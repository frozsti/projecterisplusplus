# Licensing TODO before public release

No project-wide license has been selected for Project Eris ++ yet.

Before publishing the repository as an open-source project:

1. Inventory which files are entirely original Project Eris ++ work and which files were copied, modified, or derived from Project Eris / RetroArch / PCSX-ReARMed or other upstream projects.
2. Preserve upstream copyright notices and license files for any derived files.
3. Check license compatibility before selecting a repository-wide license.
4. Keep DuckStation, RA_Integration.dll, PlayStation BIOS files and game images out of the repository and release archives.
5. If you are uncertain about a derived file, do not relabel it with a new license until its origin and obligations are clear.

Useful upstream references:

- Project Eris organization: https://github.com/Project-Eris-psc
- Project Eris Payload: https://github.com/Project-Eris-psc/Project-Eris-Payload
- PCSX-ReARMed Project Eris fork: https://github.com/Project-Eris-psc/psc_pcsx_rearmed
- RetroArch: https://github.com/libretro/RetroArch
- DuckStation: https://github.com/stenzek/duckstation

GitHub's licensing documentation explains that publishing a repository without an explicit license does not grant normal open-source reuse rights. Choose a license only after the provenance review above.
