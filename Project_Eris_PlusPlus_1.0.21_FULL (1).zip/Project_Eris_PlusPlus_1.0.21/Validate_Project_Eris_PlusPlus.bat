@echo off
setlocal
cd /d "%~dp0"
where py >nul 2>nul && (py -3 Validate_Project_Eris_PlusPlus.py & pause & exit /b %errorlevel%)
where python >nul 2>nul && (python Validate_Project_Eris_PlusPlus.py & pause & exit /b %errorlevel%)
echo Python was not found. The installer itself does not require Python, but this optional validation script does.
pause
exit /b 2
