@echo off
setlocal
cd /d "%~dp0"
echo Project Eris ++ v1.0.21 - Permanent Exporter Cleanup + First-Install Space Preflight + proven exit-only save states
powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0windows\Validate-PowerShell.ps1"
if errorlevel 1 (
  echo.
  echo Update stopped: PowerShell parser validation failed.
  pause
  exit /b 10
)
powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0windows\ProjectErisPlusPlus.InPlaceUpdate.ps1"
if errorlevel 1 pause
