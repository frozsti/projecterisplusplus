﻿$script:PerformanceRoot=Join-Path $script:AppRoot 'performance'
$script:CacheIndexFile=Join-Path $script:PerformanceRoot 'cache_index.tsv'
$script:CompileIndexFile=Join-Path $script:PerformanceRoot 'compile_index.tsv'
$script:BadgeIndexFile=Join-Path $script:PerformanceRoot 'badge_index.tsv'
$script:PerformanceModeFile=Join-Path $script:PerformanceRoot 'mode.txt'
$script:CacheIdIndex=$null
$script:CacheTitleIndex=$null
$script:CacheMetaIndex=$null
$script:LastPerfSummary=[pscustomobject]@{Action='Ready';Seconds=0.0;Scanned=0;Rebuilt=0;Skipped=0;Copied=0}
New-Item -ItemType Directory -Force -Path $script:PerformanceRoot|Out-Null

function Get-ErisPPPerformanceMode {
    if(Test-Path $script:PerformanceModeFile){try{$m=(Get-Content $script:PerformanceModeFile -Raw).Trim();if($m -in @('Fast','Verify','Full rebuild')){return $m}}catch{}}
    return 'Fast'
}
function Set-ErisPPPerformanceMode([string]$Mode){if($Mode -notin @('Fast','Verify','Full rebuild')){$Mode='Fast'};Set-Content $script:PerformanceModeFile $Mode -Encoding ASCII;return $Mode}
function Get-ErisPPPerformanceSummary {return $script:LastPerfSummary}
function Set-ErisPPPerfSummary([string]$Action,[double]$Seconds,[int]$Scanned=0,[int]$Rebuilt=0,[int]$Skipped=0,[int]$Copied=0){$script:LastPerfSummary=[pscustomobject]@{Action=$Action;Seconds=[Math]::Round($Seconds,2);Scanned=$Scanned;Rebuilt=$Rebuilt;Skipped=$Skipped;Copied=$Copied}}
function Get-ErisPPFileStamp([string]$Path){if(!$Path -or !(Test-Path $Path)){return ''};try{$f=Get-Item $Path -ErrorAction Stop;return ([string]$f.Length+':'+[string]$f.LastWriteTimeUtc.Ticks)}catch{return ''}}
function Test-ErisPPFilesEquivalent([string]$Source,[string]$Destination){
    if(!(Test-Path $Source) -or !(Test-Path $Destination)){return $false}
    try{
        $a=Get-Item $Source -ErrorAction Stop;$b=Get-Item $Destination -ErrorAction Stop
        if($a.Length -ne $b.Length){return $false}
        $mode=Get-ErisPPPerformanceMode
        if($mode -eq 'Fast'){
            # FAT timestamps have coarse resolution. A matching size plus a <= 2.5 s timestamp delta is the fast path.
            $delta=[Math]::Abs(($a.LastWriteTimeUtc-$b.LastWriteTimeUtc).TotalSeconds)
            if($delta -le 2.5){return $true}
            # Badge assets are immutable by badge name; avoid hashing thousands of images on every USB pass.
            $ext=$a.Extension.ToLowerInvariant();if($ext -in @('.bmp','.png','.jpg','.jpeg')){return $true}
        }
        return ((Get-FileHash $a.FullName -Algorithm SHA256).Hash -eq (Get-FileHash $b.FullName -Algorithm SHA256).Hash)
    }catch{return $false}
}
function Copy-ErisPPFileIfDifferent([string]$Source,[string]$Destination){
    if([string]::IsNullOrWhiteSpace($Source) -or [string]::IsNullOrWhiteSpace($Destination) -or !(Test-Path $Source)){return $false}
    try{$srcFull=[IO.Path]::GetFullPath((Get-Item $Source).FullName).TrimEnd('\');$dstFull=[IO.Path]::GetFullPath($Destination).TrimEnd('\')}catch{return $false}
    if([string]::Equals($srcFull,$dstFull,[System.StringComparison]::OrdinalIgnoreCase)){return $true}
    if(Test-ErisPPFilesEquivalent $Source $Destination){return $true}
    $parent=Split-Path $Destination -Parent;if($parent){New-Item -ItemType Directory -Force -Path $parent|Out-Null};Copy-Item $Source $Destination -Force;return (Test-Path $Destination)
}
function Copy-Tree([string]$Src,[string]$Dst){
    if(!(Test-Path $Src)){return};New-Item -ItemType Directory -Force -Path $Dst|Out-Null
    $srcRoot=(Get-Item $Src).FullName.TrimEnd('\');foreach($f in Get-ChildItem $srcRoot -Recurse -File -ErrorAction SilentlyContinue){$rel=$f.FullName.Substring($srcRoot.Length).TrimStart('\');$to=Join-Path $Dst $rel;[void](Copy-ErisPPFileIfDifferent $f.FullName $to)}
}
function Read-ErisPPTsvMap([string]$Path,[int]$KeyColumn=0){$m=@{};if(!(Test-Path $Path)){return $m};foreach($line in Get-Content $Path -ErrorAction SilentlyContinue){if(!$line -or $line.StartsWith('#')){continue};$f=$line -split "`t";if($f.Count -gt $KeyColumn){$m[[string]$f[$KeyColumn]]=$f}};return $m}

function Load-ErisPPCacheIndex {
    if($null -ne $script:CacheTitleIndex -and $null -ne $script:CacheIdIndex){return $script:CacheTitleIndex.Count}
    $byTitle=@{};$byId=@{};$meta=@{}
    if(Test-Path $script:CacheIndexFile){foreach($line in Get-Content $script:CacheIndexFile -ErrorAction SilentlyContinue){$f=$line -split "`t",5;if($f.Count -lt 5){continue};$gid=0;try{$gid=[int]$f[0]}catch{};$norm=[string]$f[1];$title=[string]$f[2];$path=[string]$f[3];$stamp=[string]$f[4];if($gid -le 0 -or !$norm -or !(Test-Path $path)){continue};$actual=Get-ErisPPFileStamp $path;if(!$actual){continue};$byId[$gid]=$path;if(!$byTitle.ContainsKey($norm)){$byTitle[$norm]=$path};$meta[$gid]=[pscustomobject]@{Id=$gid;Norm=$norm;Title=$title;Path=$path;Stamp=$actual}}}
    if($byTitle.Count -eq 0){
        foreach($dir in @($script:AchievementRaw,$script:RawCache,(Join-Path $PSScriptRoot 'bundled_cache'))){if(!$dir -or !(Test-Path $dir)){continue};foreach($f in Get-ChildItem $dir -File -Filter '*.json' -ErrorAction SilentlyContinue){try{$x=Get-Content $f.FullName -Raw -Encoding UTF8|ConvertFrom-Json;$gid=Get-ErisPPGameIdFromCache $x;if($gid -le 0 -or !(Test-ErisPPRawCacheObject $x)){continue};$title=Safe ([string](Get-ErisPPPropertyValue $x 'Title'));$norm=Normalize-Title $title;if(!$norm){$norm='id'+$gid};$byId[$gid]=$f.FullName;if(!$byTitle.ContainsKey($norm)){$byTitle[$norm]=$f.FullName};$meta[$gid]=[pscustomobject]@{Id=$gid;Norm=$norm;Title=$title;Path=$f.FullName;Stamp=(Get-ErisPPFileStamp $f.FullName)}}catch{}}}
    }
    $script:CacheTitleIndex=$byTitle;$script:CacheIdIndex=$byId;$script:CacheMetaIndex=$meta;if($byTitle.Count -gt 0){Save-ErisPPCacheIndex};return $byTitle.Count
}
function Save-ErisPPCacheIndex {
    if($null -eq $script:CacheMetaIndex){return};$rows=New-Object System.Collections.ArrayList;foreach($k in @($script:CacheMetaIndex.Keys|Sort-Object)){ $e=$script:CacheMetaIndex[$k];if($e -and (Test-Path $e.Path)){[void]$rows.Add(([string]$e.Id+"`t"+[string]$e.Norm+"`t"+(Safe ([string]$e.Title))+"`t"+[string]$e.Path+"`t"+(Get-ErisPPFileStamp ([string]$e.Path))))}};$rows|Set-Content $script:CacheIndexFile -Encoding UTF8
}
function Add-ErisPPCacheIndexEntry([string]$Path,$Cache=$null){
    if(!$Path -or !(Test-Path $Path)){return};if($null -eq $script:CacheTitleIndex){[void](Load-ErisPPCacheIndex)}
    try{if($null -eq $Cache){$Cache=Get-Content $Path -Raw -Encoding UTF8|ConvertFrom-Json};$gid=Get-ErisPPGameIdFromCache $Cache;if($gid -le 0 -or !(Test-ErisPPRawCacheObject $Cache)){return};$title=Safe ([string](Get-ErisPPPropertyValue $Cache 'Title'));$norm=Normalize-Title $title;if(!$norm){$norm='id'+$gid};$full=(Get-Item $Path).FullName;$script:CacheIdIndex[$gid]=$full;if(!$script:CacheTitleIndex.ContainsKey($norm)){$script:CacheTitleIndex[$norm]=$full};$script:CacheMetaIndex[$gid]=[pscustomobject]@{Id=$gid;Norm=$norm;Title=$title;Path=$full;Stamp=(Get-ErisPPFileStamp $full)}}catch{}
}
function Build-ErisPPCacheTitleIndex([scriptblock]$StatusCallback=$null,[switch]$Force){
    $sw=[Diagnostics.Stopwatch]::StartNew();if(!$Force){$loaded=Load-ErisPPCacheIndex;if($loaded -gt 0){Set-ErisPPPerfSummary 'Cache index loaded' $sw.Elapsed.TotalSeconds $loaded 0 $loaded 0;return $loaded}}
    $idx=@{};$id=@{};$meta=@{};$seen=@{};$n=0
    foreach($root in Get-CacheRoots){if(!$root -or !(Test-Path $root)){continue};foreach($j in Get-ChildItem $root -Recurse -File -Filter '*.json' -ErrorAction SilentlyContinue|Select-Object -First 12000){$fk=$j.FullName.ToLowerInvariant();if($seen.ContainsKey($fk)){continue};$seen[$fk]=$true;try{$x=Get-Content $j.FullName -Raw -Encoding UTF8|ConvertFrom-Json;$gid=Get-ErisPPGameIdFromCache $x;if($gid -le 0 -or !(Test-ErisPPRawCacheObject $x)){continue};$title=Safe ([string](Get-ErisPPPropertyValue $x 'Title'));$norm=Normalize-Title $title;if(!$norm){$norm='id'+$gid};if(!$idx.ContainsKey($norm)){$idx[$norm]=$j.FullName};$id[$gid]=$j.FullName;$meta[$gid]=[pscustomobject]@{Id=$gid;Norm=$norm;Title=$title;Path=$j.FullName;Stamp=(Get-ErisPPFileStamp $j.FullName)};$n++;if($StatusCallback -and (($n%250)-eq 0)){& $StatusCallback ([pscustomobject]@{Phase='CACHE_INDEX';Current=$n;Total=0;Title='';Status='Indexing achievement cache';Detail=('Caches indexed: '+$n);Identity=''})}}catch{}}}
    $script:CacheTitleIndex=$idx;$script:CacheIdIndex=$id;$script:CacheMetaIndex=$meta;Save-ErisPPCacheIndex;Set-ErisPPPerfSummary 'Cache index rebuilt' $sw.Elapsed.TotalSeconds $n $n 0 0;return $idx.Count
}
function Find-CachePathByTitle([string]$Title){$norm=Normalize-Title $Title;if(!$norm){return $null};[void](Load-ErisPPCacheIndex);if($script:CacheTitleIndex.ContainsKey($norm)){$p=[string]$script:CacheTitleIndex[$norm];if(Test-Path $p){return $p}};if($script:CacheTitleIndex.Count -eq 0){[void](Build-ErisPPCacheTitleIndex);if($script:CacheTitleIndex.ContainsKey($norm)){return [string]$script:CacheTitleIndex[$norm]}};return $null}
function Find-CacheJson([int]$Id,[string]$Title){
    foreach($r in Get-CacheRoots){$direct=Join-Path $r "$Id.json";if(Test-Path $direct){return $direct};$data=Join-Path $r "Data\$Id.json";if(Test-Path $data){return $data}}
    [void](Load-ErisPPCacheIndex);if($script:CacheIdIndex.ContainsKey($Id)){$p=[string]$script:CacheIdIndex[$Id];if(Test-Path $p){return $p}};if($Title){return (Find-CachePathByTitle $Title)};return $null
}
function Import-ErisPPRawCacheFile([string]$Path){
    if(!(Test-ErisPPRawCacheFile $Path)){return $null};$j=Get-Content $Path -Raw -Encoding UTF8|ConvertFrom-Json;$gid=Get-ErisPPGameIdFromCache $j;$raw=Join-Path $script:RawCache ("$gid.json");$libraw=Join-Path $script:AchievementRaw ("$gid.json");if(!(Copy-ErisPPFileIfDifferent $Path $raw)){return $null};if(!(Copy-ErisPPFileIfDifferent $Path $libraw)){return $null};Add-ErisPPCacheIndexEntry $libraw $j;Save-ErisPPCacheIndex;return $libraw
}
function Refresh-ErisPPAchievementLibraryCatalog([switch]$Force){
    $sw=[Diagnostics.Stopwatch]::StartNew();$catalog=Join-Path $script:AchievementLibrary 'catalog.tsv';$mode=Get-ErisPPPerformanceMode
    if(!$Force -and $mode -eq 'Fast' -and (Test-Path $catalog)){
        $loaded=Load-ErisPPCacheIndex
        if($loaded -gt 0){Set-ErisPPPerfSummary 'Achievement catalog index hit' $sw.Elapsed.TotalSeconds $loaded 0 $loaded 0;return 0}
    }
    [void](Build-ErisPPCacheTitleIndex $null -Force:$Force);$rows=New-Object System.Collections.ArrayList;$copied=0
    foreach($gid in @($script:CacheMetaIndex.Keys|Sort-Object)){$e=$script:CacheMetaIndex[$gid];if(!$e -or !(Test-Path $e.Path)){continue};$dst=Join-Path $script:AchievementRaw ("$gid.json");if(!(Test-ErisPPFilesEquivalent $e.Path $dst)){Copy-Item $e.Path $dst -Force;$copied++};$count='';try{$j=Get-Content $e.Path -Raw -Encoding UTF8|ConvertFrom-Json;$count=@(Core-Achievements $j).Count}catch{};[void]$rows.Add(([string]$gid+"`t"+(Safe ([string]$e.Title))+"`t"+[string]$count+"`t"+[string]$e.Path))}
    $rows|Set-Content $catalog -Encoding UTF8;Set-ErisPPPerfSummary 'Achievement catalog' $sw.Elapsed.TotalSeconds $rows.Count 0 ($rows.Count-$copied) $copied;return $copied
}
function Seed-ErisPPAchievementLibraryFromUsb([string]$Usb){
    if(!$Usb){return 0}
    $sw=[Diagnostics.Stopwatch]::StartNew();$root=Join-Path (Eris-Root $Usb) 'etc\erispp';$db=Join-Path $root 'database';$ui=Join-Path $root 'ui\games';$badges=Join-Path $root 'ui\badges';if(!(Test-Path $db)){return 0}
    $files=@(Get-ChildItem $db -Filter '*.fdb' -File -ErrorAction SilentlyContinue);$n=$files.Count;$copied=0;$mode=Get-ErisPPPerformanceMode
    if($mode -eq 'Fast' -and $n -gt 0){
        $complete=$true
        foreach($f in $files){$localDb=Join-Path $script:AchievementCompiled ('database\'+$f.Name);$localUi=Join-Path $script:AchievementCompiled ('ui\games\'+$f.BaseName+'.tsv');if(!(Test-Path $localDb) -or !(Test-Path $localUi)){$complete=$false;break}}
        if($complete){Set-ErisPPPerfSummary 'USB seed index hit' $sw.Elapsed.TotalSeconds $n 0 $n 0;return $n}
    }
    foreach($f in $files){
        $dst=Join-Path $script:AchievementCompiled ('database\'+$f.Name);if(!(Test-ErisPPFilesEquivalent $f.FullName $dst)){[void](Copy-ErisPPFileIfDifferent $f.FullName $dst);$copied++}
        $u=Join-Path $ui ($f.BaseName+'.tsv');if(Test-Path $u){[void](Copy-ErisPPFileIfDifferent $u (Join-Path $script:AchievementCompiled ('ui\games\'+$f.BaseName+'.tsv')))}
        # Badge trees are only copied when absent locally or when Verify/Full rebuild is requested.
        $b=Join-Path $badges $f.BaseName;$lb=Join-Path $script:AchievementCompiled ('ui\badges\'+$f.BaseName)
        if(Test-Path $b){if($mode -ne 'Fast' -or !(Test-Path $lb)){Copy-Tree $b $lb}}
    }
    Set-ErisPPPerfSummary 'USB seed' $sw.Elapsed.TotalSeconds $n 0 ($n-$copied) $copied;return $n
}
function Stage-ErisPPCompiledLibraryFast {
    $db=Join-Path $script:AchievementCompiled 'database';$games=Join-Path $script:AchievementCompiled 'ui\games'
    if(Test-Path $db){Copy-Tree $db (Join-Path $script:StageRoot 'database')}
    if(Test-Path $games){Copy-Tree $games (Join-Path $script:StageRoot 'ui\games')}
    # Do not mirror the global badge tree into staging. Badge sync is per changed RA game ID.
}
function Import-ExistingCompiledPacks($Lib){
    $sw=[Diagnostics.Stopwatch]::StartNew();$n=0
    $bundled=Join-Path $PSScriptRoot 'bundled_packs';if(Test-Path $bundled){Copy-Tree (Join-Path $bundled 'database') (Join-Path $script:AchievementCompiled 'database');Copy-Tree (Join-Path $bundled 'ui') (Join-Path $script:AchievementCompiled 'ui')}
    foreach($r in Get-LegacyCompiledRoots){$full='';try{$full=(Get-Item $r).FullName}catch{continue};$current=(Join-Path $script:AchievementCompiled 'database');if([string]::Equals($full,$current,[System.StringComparison]::OrdinalIgnoreCase)){continue};foreach($f in Get-ChildItem $r -Filter '*.fdb' -File -ErrorAction SilentlyContinue){$dst=Join-Path $script:AchievementCompiled ("database\"+$f.Name);if(!(Test-Path $dst)){Copy-Item $f.FullName $dst -Force;$n++}}}
    Stage-ErisPPCompiledLibraryFast
    if($null -ne $Lib){foreach($g in @($Lib.games)){$gid=0;try{$gid=[int]$g.RaId}catch{};if($gid -le 0){continue};$f=Join-Path $script:AchievementCompiled ("database\$gid.fdb");if(!(Test-Path $f)){continue};try{$h=(Get-Content $f -TotalCount 1 -Encoding ASCII)-split "`t";if($h.Count -ge 4 -and $h[0] -eq 'ERPP2'){$cnt=[int]$h[2];$g.Supported=$cnt;if([int]$g.Total -le 0){$g.Total=$cnt};$g.PackStatus=if([int]$g.Total -gt $cnt){'Partial'}else{'Ready'}}}catch{}};Save-Library $Lib};Set-ErisPPPerfSummary 'Stage compiled library' $sw.Elapsed.TotalSeconds 0 0 0 $n;return $n
}
function Get-ErisPPCompileState {return (Read-ErisPPTsvMap $script:CompileIndexFile 0)}
function Save-ErisPPCompileState($Map){$rows=New-Object System.Collections.ArrayList;foreach($k in @($Map.Keys|Sort-Object)){[void]$rows.Add(($Map[$k]-join "`t"))};$rows|Set-Content $script:CompileIndexFile -Encoding UTF8}
function Compile-AvailablePacks($Lib,[switch]$Force,[switch]$Verify){
    $sw=[Diagnostics.Stopwatch]::StartNew();$mode=Get-ErisPPPerformanceMode;if($mode -eq 'Full rebuild'){$Force=$true};if($mode -eq 'Verify'){$Verify=$true};if($Force -or $Verify){[void](Build-ErisPPCacheTitleIndex $null -Force)}else{[void](Build-ErisPPCacheTitleIndex)}
    $state=Get-ErisPPCompileState;$built=0;$skipped=0;$scanned=0
    foreach($g in @(Get-ErisPPCanonicalGameList $Lib)){$scanned++;$id=0;try{$id=[int]$g.RaId}catch{};$c=$null;if($id -gt 0 -and !(Test-LocalGameId $id)){$c=Find-CacheJson $id ([string]$g.Title)};if(!$c){$c=Find-CachePathByTitle ([string]$g.Title)};if(!$c){continue};$cacheStamp=Get-ErisPPFileStamp $c;$gid=$id;if($gid -le 0 -or (Test-LocalGameId $gid)){try{$j=Get-Content $c -Raw -Encoding UTF8|ConvertFrom-Json;$gid=Get-ErisPPGameIdFromCache $j;if($gid -gt 0){$g.RaId=$gid;$tt=Get-ErisPPPropertyValue $j 'Title';if($tt){$g.Title=Safe ([string]$tt)}}}catch{}}
        if($gid -le 0){continue};$db=Join-Path $script:AchievementCompiled ('database\'+$gid+'.fdb');$key=[string]$gid;$canSkip=$false;if(!$Force -and (Test-Path $db)){
            if($state.ContainsKey($key)){$row=$state[$key];if($row.Count -ge 3 -and [string]$row[1] -eq $cacheStamp){$canSkip=$true}}
            elseif(!$Verify){try{$dbi=Get-Item $db;$ci=Get-Item $c;$h=(Get-Content $db -TotalCount 1 -Encoding ASCII)-split "`t";if($h.Count -ge 4 -and $h[0] -eq 'ERPP2' -and [int]$h[1] -eq $gid -and $dbi.LastWriteTimeUtc -ge $ci.LastWriteTimeUtc){$canSkip=$true;$state[$key]=@($key,$cacheStamp,(Get-ErisPPFileStamp $db),'Adopted')}}catch{}}
            if($canSkip -and $Verify){$pack=[pscustomobject]@{Gid=$gid;Db=$db;Ui=(Join-Path $script:AchievementCompiled ('ui\games\'+$gid+'.tsv'));Badges=(Join-Path $script:AchievementCompiled ('ui\badges\'+$gid));Count=0;Title=$g.Title};$canSkip=Stage-ErisPPCompiledPack $pack}
        }
        if($canSkip){try{$h=(Get-Content $db -TotalCount 1 -Encoding ASCII)-split "`t";$cnt=[int]$h[2];$g.Supported=$cnt;if([int]$g.Total -le 0){$g.Total=$cnt};$g.PackStatus=if([int]$g.Total -gt $cnt){'Partial'}else{'Ready'}}catch{};$skipped++;continue}
        try{$canon=Import-ErisPPRawCacheFile $c;if($canon -and (Build-Pack $g $canon)){[void](Save-ErisPPCompiledPack $g $canon);$db=Join-Path $script:AchievementCompiled ('database\'+$g.RaId+'.fdb');$state[[string]$g.RaId]=@([string]$g.RaId,(Get-ErisPPFileStamp $canon),(Get-ErisPPFileStamp $db),[string]$g.PackStatus);$built++}}catch{Write-Warning ('Pack compile failed for '+$g.Title+': '+$_.Exception.Message)}
    }
    Save-ErisPPCompileState $state;Save-Library $Lib;Set-ErisPPPerfSummary 'FDB compile' $sw.Elapsed.TotalSeconds $scanned $built $skipped 0;return $built
}
function Get-ErisPPBadgeState {return (Read-ErisPPTsvMap $script:BadgeIndexFile 0)}
function Save-ErisPPBadgeState($Map){$rows=New-Object System.Collections.ArrayList;foreach($k in @($Map.Keys|Sort-Object)){[void]$rows.Add(($Map[$k]-join "`t"))};$rows|Set-Content $script:BadgeIndexFile -Encoding UTF8}
function Sync-InstalledBadgeAssets([string]$Usb,$Lib){
    $sw=[Diagnostics.Stopwatch]::StartNew();$ui=Join-Path (Eris-Root $Usb) 'etc\erispp\ui';if(!(Test-Path $ui)){return 0};[void](Load-ErisPPCacheIndex);$state=Get-ErisPPBadgeState;$linked=0;$downloaded=0;$failed=0;$games=0;$skipped=0
    foreach($g in @(Get-ErisPPCanonicalGameList $Lib)){
        $gid=0;try{$gid=[int]$g.RaId}catch{};if($gid -le 0){continue};$tsv=Join-Path $ui ('games\'+$gid+'.tsv');if(!(Test-Path $tsv)){continue};$c=Find-CacheJson $gid ([string]$g.Title);if(!$c){continue}
        $cs=Get-ErisPPFileStamp $c;$ts=Get-ErisPPFileStamp $tsv;$key=[string]$gid;$bd=Join-Path $ui ('badges\'+$gid);$localBd=Join-Path $script:AchievementCompiled ('ui\badges\'+$gid)
        if(!(Test-Path $bd) -and (Test-Path $localBd)){Copy-Tree $localBd $bd}
        if($state.ContainsKey($key)){$row=$state[$key];if($row.Count -ge 4 -and $row[1] -eq $cs -and $row[2] -eq $ts -and (Test-Path $bd)){try{$linked+=[int]$row[3]}catch{};$games++;$skipped++;continue}}
        $r=Sync-ErisPPUiBadges $ui $gid $c;$linked+=$r.Linked;$downloaded+=$r.Downloaded;$failed+=$r.Failed;$games++;$state[$key]=@($key,$cs,(Get-ErisPPFileStamp $tsv),[string]$r.Linked)
        if(Test-Path $bd){Copy-Tree $bd $localBd}
    }
    Save-ErisPPBadgeState $state;@('Project Eris ++ 1.0.21 badge sync',('Generated='+(Get-Date -Format o)),('Games='+$games),('Linked='+$linked),('Downloaded='+$downloaded),('Failed='+$failed),('SkippedUnchanged='+$skipped))|Set-Content (Join-Path $Usb 'PROJECT_ERIS_PP_BADGES_1.0.21.txt') -Encoding ASCII;Set-ErisPPPerfSummary 'Badge sync' $sw.Elapsed.TotalSeconds $games ($games-$skipped) $skipped $downloaded;return $linked
}
function Deploy-StagedOnly([string]$Usb,$Lib){
    $sw=[Diagnostics.Stopwatch]::StartNew();Build-Indexes $Lib;$eris=Eris-Root $Usb;$root=Join-Path $eris 'etc\erispp';$usbDb=Join-Path $root 'database';$usbUi=Join-Path $root 'ui';$usbUiGames=Join-Path $usbUi 'games';New-Item -ItemType Directory -Force -Path $root,$usbDb,$usbUi,$usbUiGames,(Join-Path $root 'runtime')|Out-Null
    if((Get-ErisPPPerformanceMode) -eq 'Full rebuild'){Remove-Item (Join-Path $usbDb '*.fdb') -Force -ErrorAction SilentlyContinue;Remove-Item (Join-Path $usbUiGames '*.tsv') -Force -ErrorAction SilentlyContinue}
    Copy-Tree (Join-Path $script:PackageRoot 'console\runtime') (Join-Path $root 'runtime');foreach($legacy in @('erispp_audio_prepare.sh','erispp_unlock_audio.sh','erispp_audio_once.sh','erispp_dsp.so','TEST_AUDIO.flag','TEST_AUDIO_DSP.flag','PLAY_CHIME.flag')){Remove-Item (Join-Path (Join-Path $root 'runtime') $legacy) -Force -ErrorAction SilentlyContinue}
    if(!(Test-Path (Join-Path $root 'runtime\FIRST_BOOT_EXPORT_PENDING.flag'))){Remove-Item (Join-Path $root 'runtime\erispp_firstboot_export.sh') -Force -ErrorAction SilentlyContinue}
    Copy-Tree (Join-Path $script:StageRoot 'database') $usbDb
    Copy-Tree (Join-Path $script:StageRoot 'ui\games') $usbUiGames
    $stageGames=Join-Path $script:StageRoot 'ui\games.tsv';if(Test-Path $stageGames){[void](Copy-ErisPPFileIfDifferent $stageGames (Join-Path $usbUi 'games.tsv'))}
    $stageMap=Join-Path $script:StageRoot 'content_map.tsv';if(Test-Path $stageMap){[void](Copy-ErisPPFileIfDifferent $stageMap (Join-Path $root 'content_map.tsv'))}
    $badgeLinked=Sync-InstalledBadgeAssets $Usb $Lib
    Set-ErisPPPerfSummary 'USB deploy' $sw.Elapsed.TotalSeconds 0 0 0 0
    return $badgeLinked
}
function Reset-ErisPPPerformanceIndexes {foreach($p in @($script:CacheIndexFile,$script:CompileIndexFile,$script:BadgeIndexFile)){Remove-Item $p -Force -ErrorAction SilentlyContinue};$script:CacheTitleIndex=$null;$script:CacheIdIndex=$null;$script:CacheMetaIndex=$null;return $true}
