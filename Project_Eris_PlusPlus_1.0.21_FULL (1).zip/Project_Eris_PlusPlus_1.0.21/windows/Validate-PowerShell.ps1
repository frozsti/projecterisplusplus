﻿param([string[]]$Paths)
$ErrorActionPreference='Stop'
if($Paths -and $Paths.Count -gt 0){
    $files=@($Paths)
}else{
    $files=@(
        (Join-Path $PSScriptRoot 'ProjectErisPlusPlus.Core.ps1'),
        (Join-Path $PSScriptRoot 'ProjectErisPlusPlus.Wizard.ps1'),
        (Join-Path $PSScriptRoot 'ProjectErisPlusPlus.ResetLab.ps1'),
        (Join-Path $PSScriptRoot 'ProjectErisPlusPlus.RichCompiler.ps1'),
        (Join-Path $PSScriptRoot 'ProjectErisPlusPlus.AchievementRepair.ps1'),
        (Join-Path $PSScriptRoot 'ProjectErisPlusPlus.InPlaceUpdate.ps1'),
        (Join-Path $PSScriptRoot 'Collect-RuntimeCheck.ps1'),
        (Join-Path $PSScriptRoot 'ProjectErisPlusPlus.TestAudio.ps1'),
        (Join-Path $PSScriptRoot 'ProjectErisPlusPlus.Performance.ps1'),
        (Join-Path $PSScriptRoot 'ProjectErisPlusPlus.DesktopWizard.ps1'),
        (Join-Path $PSScriptRoot 'ProjectErisPlusPlus.SimpleWizard.ps1'),
        (Join-Path $PSScriptRoot 'Install-DesktopWizard.ps1')
    )
}
$failed=$false
foreach($file in $files){
    if(!(Test-Path $file)){
        Write-Host ('MISSING: '+$file) -ForegroundColor Red
        $failed=$true
        continue
    }
    $tokens=$null
    $errors=$null
    [System.Management.Automation.Language.Parser]::ParseFile($file,[ref]$tokens,[ref]$errors)|Out-Null
    if($errors -and $errors.Count -gt 0){
        Write-Host ('PARSER ERROR: '+$file) -ForegroundColor Red
        foreach($e in $errors){Write-Host ('  '+$e.Message+' at line '+$e.Extent.StartLineNumber+', col '+$e.Extent.StartColumnNumber) -ForegroundColor Red}
        $failed=$true
    }else{
        Write-Host ('OK: '+$file) -ForegroundColor Green
    }
}
if($failed){exit 10}
exit 0
