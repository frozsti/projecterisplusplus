﻿$ErrorActionPreference='Stop'
Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing
[System.Windows.Forms.Application]::EnableVisualStyles()
. (Join-Path $PSScriptRoot 'ProjectErisPlusPlus.Core.ps1')

$script:Usb=Find-ErisUsb
$script:Lib=Get-Library
$script:Initial=$true
if($script:Usb -and (Test-Path (Join-Path $script:Usb 'PROJECT_ERIS_PP_INSTALL.txt'))){$script:Initial=$false}
$script:Step=1
$script:InstallButton=$null

$form=New-Object System.Windows.Forms.Form
$form.Text='Project Eris ++ 1.0.21'
$form.StartPosition='CenterScreen'
$form.Size=New-Object System.Drawing.Size(920,720)
$form.MinimumSize=New-Object System.Drawing.Size(920,720)
$form.BackColor=[System.Drawing.Color]::FromArgb(9,20,42)
$form.ForeColor=[System.Drawing.Color]::White
$form.Font=New-Object System.Drawing.Font('Segoe UI',10)

$header=New-Object System.Windows.Forms.Label
$header.Text='PROJECT ERIS ++'
$header.Font=New-Object System.Drawing.Font('Segoe UI',25,[System.Drawing.FontStyle]::Bold)
$header.ForeColor=[System.Drawing.Color]::FromArgb(142,233,255)
$header.AutoSize=$true;$header.Location=New-Object System.Drawing.Point(24,18);$form.Controls.Add($header)
$sub=New-Object System.Windows.Forms.Label
$sub.Text='PlayStation Classic - Project Eris upgrade wizard'
$sub.ForeColor=[System.Drawing.Color]::FromArgb(160,180,205);$sub.AutoSize=$true;$sub.Location=New-Object System.Drawing.Point(28,65);$form.Controls.Add($sub)
$ver=New-Object System.Windows.Forms.Label;$ver.Text='v1.0.21';$ver.Location=New-Object System.Drawing.Point(790,24);$ver.Size=New-Object System.Drawing.Size(84,28);$ver.TextAlign=[System.Drawing.ContentAlignment]::MiddleCenter;$ver.ForeColor=[System.Drawing.Color]::FromArgb(142,233,255);$ver.BackColor=[System.Drawing.Color]::FromArgb(23,41,67);$ver.BorderStyle=[System.Windows.Forms.BorderStyle]::FixedSingle;$ver.Font=New-Object System.Drawing.Font('Segoe UI',9,[System.Drawing.FontStyle]::Bold);$form.Controls.Add($ver)
$status=New-Object System.Windows.Forms.Label
$status.Location=New-Object System.Drawing.Point(28,95);$status.Size=New-Object System.Drawing.Size(850,28);$status.ForeColor=[System.Drawing.Color]::FromArgb(143,255,199);$form.Controls.Add($status)
$panel=New-Object System.Windows.Forms.Panel
$panel.Location=New-Object System.Drawing.Point(24,132);$panel.Size=New-Object System.Drawing.Size(850,480);$panel.BackColor=[System.Drawing.Color]::FromArgb(15,28,50);$panel.BorderStyle=[System.Windows.Forms.BorderStyle]::FixedSingle;$form.Controls.Add($panel)
$back=New-Object System.Windows.Forms.Button;$back.Text='Back';$back.Location=New-Object System.Drawing.Point(24,628);$back.Size=New-Object System.Drawing.Size(120,38);$back.FlatStyle=[System.Windows.Forms.FlatStyle]::Flat;$back.BackColor=[System.Drawing.Color]::FromArgb(23,41,67);$back.ForeColor=[System.Drawing.Color]::White;$back.FlatAppearance.BorderColor=[System.Drawing.Color]::FromArgb(48,84,115);$form.Controls.Add($back)
$next=New-Object System.Windows.Forms.Button;$next.Text='Next';$next.Location=New-Object System.Drawing.Point(754,628);$next.Size=New-Object System.Drawing.Size(120,38);$next.FlatStyle=[System.Windows.Forms.FlatStyle]::Flat;$next.BackColor=[System.Drawing.Color]::FromArgb(108,224,255);$next.ForeColor=[System.Drawing.Color]::FromArgb(6,25,40);$next.FlatAppearance.BorderColor=[System.Drawing.Color]::FromArgb(108,224,255);$next.Font=New-Object System.Drawing.Font('Segoe UI',9,[System.Drawing.FontStyle]::Bold);$form.Controls.Add($next)

function Set-Status([string]$Text,[bool]$Bad=$false){$status.Text=$Text;$status.ForeColor=if($Bad){[System.Drawing.Color]::FromArgb(255,116,130)}else{[System.Drawing.Color]::FromArgb(143,255,199)};$form.Refresh()}
function Label([string]$Text,[int]$X,[int]$Y,[int]$W=780,[int]$H=36,[int]$Size=10,[bool]$Bold=$false){$l=New-Object System.Windows.Forms.Label;$l.Text=$Text;$l.Location=New-Object System.Drawing.Point($X,$Y);$l.Size=New-Object System.Drawing.Size($W,$H);$l.ForeColor=[System.Drawing.Color]::White;$l.Font=New-Object System.Drawing.Font('Segoe UI',$Size,$(if($Bold){[System.Drawing.FontStyle]::Bold}else{[System.Drawing.FontStyle]::Regular}));$panel.Controls.Add($l);return $l}
function Button([string]$Text,[int]$X,[int]$Y,[int]$W=220,[int]$H=42){$b=New-Object System.Windows.Forms.Button;$b.Text=$Text;$b.Location=New-Object System.Drawing.Point($X,$Y);$b.Size=New-Object System.Drawing.Size($W,$H);$b.FlatStyle=[System.Windows.Forms.FlatStyle]::Flat;$b.FlatAppearance.BorderSize=1;$b.FlatAppearance.BorderColor=[System.Drawing.Color]::FromArgb(48,84,115);$b.BackColor=[System.Drawing.Color]::FromArgb(23,41,67);$b.ForeColor=[System.Drawing.Color]::FromArgb(236,244,252);$b.Cursor=[System.Windows.Forms.Cursors]::Hand;$b.Font=New-Object System.Drawing.Font('Segoe UI',9,[System.Drawing.FontStyle]::Bold);$panel.Controls.Add($b);return $b}
function Profile-NameFromUsb {if(!$script:Usb){return (Get-ProfileName)};$p=Join-Path (Eris-Root $script:Usb) 'etc\erispp\profiles\active\profile.tsv';if(Test-Path $p){foreach($line in Get-Content $p){$f=$line -split "`t",2;if($f.Count -eq 2 -and $f[0] -eq 'display'){return $f[1]}}};return (Get-ProfileName)}
function Pack-Counts {$ready=@($script:Lib.games|Where-Object{$_.PackStatus -in @('Ready','Partial')}).Count;$no=@($script:Lib.games|Where-Object{$_.OfficialSet -eq 'NO_SET'}).Count;$need=@($script:Lib.games|Where-Object{$_.OfficialSet -ne 'NO_SET' -and $_.PackStatus -notin @('Ready','Partial')}).Count;return @($ready,$need,$no)}

function Render-Initial {
    $panel.Controls.Clear();$back.Visible=$true;$next.Visible=$true
    if($script:Step -eq 1){
        Label 'Step 1 of 4 - Check Project Eris' 24 18 780 36 15 $true|Out-Null
        if(!$script:Usb){Label 'No clean Project Eris USB was found. Insert the USB drive and click Scan again.' 24 72 770 60|Out-Null;$b=Button 'Scan again' 24 145 180 42;$b.Add_Click({$script:Usb=Find-ErisUsb;Render-Initial});$next.Enabled=$false;Set-Status 'Waiting for a Project Eris USB drive.' $true;return}
        Label ("USB found: "+$script:Usb) 24 65 780 30|Out-Null
        $y=92;$ok=$true
        foreach($c in Test-Preflight $script:Usb){$mark=if($c.OK){'[OK]'}else{'[X]'};$l=Label ("$mark  "+$c.Name) 36 $y 700 28 10 $false;if(!$c.OK){$l.ForeColor=[System.Drawing.Color]::FromArgb(255,116,130);$ok=$false}else{$l.ForeColor=[System.Drawing.Color]::FromArgb(143,255,199)};$y+=30}
        Label 'The wizard creates a backup under project_eris\backup before every change.' 24 345 790 42|Out-Null
        $next.Enabled=$ok;$back.Enabled=$false;Set-Status $(if($ok){'Preflight passed. The USB drive is ready to be upgraded.'}else{'Preflight failed; the wizard will not change the USB drive.'}) (!$ok)
    } elseif($script:Step -eq 2){
        Label 'Step 2 of 4 - Profile' 24 18 780 36 15 $true|Out-Null
        Label 'This is the only information Project Eris ++ needs for the base installation.' 24 68 780 40|Out-Null
        Label 'Profile name' 24 128 300 30 11 $true|Out-Null
        $t=New-Object System.Windows.Forms.TextBox;$t.Name='ProfileBox';$t.Text=Get-ProfileName;$t.Location=New-Object System.Drawing.Point(24,166);$t.Size=New-Object System.Drawing.Size(420,34);$t.Font=New-Object System.Drawing.Font('Segoe UI',12);$panel.Controls.Add($t)
        Label 'Unlocks, played games and history are stored only on this USB drive.' 24 230 780 50|Out-Null
        $back.Enabled=$true;$next.Enabled=$true;Set-Status 'Enter your profile name and continue.'
    } elseif($script:Step -eq 3){
        Label 'Step 3 of 4 - Install' 24 18 780 36 15 $true|Out-Null
        Label 'The following components will now be installed as one complete package:' 24 68 780 32|Out-Null
        $items=@('Carousel -> RetroArch for all games','DualShock / analog controller + rumble','Persistent RetroArch saves and clean return to Carousel','Project Eris ++ Achievement Hub + local evaluator','Top-left unlock popup + unlock sound','Automatic one-time Internal 20 export on first console boot (14 GiB free-space preflight)','Profile and local achievement database')
        $y=108;foreach($x in $items){Label ('- '+$x) 42 $y 760 28|Out-Null;$y+=31}
        $script:InstallButton=Button 'Install Project Eris ++' 24 340 290 46
        $script:InstallButton.Add_Click({
            try{
                $script:InstallButton.Enabled=$false
                $next.Enabled=$false
                Set-Status 'Installing and validating Project Eris ++...'
                $name=Get-ProfileName
                $backup=Deploy-ProjectErisPP $script:Usb $name $script:Lib
                Install-PCShortcuts
                Set-Status 'Installation completed and backup created.'
                [System.Windows.Forms.MessageBox]::Show("Base installation completed.`r`n`r`nBackup:`r`n$backup",'Project Eris ++')|Out-Null
                $script:Step=4
                Render-Initial
            }catch{
                $msg=$_.Exception.Message
                $logDir=Join-Path $script:AppRoot 'Logs'
                New-Item -ItemType Directory -Force -Path $logDir|Out-Null
                $log=Join-Path $logDir ('install_error_'+(Get-Date -Format 'yyyyMMdd_HHmmss')+'.txt')
                @(
                    'Project Eris ++ 1.0.21 installation error',
                    'Time='+(Get-Date -Format o),
                    'USB='+[string]$script:Usb,
                    'Message='+$msg,
                    '',
                    'Invocation:',
                    [string]$_.InvocationInfo.PositionMessage,
                    '',
                    'Script stack:',
                    [string]$_.ScriptStackTrace,
                    '',
                    'Exception:',
                    [string]($_|Out-String)
                )|Set-Content $log -Encoding UTF8
                Set-Status $msg $true
                [System.Windows.Forms.MessageBox]::Show(($msg+"`r`n`r`nDiagnostic log:`r`n"+$log),'Installation error')|Out-Null
                if($null -ne $script:InstallButton){$script:InstallButton.Enabled=$true}
            }
        })
        $back.Enabled=$true;$next.Enabled=$false;Set-Status 'Ready to upgrade the clean Project Eris installation.'
    } else {
        Label 'Step 4 of 4 - Internal 20 games' 24 18 780 36 15 $true|Out-Null
        $export=Join-Path $script:Usb 'PROJECT_ERIS_PP_INTERNAL_EXPORT\EXPORT_COMPLETE.txt'
        if(!(Test-Path $export)){
            $pending=Join-Path (Eris-Root $script:Usb) 'etc\erispp\runtime\FIRST_BOOT_EXPORT_PENDING.flag'
            if(Test-Path $pending){
                Label 'Everything is ready for the automatic one-time copy of the 20 internal games.' 24 70 790 52|Out-Null
                Label '1. Safely eject the USB drive and start the PlayStation Classic.' 42 132 760 30|Out-Null
                Label '2. Project Eris ++ Internal Export opens automatically instead of the Carousel.' 42 166 760 30|Out-Null
                Label '3. Do not touch anything: all 20 games are copied and verified automatically.' 42 200 760 30|Out-Null
                Label '4. On success, Project Eris ++ removes the copy app, restores normal boot and powers off the Classic.' 42 234 760 52|Out-Null
                Label '5. Then reconnect the USB drive to this PC and click below.' 42 286 760 30|Out-Null
                Set-Status 'Automatic Internal 20 export is ready for the next console boot.'
            } else {
                Label 'The Internal 20 export is incomplete and the automatic first-boot marker is missing.' 24 70 790 52|Out-Null
                Label 'The one-time exporter is removed after any failed console attempt and never remains as a retry app. Resolve the reported issue, then rerun the base installer if the Internal 20 export is still needed.' 42 135 760 72|Out-Null
                Set-Status 'Internal 20 export is incomplete; no exporter remains on the USB.' $true
            }
            $b=Button 'Check USB again' 24 335 240 44;$b.Add_Click({$script:Usb=Find-ErisUsb;if($script:Usb -and (Test-Path (Join-Path $script:Usb 'PROJECT_ERIS_PP_INTERNAL_EXPORT\EXPORT_COMPLETE.txt'))){$script:Lib=Get-Library;Render-Initial}else{Set-Status 'The complete Internal 20 export has not been found yet.' $true}})
            $next.Visible=$false;$back.Visible=$false
        } else {
            $n=Sync-InternalExport $script:Usb $script:Lib;Import-ExistingCompiledPacks $script:Lib|Out-Null;$built=Compile-AvailablePacks $script:Lib;Deploy-StagedOnly $script:Usb $script:Lib;$c=Pack-Counts
            Label 'Internal 20 export found and processed.' 24 72 780 36 12 $true|Out-Null
            Label ("Scanned internal slots: $n / 20") 42 125 700 30|Out-Null
            Label ("Achievement-ready: $($c[0])   -   Pack needed: $($c[1])   -   No official set: $($c[2])") 42 160 760 30|Out-Null
            Label 'Project Eris ++ never creates fake achievements. An FDB is marked Ready only when genuine trigger logic from an existing local cache has been compiled.' 42 210 750 72|Out-Null
            $b=Button 'Open Project Eris ++ Manager' 24 315 270 44;$b.Add_Click({$script:Initial=$false;Render-Dashboard});$r=Button 'Repair achievement packs' 315 315 270 44;$r.Add_Click({Start-Process powershell.exe -ArgumentList ('-NoProfile -ExecutionPolicy Bypass -File "'+(Join-Path $PSScriptRoot 'ProjectErisPlusPlus.AchievementRepair.ps1')+'"')})
            $next.Visible=$false;$back.Visible=$false;Set-Status 'Internal 20 is synchronized.'
        }
    }
}

function Invoke-LibraryImportUi {
    $pick=New-Object System.Windows.Forms.FolderBrowserDialog
    $pick.Description='Select the root folder of your PS1 game library. All subfolders are scanned automatically.'
    $pick.ShowNewFolderButton=$false
    if($pick.ShowDialog() -ne 'OK'){return}
    $rootFolder=$pick.SelectedPath
    $win=New-Object System.Windows.Forms.Form;$win.Text='Project Eris ++ - Import Complete Library';$win.StartPosition='CenterParent';$win.Size=New-Object System.Drawing.Size(1040,650);$win.MinimumSize=New-Object System.Drawing.Size(1040,650);$win.BackColor=[System.Drawing.Color]::FromArgb(9,20,42);$win.ForeColor=[System.Drawing.Color]::White;$win.Font=New-Object System.Drawing.Font('Segoe UI',9)
    $title=New-Object System.Windows.Forms.Label;$title.Text='COMPLETE GAME LIBRARY';$title.Font=New-Object System.Drawing.Font('Segoe UI',18,[System.Drawing.FontStyle]::Bold);$title.ForeColor=[System.Drawing.Color]::FromArgb(142,233,255);$title.Location=New-Object System.Drawing.Point(20,18);$title.Size=New-Object System.Drawing.Size(600,36);$win.Controls.Add($title)
    $path=New-Object System.Windows.Forms.Label;$path.Text=$rootFolder;$path.Location=New-Object System.Drawing.Point(22,58);$path.Size=New-Object System.Drawing.Size(970,24);$path.ForeColor=[System.Drawing.Color]::FromArgb(170,190,215);$win.Controls.Add($path)
    $sum=New-Object System.Windows.Forms.Label;$sum.Text='Starting recursive scan...';$sum.Location=New-Object System.Drawing.Point(22,88);$sum.Size=New-Object System.Drawing.Size(970,28);$sum.ForeColor=[System.Drawing.Color]::FromArgb(143,255,199);$win.Controls.Add($sum)
    $prog=New-Object System.Windows.Forms.ProgressBar;$prog.Location=New-Object System.Drawing.Point(22,120);$prog.Size=New-Object System.Drawing.Size(970,20);$prog.Minimum=0;$prog.Maximum=100;$prog.Value=0;$win.Controls.Add($prog)
    $grid=New-Object System.Windows.Forms.DataGridView;$grid.Location=New-Object System.Drawing.Point(22,154);$grid.Size=New-Object System.Drawing.Size(970,390);$grid.ReadOnly=$true;$grid.AllowUserToAddRows=$false;$grid.AllowUserToDeleteRows=$false;$grid.RowHeadersVisible=$false;$grid.AutoSizeColumnsMode=[System.Windows.Forms.DataGridViewAutoSizeColumnsMode]::Fill;$grid.BackgroundColor=[System.Drawing.Color]::FromArgb(14,22,43);$grid.ForeColor=[System.Drawing.Color]::Black;$grid.SelectionMode=[System.Windows.Forms.DataGridViewSelectionMode]::FullRowSelect
    [void]$grid.Columns.Add('Game','Game');[void]$grid.Columns.Add('Type','Type');[void]$grid.Columns.Add('Discs','Discs');[void]$grid.Columns.Add('Status','Status');[void]$grid.Columns.Add('Detail','Detail');$grid.Columns[0].FillWeight=28;$grid.Columns[1].FillWeight=12;$grid.Columns[2].FillWeight=7;$grid.Columns[3].FillWeight=18;$grid.Columns[4].FillWeight=35;$win.Controls.Add($grid)
    $close=New-Object System.Windows.Forms.Button;$close.Text='Close';$close.Location=New-Object System.Drawing.Point(872,562);$close.Size=New-Object System.Drawing.Size(120,36);$close.Enabled=$false;$close.Add_Click({$win.Close()});$win.Controls.Add($close)
    $openReport=New-Object System.Windows.Forms.Button;$openReport.Text='Open report';$openReport.Location=New-Object System.Drawing.Point(720,562);$openReport.Size=New-Object System.Drawing.Size(135,36);$openReport.Enabled=$false;$win.Controls.Add($openReport)
    $win.Show($form);[System.Windows.Forms.Application]::DoEvents()
    try{
        $uiTick=[Diagnostics.Stopwatch]::StartNew()
        $scanCb={param($e)if($uiTick.ElapsedMilliseconds -lt 250){return};$uiTick.Restart();$sum.Text=$e.Detail;$win.Refresh();[System.Windows.Forms.Application]::DoEvents()}.GetNewClosure()
        $scan=Get-ErisPPLibraryScan $rootFolder $scanCb
        $rowById=@{}
        foreach($i in @($scan.Items)){$ri=$grid.Rows.Add($i.Title,$i.Type,[string]$i.DiscCount,'Found',$(if($i.MultiDisc){'Multi-disc; '+$(if($i.GeneratedM3u){'M3U will be created automatically'}else{'existing M3U used'})}else{'Single-disc'}));$rowById[[string]$i.Identity]=$ri}
        foreach($i in @($scan.Issues)){[void]$grid.Rows.Add($i.Title,$i.Type,'-','Needs attention',$i.Detail)}
        $sum.Text=('Scan complete: '+$scan.Games+' games; '+$scan.SingleDisc+' single-disc; '+$scan.MultiDisc+' multi-disc; '+$scan.IssuesCount+' issue(s). FDB preflight starts now...');$prog.Value=0;$win.Refresh();[System.Windows.Forms.Application]::DoEvents()
        $cb={param($e)
            if($e.Total -gt 0){$v=[int](100.0*[double]$e.Current/[double]$e.Total);if($v -lt 0){$v=0};if($v -gt 100){$v=100};$prog.Value=$v}
            if($e.Identity -and $rowById.ContainsKey([string]$e.Identity)){$r=$grid.Rows[[int]$rowById[[string]$e.Identity]];$r.Cells[3].Value=$e.Status;$r.Cells[4].Value=$e.Detail}
            if($uiTick.ElapsedMilliseconds -ge 250 -or $e.Phase -eq 'DEPLOY'){$uiTick.Restart();if($e.Title){$sum.Text=($e.Status+': '+$e.Title+' - '+$e.Detail)}else{$sum.Text=($e.Status+' - '+$e.Detail)};$win.Refresh();[System.Windows.Forms.Application]::DoEvents()}
        }.GetNewClosure()
        $r=Import-ErisPPGameLibrary $script:Usb $rootFolder $script:Lib $scan $cb
        $prog.Value=100;$sum.Text=('Done: '+$r.Added+' added; '+$r.AlreadyPresent+' already present; '+$r.Ready+' achievement-ready; '+$r.NoSet+' no-set; '+$r.Blocked+' blocked; '+$r.MultiDisc+' multi-disc.');$close.Enabled=$true;$openReport.Enabled=$true;$reportPath=$r.Report;$openReport.Add_Click({if(Test-Path $reportPath){Start-Process notepad.exe $reportPath}});$script:Lib=Get-Library;Set-Status ("Library import complete: $($r.Added) added, $($r.AlreadyPresent) already present, $($r.Blocked) blocked.");$win.Refresh()
    }catch{$sum.Text=('ERROR: '+$_.Exception.Message);$sum.ForeColor=[System.Drawing.Color]::FromArgb(255,116,130);$close.Enabled=$true;$win.Refresh();Set-Status $_.Exception.Message $true}
}


function Invoke-ExistingUsbImportUi {
    $win=New-Object System.Windows.Forms.Form;$win.Text='Project Eris ++ - Import Installed USB Games';$win.StartPosition='CenterParent';$win.Size=New-Object System.Drawing.Size(1040,650);$win.MinimumSize=New-Object System.Drawing.Size(1040,650);$win.BackColor=[System.Drawing.Color]::FromArgb(9,20,42);$win.ForeColor=[System.Drawing.Color]::White;$win.Font=New-Object System.Drawing.Font('Segoe UI',9)
    $title=New-Object System.Windows.Forms.Label;$title.Text='INSTALLED PROJECT ERIS GAMES';$title.Font=New-Object System.Drawing.Font('Segoe UI',18,[System.Drawing.FontStyle]::Bold);$title.ForeColor=[System.Drawing.Color]::FromArgb(142,233,255);$title.Location=New-Object System.Drawing.Point(20,18);$title.Size=New-Object System.Drawing.Size(720,36);$win.Controls.Add($title)
    $path=New-Object System.Windows.Forms.Label;$path.Text=('USB: '+$script:Usb+'   Existing game files stay exactly where they are.');$path.Location=New-Object System.Drawing.Point(22,58);$path.Size=New-Object System.Drawing.Size(970,24);$path.ForeColor=[System.Drawing.Color]::FromArgb(170,190,215);$win.Controls.Add($path)
    $sum=New-Object System.Windows.Forms.Label;$sum.Text='Scanning installed Project Eris game folders...';$sum.Location=New-Object System.Drawing.Point(22,88);$sum.Size=New-Object System.Drawing.Size(970,28);$sum.ForeColor=[System.Drawing.Color]::FromArgb(143,255,199);$win.Controls.Add($sum)
    $prog=New-Object System.Windows.Forms.ProgressBar;$prog.Location=New-Object System.Drawing.Point(22,120);$prog.Size=New-Object System.Drawing.Size(970,20);$prog.Minimum=0;$prog.Maximum=100;$prog.Value=0;$win.Controls.Add($prog)
    $grid=New-Object System.Windows.Forms.DataGridView;$grid.Location=New-Object System.Drawing.Point(22,154);$grid.Size=New-Object System.Drawing.Size(970,390);$grid.ReadOnly=$true;$grid.AllowUserToAddRows=$false;$grid.AllowUserToDeleteRows=$false;$grid.RowHeadersVisible=$false;$grid.AutoSizeColumnsMode=[System.Windows.Forms.DataGridViewAutoSizeColumnsMode]::Fill;$grid.BackgroundColor=[System.Drawing.Color]::FromArgb(14,22,43);$grid.ForeColor=[System.Drawing.Color]::Black;$grid.SelectionMode=[System.Windows.Forms.DataGridViewSelectionMode]::FullRowSelect
    [void]$grid.Columns.Add('Game','Game');[void]$grid.Columns.Add('Type','Type');[void]$grid.Columns.Add('Discs','Discs');[void]$grid.Columns.Add('Status','Status');[void]$grid.Columns.Add('Detail','Detail');$grid.Columns[0].FillWeight=30;$grid.Columns[1].FillWeight=10;$grid.Columns[2].FillWeight=7;$grid.Columns[3].FillWeight=18;$grid.Columns[4].FillWeight=35;$win.Controls.Add($grid)
    $close=New-Object System.Windows.Forms.Button;$close.Text='Close';$close.Location=New-Object System.Drawing.Point(872,562);$close.Size=New-Object System.Drawing.Size(120,36);$close.Enabled=$false;$close.Add_Click({$win.Close()});$win.Controls.Add($close)
    $openReport=New-Object System.Windows.Forms.Button;$openReport.Text='Open report';$openReport.Location=New-Object System.Drawing.Point(720,562);$openReport.Size=New-Object System.Drawing.Size(135,36);$openReport.Enabled=$false;$win.Controls.Add($openReport)
    $win.Show($form);[System.Windows.Forms.Application]::DoEvents()
    try{
        $uiTick=[Diagnostics.Stopwatch]::StartNew()
        $scanCb={param($e)if($uiTick.ElapsedMilliseconds -lt 250){return};$uiTick.Restart();$sum.Text=$e.Detail;$win.Refresh();[System.Windows.Forms.Application]::DoEvents()}.GetNewClosure()
        $scan=Get-ErisPPInstalledUsbGameScan $script:Usb $scanCb
        $rowById=@{}
        foreach($i in @($scan.Items)){$ri=$grid.Rows.Add($i.Title,$i.Type,[string]$i.DiscCount,'Found','Existing game; achievement identity not changed yet');$rowById[[string]$i.Identity]=$ri}
        foreach($i in @($scan.Issues)){[void]$grid.Rows.Add($i.Title,$i.Type,'-','Needs attention',$i.Detail)}
        if($scan.Games -eq 0){$sum.Text='No installed Project Eris games were found under the standard games folder.';$sum.ForeColor=[System.Drawing.Color]::FromArgb(255,180,120);$close.Enabled=$true;$win.Refresh();return}
        $sum.Text=('Scan complete: '+$scan.Games+' installed games; '+$scan.MultiDisc+' multi-disc; '+$scan.IssuesCount+' issue(s). Preparing genuine achievement packs...');$win.Refresh();[System.Windows.Forms.Application]::DoEvents()
        $cb={param($e)
            if($e.Total -gt 0){$v=[int](100.0*[double]$e.Current/[double]$e.Total);if($v -lt 0){$v=0};if($v -gt 100){$v=100};$prog.Value=$v}
            if($e.Identity -and $rowById.ContainsKey([string]$e.Identity)){$r=$grid.Rows[[int]$rowById[[string]$e.Identity]];$r.Cells[3].Value=$e.Status;$r.Cells[4].Value=$e.Detail}
            if($uiTick.ElapsedMilliseconds -ge 250 -or $e.Phase -eq 'DEPLOY'){$uiTick.Restart();$sum.Text=$(if($e.Title){$e.Status+': '+$e.Title+' - '+$e.Detail}else{$e.Status+' - '+$e.Detail});$win.Refresh();[System.Windows.Forms.Application]::DoEvents()}
        }.GetNewClosure()
        $r=Import-ErisPPInstalledUsbGames $script:Usb $script:Lib $scan $cb
        $prog.Value=100;$sum.Text=('Done: '+$r.Linked+' newly linked; '+$r.Updated+' existing identities updated; '+$r.Ready+' achievement-ready; '+$r.NoSet+' no-set; '+$r.Blocked+' without a usable pack. No game files were copied.');$close.Enabled=$true;$openReport.Enabled=$true;$reportPath=$r.Report;$openReport.Add_Click({if(Test-Path $reportPath){Start-Process notepad.exe $reportPath}});$script:Lib=Get-Library;Set-Status ('Existing USB import complete: '+$r.Ready+' achievement-ready, '+$r.Blocked+' unavailable.');$win.Refresh()
    }catch{$sum.Text=('ERROR: '+$_.Exception.Message);$sum.ForeColor=[System.Drawing.Color]::FromArgb(255,116,130);$close.Enabled=$true;$win.Refresh();Set-Status $_.Exception.Message $true}
}

function Render-Dashboard {
    $panel.Controls.Clear();$back.Visible=$false;$next.Visible=$false
    $script:Usb=Find-ErisUsb
    if(!$script:Usb){Label 'Project Eris ++ Manager' 24 18 780 36 15 $true|Out-Null;Label 'Insert your Project Eris USB drive to manage games or achievements.' 24 75 760 50|Out-Null;$b=Button 'Scan again' 24 145 180 42;$b.Add_Click({Render-Dashboard});Set-Status 'No Project Eris USB drive found.' $true;return}
    $script:Lib=Get-Library;[void](Seed-ErisPPAchievementLibraryFromUsb $script:Usb);Sync-InternalExport $script:Usb $script:Lib|Out-Null;$c=Pack-Counts
    Label 'Project Eris ++ Manager' 24 18 780 36 15 $true|Out-Null
    Label ("USB: $script:Usb     Profile: $(Profile-NameFromUsb)") 24 62 790 30|Out-Null
    Label ("Library: $(@($script:Lib.games).Count) games - Ready/Partial $($c[0]) - Pack needed $($c[1]) - No set $($c[2])") 24 96 800 30|Out-Null
    $fbPending=Test-Path (Join-Path (Eris-Root $script:Usb) 'etc\erispp\runtime\FIRST_BOOT_EXPORT_PENDING.flag');$fbComplete=Test-Path (Join-Path $script:Usb 'PROJECT_ERIS_PP_INTERNAL_EXPORT\EXPORT_COMPLETE.txt');$fbText=if($fbComplete){'Internal 20: complete; temporary copy app should be removed'}elseif($fbPending){'Internal 20: automatic export is ready for the next console boot'}else{'Internal 20: export is not complete yet'};Label $fbText 24 122 790 24 9 $false|Out-Null
    $add=Button 'Add game(s) + FDB' 24 165 245 46
    $sync=Button 'Sync achievements' 288 165 255 46
    $repair=Button 'Repair installation' 562 165 235 46
    $reset=Button 'Open Reset Lab' 24 230 245 46
    $internal=Button 'Reprocess Internal 20' 288 230 255 46
    $folder=Button 'Open Project Eris ++ data' 562 230 235 46
    $cache=Button 'Import RA cache' 24 295 245 46
    $harvest=Button 'Repair achievement packs' 288 295 255 46
    $library=Button 'Import complete library' 562 295 235 46
    $existingUsb=Button 'Import installed USB games' 24 360 285 46;$existingUsb.BackColor=[System.Drawing.Color]::FromArgb(108,224,255);$existingUsb.ForeColor=[System.Drawing.Color]::FromArgb(6,25,40);$existingUsb.FlatAppearance.BorderColor=[System.Drawing.Color]::FromArgb(108,224,255)
    Label 'Adds achievements to games already installed by Project Eris. Existing game images are never copied or moved.' 325 362 475 42 8 $false|Out-Null
    $modeLabel=Label 'Performance mode' 24 425 150 26 9 $true
    $modeBox=New-Object System.Windows.Forms.ComboBox;$modeBox.DropDownStyle=[System.Windows.Forms.ComboBoxStyle]::DropDownList;$modeBox.Location=New-Object System.Drawing.Point(160,421);$modeBox.Size=New-Object System.Drawing.Size(150,30);[void]$modeBox.Items.AddRange(@('Fast','Verify','Full rebuild'));$modeBox.SelectedItem=Get-ErisPPPerformanceMode;$modeBox.Add_SelectedIndexChanged({param($sender,$eventArgs);if($null -ne $sender -and $null -ne $sender.SelectedItem){$selected=[string]$sender.SelectedItem;[void](Set-ErisPPPerformanceMode $selected);Set-Status ('Performance mode: '+$selected)}});$panel.Controls.Add($modeBox)
    $perf=Get-ErisPPPerformanceSummary;Label (('Last: '+$perf.Action+' - '+$perf.Seconds+'s - rebuilt '+$perf.Rebuilt+' - skipped '+$perf.Skipped)) 325 423 485 30 9 $false|Out-Null
    $add.Add_Click({$o=New-Object System.Windows.Forms.OpenFileDialog;$o.Title='Select your PS1 image(s)';$o.Filter='PS1 images|*.cue;*.pbp;*.chd;*.iso;*.m3u|All files|*.*';$o.Multiselect=$true;if($o.ShowDialog() -eq 'OK'){try{Set-Status 'Achievement preflight: checking local cache, harvesting with DuckStation if needed, then building and validating the FDB...';$r=Add-GameFiles $script:Usb $o.FileNames $script:Lib;$msg="Added: $($r.Added)  -  Already present: $($r.AlreadyPresent)  -  Achievement-ready: $($r.Ready)  -  No set: $($r.NoSet)  -  Blocked: $($r.Blocked)`r`n`r`nReport: $($r.Report)";if($r.Blocked -gt 0){[System.Windows.Forms.MessageBox]::Show($msg+'`r`n`r`nBlocked games were NOT copied to transfer. This prevents games from being transferred without a genuine FDB.','Add game')|Out-Null};Set-Status "$($r.Added) game(s) added FDB-first; $($r.AlreadyPresent) already present; $($r.Blocked) blocked.";Render-Dashboard}catch{[System.Windows.Forms.MessageBox]::Show($_.Exception.Message,'Add game')}}})
    $library.Add_Click({Invoke-LibraryImportUi})
    $existingUsb.Add_Click({Invoke-ExistingUsbImportUi})
    $sync.Add_Click({try{Set-Status ('Synchronizing in '+(Get-ErisPPPerformanceMode)+' mode...');Import-ExistingCompiledPacks $script:Lib|Out-Null;$n=Compile-AvailablePacks $script:Lib;Deploy-StagedOnly $script:Usb $script:Lib;Set-Status "$n pack(s) rebuilt/compiled.";Render-Dashboard}catch{[System.Windows.Forms.MessageBox]::Show($_.Exception.Message,'Synchronization error')}})
    $repair.Add_Click({try{if([System.Windows.Forms.MessageBox]::Show('Reinstall Project Eris ++ over the existing installation? Unlocks and saves will be preserved.','Repair',[System.Windows.Forms.MessageBoxButtons]::YesNo) -eq 'Yes'){Set-Status 'Repairing installation...';Deploy-ProjectErisPP $script:Usb (Profile-NameFromUsb) $script:Lib|Out-Null;Set-Status 'Installation repaired.'}}catch{[System.Windows.Forms.MessageBox]::Show($_.Exception.Message,'Repair error')}})
    $reset.Add_Click({Start-Process powershell.exe -ArgumentList ('-NoProfile -ExecutionPolicy Bypass -File "'+(Join-Path $PSScriptRoot 'ProjectErisPlusPlus.ResetLab.ps1')+'"')})
    $internal.Add_Click({try{$n=Sync-InternalExport $script:Usb $script:Lib;Import-ExistingCompiledPacks $script:Lib|Out-Null;Compile-AvailablePacks $script:Lib|Out-Null;Deploy-StagedOnly $script:Usb $script:Lib;Set-Status "$n internal slots synchronized again.";Render-Dashboard}catch{[System.Windows.Forms.MessageBox]::Show($_.Exception.Message,'Internal 20')}})
    $folder.Add_Click({Start-Process explorer.exe $script:AppRoot})
    $harvest.Add_Click({Start-Process powershell.exe -ArgumentList ('-NoProfile -ExecutionPolicy Bypass -File "'+(Join-Path $PSScriptRoot 'ProjectErisPlusPlus.AchievementRepair.ps1')+'"')})
    $cache.Add_Click({$o=New-Object System.Windows.Forms.FolderBrowserDialog;$o.Description='Select an existing RAIntegration/RACache folder containing achievement JSON files';if($o.ShowDialog() -eq 'OK'){try{Set-Status 'Importing and compiling RA cache...';$n=Import-RawCacheFolder $o.SelectedPath;$built=Compile-AvailablePacks $script:Lib;Deploy-StagedOnly $script:Usb $script:Lib;Set-Status "$n cache file(s) imported; $built pack(s) compiled.";Render-Dashboard}catch{[System.Windows.Forms.MessageBox]::Show($_.Exception.Message,'Import RA cache')}}})
    Set-Status 'Project Eris ++ is ready. You can import a complete library recursively.'
}

$back.Add_Click({if($script:Step -gt 1){$script:Step--;Render-Initial}})
$next.Add_Click({
    if($script:Step -eq 1){$script:Step=2;Render-Initial;return}
    if($script:Step -eq 2){$tb=$panel.Controls['ProfileBox'];if($null -eq $tb -or [string]::IsNullOrWhiteSpace($tb.Text)){[System.Windows.Forms.MessageBox]::Show('Enter a profile name.','Project Eris ++');return};Write-Profile $tb.Text;$script:Step=3;Render-Initial;return}
})

if($script:Initial){Render-Initial}else{Render-Dashboard}
[void]$form.ShowDialog()
