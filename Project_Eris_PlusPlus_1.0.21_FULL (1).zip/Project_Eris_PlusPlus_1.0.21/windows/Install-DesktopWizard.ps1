﻿$ErrorActionPreference='Stop'
$packageRoot=Split-Path -Parent $PSScriptRoot
$desk=[Environment]::GetFolderPath('Desktop')
$ws=New-Object -ComObject WScript.Shell
$link=Join-Path $desk 'Project Eris ++.lnk'
$s=$ws.CreateShortcut($link)
$s.TargetPath='powershell.exe'
$s.Arguments='-NoLogo -NoProfile -ExecutionPolicy Bypass -File "'+(Join-Path $PSScriptRoot 'ProjectErisPlusPlus.SimpleWizard.ps1')+'"'
$s.WorkingDirectory=$PSScriptRoot
$s.Description='Project Eris ++'
$icon=Join-Path $packageRoot 'assets\projecterispp.ico';if(Test-Path $icon){$s.IconLocation=$icon}
$s.Save()
foreach($n in @('Project Eris ++ Wizard.lnk','Project Eris ++ Reset Lab.lnk')){$old=Join-Path $desk $n;if(Test-Path $old){Remove-Item $old -Force -ErrorAction SilentlyContinue}}
Start-Process powershell.exe -ArgumentList ('-NoLogo -NoProfile -ExecutionPolicy Bypass -File "'+(Join-Path $PSScriptRoot 'ProjectErisPlusPlus.SimpleWizard.ps1')+'"')
