﻿$ErrorActionPreference='Stop'
Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing
[System.Windows.Forms.Application]::EnableVisualStyles()
. (Join-Path $PSScriptRoot 'ProjectErisPlusPlus.Core.ps1')

$C_BG=[System.Drawing.Color]::FromArgb(8,15,30)
$C_HEADER=[System.Drawing.Color]::FromArgb(11,23,45)
$C_CARD=[System.Drawing.Color]::FromArgb(16,29,52)
$C_CARD2=[System.Drawing.Color]::FromArgb(20,36,62)
$C_TEXT=[System.Drawing.Color]::FromArgb(235,242,250)
$C_MUTED=[System.Drawing.Color]::FromArgb(156,177,202)
$C_ACCENT=[System.Drawing.Color]::FromArgb(108,224,255)
$C_ACCENT_DARK=[System.Drawing.Color]::FromArgb(20,145,184)
$C_GOOD=[System.Drawing.Color]::FromArgb(103,232,172)
$C_WARN=[System.Drawing.Color]::FromArgb(255,190,105)
$C_BAD=[System.Drawing.Color]::FromArgb(255,112,128)
$C_BORDER=[System.Drawing.Color]::FromArgb(42,64,92)

function New-Label([string]$Text,[int]$X,[int]$Y,[int]$W,[int]$H,[int]$Size=10,[bool]$Bold=$false,[System.Drawing.Color]$Color=$C_TEXT,[System.Windows.Forms.Control]$Parent=$form){
    $l=New-Object System.Windows.Forms.Label
    $l.Text=$Text;$l.Location=New-Object System.Drawing.Point($X,$Y);$l.Size=New-Object System.Drawing.Size($W,$H)
    $l.ForeColor=$Color;$l.BackColor=[System.Drawing.Color]::Transparent
    $style=if($Bold){[System.Drawing.FontStyle]::Bold}else{[System.Drawing.FontStyle]::Regular}
    $l.Font=New-Object System.Drawing.Font('Segoe UI',$Size,$style)
    $Parent.Controls.Add($l);return $l
}
function New-Card([int]$X,[int]$Y,[int]$W,[int]$H,[System.Windows.Forms.Control]$Parent=$form){
    $p=New-Object System.Windows.Forms.Panel;$p.Location=New-Object System.Drawing.Point($X,$Y);$p.Size=New-Object System.Drawing.Size($W,$H)
    $p.BackColor=$C_CARD;$p.BorderStyle=[System.Windows.Forms.BorderStyle]::FixedSingle;$Parent.Controls.Add($p);return $p
}
function Style-Button($b,[bool]$Primary=$false){
    $b.FlatStyle=[System.Windows.Forms.FlatStyle]::Flat;$b.FlatAppearance.BorderSize=1;$b.Cursor=[System.Windows.Forms.Cursors]::Hand
    $b.Font=New-Object System.Drawing.Font('Segoe UI',10,[System.Drawing.FontStyle]::Bold)
    if($Primary){$b.BackColor=$C_ACCENT;$b.ForeColor=[System.Drawing.Color]::FromArgb(6,25,40);$b.FlatAppearance.BorderColor=$C_ACCENT}
    else{$b.BackColor=$C_CARD2;$b.ForeColor=$C_TEXT;$b.FlatAppearance.BorderColor=$C_BORDER}
    return $b
}
function New-Button([string]$Text,[int]$X,[int]$Y,[int]$W,[int]$H,[System.Windows.Forms.Control]$Parent,[bool]$Primary=$false){
    $b=New-Object System.Windows.Forms.Button;$b.Text=$Text;$b.Location=New-Object System.Drawing.Point($X,$Y);$b.Size=New-Object System.Drawing.Size($W,$H)
    [void](Style-Button $b $Primary);$Parent.Controls.Add($b);return $b
}
function Set-Dot($Dot,[string]$State){
    if($State -eq 'good'){$Dot.BackColor=$C_GOOD}elseif($State -eq 'warn'){$Dot.BackColor=$C_WARN}else{$Dot.BackColor=$C_BAD}
}

$form=New-Object System.Windows.Forms.Form
$form.Text='Project Eris ++ 1.0.21'
$form.StartPosition='CenterScreen'
$form.Size=New-Object System.Drawing.Size(930,660)
$form.MinimumSize=$form.Size;$form.MaximumSize=$form.Size
$form.BackColor=$C_BG;$form.ForeColor=$C_TEXT;$form.Font=New-Object System.Drawing.Font('Segoe UI',10)
$form.FormBorderStyle=[System.Windows.Forms.FormBorderStyle]::FixedSingle;$form.MaximizeBox=$false
$icon=Join-Path (Split-Path -Parent $PSScriptRoot) 'assets\projecterispp.ico';if(Test-Path $icon){try{$form.Icon=New-Object System.Drawing.Icon -ArgumentList $icon}catch{}}

$hero=New-Object System.Windows.Forms.Panel;$hero.Location=New-Object System.Drawing.Point(0,0);$hero.Size=New-Object System.Drawing.Size(930,100);$hero.BackColor=$C_HEADER;$form.Controls.Add($hero)
[void](New-Label 'PROJECT ERIS ++' 28 18 470 42 26 $true $C_ACCENT $hero)
[void](New-Label 'PlayStation Classic enhancement and achievement toolkit' 31 61 520 24 10 $false $C_MUTED $hero)
$version=New-Label 'VERSION 1.0.21' 760 27 130 28 9 $true $C_ACCENT $hero;$version.TextAlign=[System.Drawing.ContentAlignment]::MiddleCenter;$version.BackColor=$C_CARD2;$version.BorderStyle=[System.Windows.Forms.BorderStyle]::FixedSingle

$left=New-Card 24 120 560 450
[void](New-Label 'SYSTEM STATUS' 22 18 240 28 11 $true $C_TEXT $left)
[void](New-Label 'Project Eris ++ checks the connected USB drive and optional achievement harvesting tools.' 22 47 500 42 9 $false $C_MUTED $left)

function New-StatusRow([string]$Name,[int]$Y){
    $dot=New-Object System.Windows.Forms.Panel;$dot.Location=New-Object System.Drawing.Point(24,$Y+7);$dot.Size=New-Object System.Drawing.Size(12,12);$dot.BackColor=$C_WARN;$left.Controls.Add($dot)
    [void](New-Label $Name 50 $Y 140 28 10 $true $C_TEXT $left)
    $value=New-Label 'Checking...' 190 $Y 335 42 9 $false $C_MUTED $left
    return @($dot,$value)
}
$usbRow=New-StatusRow 'Project Eris USB' 104;$usbDot=$usbRow[0];$usbValue=$usbRow[1]
$duckRow=New-StatusRow 'DuckStation' 158;$duckDot=$duckRow[0];$duckValue=$duckRow[1]
$raRow=New-StatusRow 'RAIntegration' 212;$raDot=$raRow[0];$raValue=$raRow[1]

[void](New-Label 'PROFILE' 22 280 120 24 9 $true $C_MUTED $left)
$profile=New-Object System.Windows.Forms.TextBox;$profile.Location=New-Object System.Drawing.Point(24,310);$profile.Size=New-Object System.Drawing.Size(500,31);$profile.Font=New-Object System.Drawing.Font('Segoe UI',11);$profile.BackColor=[System.Drawing.Color]::FromArgb(235,241,247);$profile.ForeColor=[System.Drawing.Color]::FromArgb(20,32,48);$profile.BorderStyle=[System.Windows.Forms.BorderStyle]::FixedSingle;$profile.Text=Get-ProfileName;$left.Controls.Add($profile)
[void](New-Label 'Used for local Achievement Hub progress. Existing saves and achievement data are preserved during normal upgrades.' 24 350 500 42 8 $false $C_MUTED $left)
$progress=New-Object System.Windows.Forms.ProgressBar;$progress.Location=New-Object System.Drawing.Point(24,410);$progress.Size=New-Object System.Drawing.Size(500,8);$progress.Style=[System.Windows.Forms.ProgressBarStyle]::Marquee;$progress.MarqueeAnimationSpeed=22;$progress.Visible=$false;$left.Controls.Add($progress)

$right=New-Card 604 120 296 450
[void](New-Label 'ACTIONS' 22 18 170 28 11 $true $C_TEXT $right)
[void](New-Label 'Use the primary action for a new install or an in-place upgrade.' 22 47 248 42 9 $false $C_MUTED $right)
$install=New-Button 'INSTALL / UPGRADE' 22 105 250 56 $right $true
$manager=New-Button 'OPEN MANAGER' 22 176 250 44 $right $false
$refresh=New-Button 'SCAN AGAIN' 22 232 250 40 $right $false
$guide=New-Button 'SETUP GUIDE' 22 284 250 40 $right $false
$readme=New-Button 'README' 22 336 250 40 $right $false
$close=New-Button 'CLOSE' 22 388 250 40 $right $false

$statusPanel=New-Object System.Windows.Forms.Panel;$statusPanel.Location=New-Object System.Drawing.Point(24,588);$statusPanel.Size=New-Object System.Drawing.Size(876,38);$statusPanel.BackColor=$C_HEADER;$statusPanel.BorderStyle=[System.Windows.Forms.BorderStyle]::FixedSingle;$form.Controls.Add($statusPanel)
$statusDot=New-Object System.Windows.Forms.Panel;$statusDot.Location=New-Object System.Drawing.Point(14,13);$statusDot.Size=New-Object System.Drawing.Size(10,10);$statusDot.BackColor=$C_WARN;$statusPanel.Controls.Add($statusDot)
$status=New-Label 'Scanning your system...' 36 7 820 24 9 $true $C_MUTED $statusPanel

$script:Usb=$null
function Set-SimpleStatus([string]$Text,[string]$State='good'){$status.Text=$Text;if($State -eq 'bad'){$status.ForeColor=$C_BAD;Set-Dot $statusDot 'bad'}elseif($State -eq 'warn'){$status.ForeColor=$C_WARN;Set-Dot $statusDot 'warn'}else{$status.ForeColor=$C_GOOD;Set-Dot $statusDot 'good'};$form.Refresh()}
function Read-UsbProfile([string]$Usb){if(!$Usb){return (Get-ProfileName)};$p=Join-Path (Eris-Root $Usb) 'etc\erispp\profiles\active\profile.tsv';if(Test-Path $p){foreach($line in Get-Content $p){$f=$line -split "`t",2;if($f.Count -eq 2 -and $f[0] -eq 'display'){return $f[1]}}};return (Get-ProfileName)}
function Update-Prerequisites {
    $duck=Find-ErisPPDuckStationExe
    if($duck){Set-Dot $duckDot 'good';$duckValue.Text="FOUND`r`n"+$duck;$duckValue.ForeColor=$C_GOOD;$dll=Join-Path (Split-Path $duck -Parent) 'RA_Integration.dll';if(Test-Path $dll){Set-Dot $raDot 'good';$raValue.Text='FOUND - genuine achievement harvesting is ready';$raValue.ForeColor=$C_GOOD}else{Set-Dot $raDot 'warn';$raValue.Text='NOT FOUND next to DuckStation - see Setup Guide';$raValue.ForeColor=$C_WARN}}
    else{Set-Dot $duckDot 'warn';$duckValue.Text='NOT FOUND - optional unless an uncached achievement pack is needed';$duckValue.ForeColor=$C_WARN;Set-Dot $raDot 'warn';$raValue.Text='Not checked because DuckStation was not found';$raValue.ForeColor=$C_WARN}
}
function Scan-Usb {
    Update-Prerequisites
    $script:Usb=Find-ErisUsb
    if(!$script:Usb){Set-Dot $usbDot 'bad';$usbValue.Text='NOT FOUND - connect a working Project Eris USB drive';$usbValue.ForeColor=$C_BAD;$install.Enabled=$false;$manager.Enabled=$false;Set-SimpleStatus 'Connect your Project Eris USB drive, then choose Scan Again.' 'bad';return}
    Set-Dot $usbDot 'good';$usbValue.Text='FOUND - '+$script:Usb;$usbValue.ForeColor=$C_GOOD;$profile.Text=Read-UsbProfile $script:Usb
    $installed=Test-Path (Join-Path $script:Usb 'PROJECT_ERIS_PP_INSTALL.txt');$manager.Enabled=$installed;$install.Enabled=$true
    if($installed){Set-SimpleStatus 'Project Eris ++ detected. Upgrade/repair is ready, or open the Manager.' 'good'}else{Set-SimpleStatus 'Project Eris base installation detected. Ready to install Project Eris ++.' 'good'}
}
$refresh.Add_Click({Scan-Usb})
$manager.Add_Click({Start-Process powershell.exe -ArgumentList ('-NoLogo -NoProfile -ExecutionPolicy Bypass -File "'+(Join-Path $PSScriptRoot 'ProjectErisPlusPlus.Wizard.ps1')+'"')})
$guide.Add_Click({$g=Join-Path (Split-Path -Parent $PSScriptRoot) 'README_SETUP_EN.txt';if(Test-Path $g){Start-Process notepad.exe $g}})
$readme.Add_Click({$g=Join-Path (Split-Path -Parent $PSScriptRoot) 'README.md';if(Test-Path $g){Start-Process notepad.exe $g}})
$close.Add_Click({$form.Close()})
$install.Add_Click({
    try{
        Scan-Usb;if(!$script:Usb){return};if([string]::IsNullOrWhiteSpace($profile.Text)){[System.Windows.Forms.MessageBox]::Show('Enter a profile name.','Project Eris ++')|Out-Null;return}
        $install.Enabled=$false;$refresh.Enabled=$false;$manager.Enabled=$false;$progress.Visible=$true;Set-SimpleStatus 'Installing Project Eris ++. Please wait...' 'warn'
        $checks=@(Test-Preflight $script:Usb|Where-Object{!$_.OK});if($checks.Count -gt 0){throw 'The Project Eris USB drive did not pass the installation check.'}
        $lib=Get-Library;[void](Deploy-ProjectErisPP $script:Usb $profile.Text $lib);Set-ErisPPPerformanceMode 'Fast'|Out-Null
        Set-SimpleStatus 'Installation complete. Safely eject the USB drive before using the PlayStation Classic.' 'good';$manager.Enabled=$true
        [System.Windows.Forms.MessageBox]::Show('Project Eris ++ installation completed successfully.','Project Eris ++')|Out-Null
    }catch{Set-SimpleStatus $_.Exception.Message 'bad';[System.Windows.Forms.MessageBox]::Show($_.Exception.Message,'Project Eris ++ Setup')|Out-Null}
    finally{$progress.Visible=$false;$install.Enabled=$true;$refresh.Enabled=$true}
})
Scan-Usb
[void]$form.ShowDialog()
