﻿$ErrorActionPreference='Stop'
Set-StrictMode -Version Latest
. (Join-Path $PSScriptRoot 'ProjectErisPlusPlus.Core.ps1')
function Copy-CumulativeTree([string]$Source,[string]$Destination){if(!(Test-Path $Source)){throw "Missing package path: $Source"};Copy-Tree $Source $Destination}
try{
    $usb=Find-ErisUsb;if(!$usb){throw 'No Project Eris USB drive found. Insert the USB drive and try again.'};$eris=Eris-Root $usb
    Write-Host 'Project Eris ++ v1.0.21 Existing USB Achievement Import + Windows Installer Update' -ForegroundColor Cyan;Write-Host "USB: $usb"
    [void](Test-ErisPPCacheSchemaCompatibility);Write-Host 'Achievement cache schema self-test: OK' -ForegroundColor Green
    $stamp=Get-Date -Format 'yyyyMMdd_HHmmss';$backup=Join-Path $usb "project_eris\backup\erispp_v119_$stamp";New-Item -ItemType Directory -Force -Path $backup|Out-Null;Write-Host "Backup: $backup"
    $exporterClean=Clear-ErisPPFirstBootExportPermanent $usb 'v1.0.21-in-place-update'
    if(!$exporterClean){throw 'Permanent first-boot exporter cleanup failed. The update stopped before continuing.'}
    Write-Host 'First-boot exporter permanently removed; retry is disabled.' -ForegroundColor Green
    Configure-RetroArch $usb $backup
    $root=Join-Path $eris 'etc\erispp';$runtime=Join-Path $root 'runtime';New-Item -ItemType Directory -Force -Path $root,$runtime,(Join-Path $root 'state'),(Join-Path $root 'profiles\active')|Out-Null
    foreach($legacy in @('erispp_audio_prepare.sh','erispp_unlock_audio.sh','erispp_audio_once.sh','erispp_dsp.so','TEST_AUDIO.flag','TEST_AUDIO_DSP.flag','PLAY_CHIME.flag')){Remove-Item (Join-Path $runtime $legacy) -Force -ErrorAction SilentlyContinue}
    Copy-CumulativeTree (Join-Path $script:PackageRoot 'console\runtime') $runtime;Copy-CumulativeTree (Join-Path $script:PackageRoot 'console\launcher') (Join-Path $eris 'SUP\launchers\projecterispp')
    Remove-Item (Join-Path $runtime 'erispp_firstboot_export.sh') -Force -ErrorAction SilentlyContinue
    foreach($shellRoot in @($runtime,(Join-Path $eris 'SUP\launchers\projecterispp'))){if(Test-Path $shellRoot){foreach($sh in Get-ChildItem $shellRoot -Recurse -Filter '*.sh' -File -ErrorAction SilentlyContinue){Write-LF $sh.FullName (Get-Content $sh.FullName -Raw)}}}
    $raLaunch=Join-Path $eris 'SUP\scripts\ra_launch.sh';Backup-One $raLaunch $usb $backup;Patch-RaLaunch $raLaunch
    $firstBootMode='PERMANENTLY_REMOVED'

    $repair=Repair-ErisPPUniqueProgress $usb
    $lib=Get-Library
    $seeded=Seed-ErisPPAchievementLibraryFromUsb $usb
    $catalog=Refresh-ErisPPAchievementLibraryCatalog
    [void](Sync-InternalExport $usb $lib)
    $legacy=Import-ExistingCompiledPacks $lib
    $compiled=Compile-AvailablePacks $lib

    # Preserve already installed game identities that are not in the local library, but never add the same RA ID twice.
    $usbGames=Join-Path $root 'ui\games.tsv'
    if(Test-Path $usbGames){
        $known=@{};foreach($g in @($lib.games)){$gid=0;try{$gid=[int]$g.RaId}catch{};if($gid -gt 0){$known[$gid]=$true}}
        foreach($line in Get-Content $usbGames){$f=$line -split "`t",6;if($f.Count -ge 2){$gid=0;try{$gid=[int]$f[0]}catch{};if($gid -gt 0 -and !$known.ContainsKey($gid)){$lib.games+= [pscustomobject]@{Key=('installed:'+$gid);Source='USB';Slot=0;Title=$f[1];Path='';RaId=$gid;OfficialSet='SET';PackStatus='Ready';Supported=0;Total=0};$known[$gid]=$true}}}
    }
    Save-Library $lib;Build-Indexes $lib

    # Deploy once. The performance override copies only changed FDB/UI files and syncs only changed badge sets.
    $badgeLinked=Deploy-StagedOnly $usb $lib
    $perf=Get-ErisPPPerformanceSummary

    Remove-Item (Join-Path $usb 'PROJECT_ERIS_PP_DSP.log') -Force -ErrorAction SilentlyContinue
    Remove-Item (Join-Path $usb 'PROJECT_ERIS_PP_AUDIO.log') -Force -ErrorAction SilentlyContinue
    Remove-Item (Join-Path $usb 'PROJECT_ERIS_PP_AUDIO_BRIDGE.log') -Force -ErrorAction SilentlyContinue
    Remove-Item (Join-Path $runtime 'TEST_AUDIO_BRIDGE.flag') -Force -ErrorAction SilentlyContinue
    $bridge=Join-Path $runtime 'erispp_audio_bridge.so';if(!(Test-Path $bridge)){throw 'Audio bridge is missing after copying.'};$bridgeHash=(Get-FileHash $bridge -Algorithm SHA256).Hash.ToLowerInvariant()
    Install-PCShortcuts

    $marker=Join-Path $usb 'PROJECT_ERIS_PP_1.0.21_UPDATE.txt'
    @(
        'Project Eris ++ 1.0.21 Existing USB Achievement Import + Windows Installer Full Pack',
        ('Applied='+(Get-Date -Format o)),('USB='+$usb),('Backup='+$backup),
        'Evaluator=v1.0.5 proven live evaluator retained byte-for-byte',
        'Popup=RetroArch OSD forced top-left',
        'Audio=LD_PRELOAD in-process ALSA write bridge; no DSP/dmix/aplay',
        ('AudioBridgeSHA256='+$bridgeHash),
        ('AchievementLibrarySeededFDB='+$seeded),('AchievementLibraryRawImported='+$catalog),('PacksImported='+$legacy),('PacksCompiled='+$compiled),('BadgesLinked='+$badgeLinked),
        'AchievementIdentity=one visible game per RA game ID',
        'AchievementXpPolicy=unique game ID plus unique achievement ID; duplicate rows never multiply progress',
        ('StateDuplicatesRemoved='+$repair.StateDuplicatesRemoved),('PlayedDuplicatesRemoved='+$repair.PlayedDuplicatesRemoved),('HistoryDuplicatesRemoved='+$repair.HistoryDuplicatesRemoved),
        'AddGamePolicy=FDB-first; identical installed launch mappings are reused; aliases share one RA-ID achievement identity',
        'LibraryImport=recursive M3U-first CUE-aware auto-multidisc with status UI',
        'ExistingUsbImport=scan standard Project Eris games folders; link genuine achievement packs in place; never copy or move existing game images',
        ('InternalExportFirstBoot='+$firstBootMode),
        ('ExporterPermanentCleanup='+$exporterClean),
        'ExporterRetryPolicy=disabled',
        'FirstInstallSpacePreflight=14.0 GiB minimum before any first-boot exporter staging',
        'CacheSchema=missing per-set Achievements property is safely skipped; genuine top-level/core data retained',
        ('PerformanceMode='+(Get-ErisPPPerformanceMode)),('PerformanceLastAction='+$perf.Action),('PerformanceLastSeconds='+$perf.Seconds),
        'SaveStateBridge=native RetroArch save-on-exit + explicit resume LOAD_STATE + non-destructive stock mirror',
        'SaveStatePreview=single exit-time savestate thumbnail mirrored to Carousel; no periodic SCREENSHOT commands',
        'SaveStatePolicy=exit-only; no periodic SAVE_STATE or SCREENSHOT commands during gameplay',
        'StateAndSavesPreserved=True'
    )|Set-Content $marker -Encoding ASCII
    Write-Host '';Write-Host 'DONE.' -ForegroundColor Green
    Write-Host ('Performance mode: '+(Get-ErisPPPerformanceMode))
    Write-Host ('Duplicate progress repaired: state='+$repair.StateDuplicatesRemoved+', played='+$repair.PlayedDuplicatesRemoved+', history='+$repair.HistoryDuplicatesRemoved)
    Write-Host 'Achievement Hub identity is now canonical by RetroAchievements game ID.'
    Write-Host 'Unchanged FDB packs, badges and USB files are skipped in Fast mode.'
    Write-Host 'Save-state bridge: exit-only native autosave; no periodic snapshots/screenshots during gameplay.'
    Write-Host ('Internal 20 first-boot mode: '+$firstBootMode+'.')
    Write-Host 'The old menu/hidden exporter, pending flags, cleanup residue and first-boot shim state are permanently removed.'
}catch{Write-Host '';Write-Host ('ERROR: '+$_.Exception.Message) -ForegroundColor Red;Write-Host $_.ScriptStackTrace;exit 1}
