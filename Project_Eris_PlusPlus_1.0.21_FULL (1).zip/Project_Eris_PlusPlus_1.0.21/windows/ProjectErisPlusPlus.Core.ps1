﻿$ErrorActionPreference='Stop'
Set-StrictMode -Version Latest
$script:PackageRoot=Split-Path -Parent $PSScriptRoot
$script:AppRoot=Join-Path $env:LOCALAPPDATA 'ProjectErisPlusPlus'
$script:RawCache=Join-Path $script:AppRoot 'RawCache'
$script:StageRoot=Join-Path $script:AppRoot 'Staging'
$script:ProfileRoot=Join-Path $script:AppRoot 'Profile'
$script:LibraryFile=Join-Path $script:AppRoot 'library.json'
$script:AchievementLibrary=Join-Path $script:AppRoot 'achievement_library'
$script:AchievementRaw=Join-Path $script:AchievementLibrary 'raw'
$script:AchievementCompiled=Join-Path $script:AchievementLibrary 'compiled'
$script:CacheTitleIndex=$null
$script:InternalExportMinimumFreeBytes=[int64]15032385536 # 14 GiB; exceeds the measured Internal 20 payload plus console-side reserve.
$script:InternalExportMinimumFreeGiB=14.0
New-Item -ItemType Directory -Force -Path $script:AppRoot,$script:RawCache,$script:StageRoot,$script:ProfileRoot,$script:AchievementLibrary,$script:AchievementRaw,(Join-Path $script:AchievementCompiled 'database'),(Join-Path $script:AchievementCompiled 'ui\games'),(Join-Path $script:AchievementCompiled 'ui\badges')|Out-Null
. (Join-Path $PSScriptRoot 'ProjectErisPlusPlus.RichCompiler.ps1')
function Write-LF([string]$Path,[string]$Text){$Text=$Text -replace "`r`n","`n";[IO.File]::WriteAllText($Path,$Text,(New-Object Text.UTF8Encoding($false)))}
function Safe([string]$s){if($null -eq $s){return ''};$s=$s -replace "`t|`r|`n",' ';return (($s -replace '[^ -~]','?' -replace '\s+',' ').Trim())}
function Normalize-Title([string]$s){if(!$s){return ''};return ((Safe $s).ToLowerInvariant() -replace '\([^)]*\)','' -replace '\[[^]]*\]','' -replace '(disc|disk)\s*\d+','' -replace '\bv\d+(?:\.\d+)*\b','' -replace '[^a-z0-9]+','')}
function Get-ErisPPPropertyValue($Object,[string]$Name){
    if($null -eq $Object -or [string]::IsNullOrWhiteSpace($Name)){return $null}
    $prop=$Object.PSObject.Properties[$Name]
    if($null -eq $prop){return $null}
    return $prop.Value
}
function Get-ErisPPGameIdFromCache($Cache){
    foreach($name in @('GameId','GameID','ID')){
        $v=Get-ErisPPPropertyValue $Cache $name
        if($null -ne $v){try{$id=[int]$v;if($id -gt 0){return $id}}catch{}}
    }
    return 0
}
function Test-ErisPPRawCacheObject($Cache){
    if((Get-ErisPPGameIdFromCache $Cache) -le 0){return $false}
    $sets=Get-ErisPPPropertyValue $Cache 'Sets'
    $top=Get-ErisPPPropertyValue $Cache 'Achievements'
    return ($null -ne $sets -or $null -ne $top)
}
function Get-StableLocalId([string]$Key){
    $sha=[Security.Cryptography.SHA256]::Create()
    try{$h=$sha.ComputeHash([Text.Encoding]::UTF8.GetBytes(([string]$Key).ToLowerInvariant()))}finally{$sha.Dispose()}
    $u=[BitConverter]::ToUInt32($h,0)
    return [int](1500000000+($u%400000000))
}
function Test-LocalGameId([int]$Id){return ($Id -ge 1500000000)}
function Get-CacheRoots{
    $roots=New-Object System.Collections.ArrayList
    foreach($p in @(
        $script:RawCache,
        (Join-Path $PSScriptRoot 'bundled_cache'),
        (Join-Path $env:LOCALAPPDATA 'ProjectErisPlusPlus\Worker\RACache\Data'),
        (Join-Path $env:LOCALAPPDATA 'ProjectErisPlusPlus\achievement_library'),
        (Join-Path $env:LOCALAPPDATA 'DuckStation\RACache'),
        (Join-Path $env:APPDATA 'DuckStation\RACache'),
        (Join-Path $env:LOCALAPPDATA 'RALibretro\RACache'),
        (Join-Path $env:LOCALAPPDATA 'RAIntegration\RACache')
    )){if($p -and (Test-Path $p)){[void]$roots.Add($p)}}
    try{
        foreach($d in Get-ChildItem $env:LOCALAPPDATA -Directory -ErrorAction SilentlyContinue){
            if($d.Name -match 'RAHarvester'){$a=Join-Path $d.FullName 'Archive';if(Test-Path $a){[void]$roots.Add($a)}}
        }
    }catch{}
    return @($roots|Select-Object -Unique)
}
function Find-ErisUsb{foreach($d in [IO.DriveInfo]::GetDrives()){try{if(!$d.IsReady){continue};$r=$d.RootDirectory.FullName;if(Test-Path (Join-Path $r 'project_eris\etc\project_eris\CFG\project_eris_cfg.INI')){return $r}}catch{}};return $null}
function Eris-Root([string]$Usb){Join-Path $Usb 'project_eris\etc\project_eris'}
function Ra-Root([string]$Usb){Join-Path $Usb 'project_eris\opt\retroarch'}
function Set-IniValue([string]$Path,[string]$Key,[string]$Value){if(!(Test-Path $Path)){return};$t=[IO.File]::ReadAllText($Path);$p='(?m)^\s*'+[regex]::Escape($Key)+'\s*=.*$';$l=$Key+'="'+$Value+'"';if([regex]::IsMatch($t,$p)){$t=[regex]::Replace($t,$p,$l)}else{$t=$t.TrimEnd()+"`r`n$l`r`n"};[IO.File]::WriteAllText($Path,$t,[Text.UTF8Encoding]::new($false))}
function Set-RaSetting([string]$Path,[string]$Key,[string]$Value){if(!(Test-Path $Path)){return};$t=[IO.File]::ReadAllText($Path);$p='(?m)^\s*'+[regex]::Escape($Key)+'\s*=.*$';$l=$Key+' = "'+$Value+'"';if([regex]::IsMatch($t,$p)){$t=[regex]::Replace($t,$p,$l)}else{$t=$t.TrimEnd()+"`r`n$l`r`n"};[IO.File]::WriteAllText($Path,$t,[Text.UTF8Encoding]::new($false))}
function Clear-ErisPPLegacyDmix([string]$Path){if(!(Test-Path $Path)){return};$t=[IO.File]::ReadAllText($Path);$p='(?im)^\s*audio_device\s*=\s*"(?:plug:)?dmix[^"]*"\s*$';if([regex]::IsMatch($t,$p)){$t=[regex]::Replace($t,$p,'audio_device = ""');[IO.File]::WriteAllText($Path,$t,[Text.UTF8Encoding]::new($false))}}
function Clear-ErisPPDsp([string]$Path){if(!(Test-Path $Path)){return};$t=[IO.File]::ReadAllText($Path);$p='(?im)^\s*audio_dsp_plugin\s*=\s*"[^"]*erispp_dsp[.]so"\s*$';if([regex]::IsMatch($t,$p)){$t=[regex]::Replace($t,$p,'audio_dsp_plugin = ""');[IO.File]::WriteAllText($Path,$t,[Text.UTF8Encoding]::new($false))}}
function Backup-One([string]$File,[string]$Usb,[string]$Backup){if(!(Test-Path $File)){return};$rel=$File.Substring($Usb.Length).TrimStart('\');$dst=Join-Path $Backup $rel;New-Item -ItemType Directory -Force -Path (Split-Path $dst -Parent)|Out-Null;Copy-Item $File $dst -Force}
function Copy-Tree([string]$Src,[string]$Dst){if(!(Test-Path $Src)){return};New-Item -ItemType Directory -Force -Path $Dst|Out-Null;Copy-Item (Join-Path $Src '*') $Dst -Recurse -Force}
function Copy-ErisPPFileIfDifferent([string]$Source,[string]$Destination){
    if([string]::IsNullOrWhiteSpace($Source) -or [string]::IsNullOrWhiteSpace($Destination) -or !(Test-Path $Source)){return $false}
    try{$srcFull=[IO.Path]::GetFullPath((Get-Item $Source).FullName).TrimEnd('\');$dstFull=[IO.Path]::GetFullPath($Destination).TrimEnd('\')}catch{return $false}
    if([string]::Equals($srcFull,$dstFull,[System.StringComparison]::OrdinalIgnoreCase)){return $true}
    $parent=Split-Path $Destination -Parent;if($parent){New-Item -ItemType Directory -Force -Path $parent|Out-Null}
    Copy-Item $Source $Destination -Force
    return (Test-Path $Destination)
}
function Patch-RaLaunch([string]$Path){
    if(!(Test-Path $Path)){throw 'ra_launch.sh is missing.'}
    $t=Get-Content $Path -Raw
    $t=[regex]::Replace($t,'(?s)# >>> PROJECT_ERIS_PP_RUNTIME >>>.*?# <<< PROJECT_ERIS_PP_RUNTIME <<<\s*','')
    $block=@'
# >>> PROJECT_ERIS_PP_RUNTIME >>>
ERISPP_ROOT="/media/project_eris/etc/project_eris/etc/erispp"
if [ -f "$ERISPP_ROOT/runtime/erispp_prelaunch.sh" ]; then
  sh "$ERISPP_ROOT/runtime/erispp_prelaunch.sh" "$@" >/dev/null 2>&1
fi
if [ -f "$ERISPP_ROOT/runtime/erispp_hook.sh" ]; then
  sh "$ERISPP_ROOT/runtime/erispp_hook.sh" "$@" >/dev/null 2>&1 &
fi
ERISPP_AUDIO_BRIDGE="$ERISPP_ROOT/runtime/erispp_audio_bridge.so"
if [ -f "$ERISPP_AUDIO_BRIDGE" ]; then
  case ":${LD_PRELOAD:-}:" in
    *":$ERISPP_AUDIO_BRIDGE:"*) ;;
    *) export LD_PRELOAD="$ERISPP_AUDIO_BRIDGE${LD_PRELOAD:+:$LD_PRELOAD}" ;;
  esac
fi
# <<< PROJECT_ERIS_PP_RUNTIME <<<
'@
    $pos=$t.IndexOf("`n")
    if($pos -ge 0){$t=$t.Substring(0,$pos+1)+$block+"`n"+$t.Substring($pos+1)}else{$t=$block+"`n"+$t}
    Write-LF $Path $t
}
function Get-InternalCatalog{return @(
[pscustomobject]@{Slot=1;RaId=11414;Title='Battle Arena Toshinden';Set='SET'},[pscustomobject]@{Slot=2;RaId=7332;Title='Cool Boarders 2';Set='NO_SET'},[pscustomobject]@{Slot=3;RaId=14045;Title='Destruction Derby';Set='NO_SET'},[pscustomobject]@{Slot=4;RaId=11242;Title='Final Fantasy VII';Set='SET'},[pscustomobject]@{Slot=5;RaId=10437;Title='Grand Theft Auto';Set='SET'},[pscustomobject]@{Slot=6;RaId=13904;Title='Intelligent Qube';Set='SET'},[pscustomobject]@{Slot=7;RaId=14048;Title='Jumping Flash!';Set='SET'},[pscustomobject]@{Slot=8;RaId=11244;Title='Metal Gear Solid';Set='SET'},[pscustomobject]@{Slot=9;RaId=5573;Title='Mr. Driller';Set='SET'},[pscustomobject]@{Slot=10;RaId=11295;Title="Oddworld: Abe's Oddysee";Set='SET'},[pscustomobject]@{Slot=11;RaId=11346;Title='Rayman';Set='SET'},[pscustomobject]@{Slot=12;RaId=11268;Title="Resident Evil: Director's Cut";Set='SET'},[pscustomobject]@{Slot=13;RaId=11371;Title='Revelations: Persona';Set='SET'},[pscustomobject]@{Slot=14;RaId=11305;Title='R4: Ridge Racer Type 4';Set='SET'},[pscustomobject]@{Slot=15;RaId=14379;Title='Super Puzzle Fighter II Turbo';Set='SET'},[pscustomobject]@{Slot=16;RaId=10675;Title='Syphon Filter';Set='SET'},[pscustomobject]@{Slot=17;RaId=11259;Title='Tekken 3';Set='SET'},[pscustomobject]@{Slot=18;RaId=11591;Title="Tom Clancy's Rainbow Six";Set='NO_SET'},[pscustomobject]@{Slot=19;RaId=11383;Title='Twisted Metal';Set='SET'},[pscustomobject]@{Slot=20;RaId=11310;Title='Wild Arms';Set='SET'})}
function Get-Library{if(Test-Path $script:LibraryFile){try{return (Get-Content $script:LibraryFile -Raw|ConvertFrom-Json)}catch{}};$g=@();foreach($i in Get-InternalCatalog){$g+=[pscustomobject]@{Key="internal:$($i.Slot)";Source='Internal';Slot=$i.Slot;Title=$i.Title;Path='';RaId=$i.RaId;OfficialSet=$i.Set;PackStatus=$(if($i.Set -eq 'NO_SET'){'No Set'}else{'Pack needed'});Supported=0;Total=0}};return [pscustomobject]@{version='1.0.21';games=$g}}
function Save-Library($Lib){$Lib.version='1.0.21';$Lib|Add-Member -NotePropertyName updated -NotePropertyValue ((Get-Date).ToString('o')) -Force;$Lib|ConvertTo-Json -Depth 8|Set-Content $script:LibraryFile -Encoding UTF8}
function Get-ErisPPCanonicalGameList($Lib){
    $out=New-Object System.Collections.ArrayList;$seen=@{}
    foreach($g in @($Lib.games|Sort-Object @{Expression={if($_.Source -eq 'Internal'){0}else{1}}},Title)){
        $gid=0;try{$gid=[int]$g.RaId}catch{};if($gid -le 0){continue};$key=[string]$gid
        if($seen.ContainsKey($key)){continue};$seen[$key]=$true;[void]$out.Add($g)
    }
    return @($out)
}
function Get-ErisPPInstalledContentMap([string]$Usb){
    $byBase=@{};$byGid=@{};$byGidBase=@{};if(!$Usb){return [pscustomobject]@{ByBase=$byBase;ByGid=$byGid;ByGidBase=$byGidBase}}
    $map=Join-Path (Eris-Root $Usb) 'etc\erispp\content_map.tsv';if(!(Test-Path $map)){return [pscustomobject]@{ByBase=$byBase;ByGid=$byGid;ByGidBase=$byGidBase}}
    foreach($line in Get-Content $map -ErrorAction SilentlyContinue){$f=$line -split "`t",3;if($f.Count -lt 2){continue};$gid=0;try{$gid=[int]$f[0]}catch{};if($gid -le 0){continue};$base=[string]$f[1];if($base){$byBase[$base.ToLowerInvariant()]=$gid;if(!$byGidBase.ContainsKey([string]$gid)){$byGidBase[[string]$gid]=$base}};$byGid[[string]$gid]=$true}
    return [pscustomobject]@{ByBase=$byBase;ByGid=$byGid;ByGidBase=$byGidBase}
}
function Get-ErisPPGameAliases($Game){
    $out=New-Object System.Collections.ArrayList
    if($null -eq $Game){return @()}
    $p=$Game.PSObject.Properties['Aliases']
    if($null -ne $p -and $null -ne $p.Value){foreach($a in @($p.Value)){if($a){[void]$out.Add(([IO.Path]::GetFileName([string]$a)))}}}
    return @($out|Where-Object{$_}|Select-Object -Unique)
}
function Set-ErisPPGameAliases($Game,[string[]]$Aliases){
    if($null -eq $Game){return}
    $clean=@($Aliases|ForEach-Object{if($_){[IO.Path]::GetFileName([string]$_)}}|Where-Object{$_}|Select-Object -Unique)
    $Game|Add-Member -NotePropertyName Aliases -NotePropertyValue $clean -Force
}
function Get-ErisPPProjectErisGameTitle([string]$Folder,[string]$Fallback){
    if($Folder -and (Test-Path $Folder)){
        $ini=Join-Path $Folder 'Game.ini'
        if(!(Test-Path $ini)){$ini=Get-ChildItem $Folder -Recurse -File -Filter 'Game.ini' -ErrorAction SilentlyContinue|Select-Object -First 1|ForEach-Object{$_.FullName}}
        if($ini -and (Test-Path $ini)){
            foreach($line in Get-Content $ini -ErrorAction SilentlyContinue){
                $m=[regex]::Match([string]$line,'(?i)^\s*Title\s*=\s*(.*?)\s*$')
                if($m.Success){$v=$m.Groups[1].Value.Trim().Trim('"').Trim("'");if($v){return (Safe $v)}}
            }
        }
    }
    return (Safe $Fallback)
}
function Get-ErisPPInstalledUsbGameScan([string]$Usb,[scriptblock]$StatusCallback=$null){
    if(!$Usb -or !(Test-Path $Usb)){throw 'Project Eris USB drive was not found.'}
    $roots=New-Object System.Collections.ArrayList
    foreach($p in @((Join-Path $Usb 'games'),(Join-Path $Usb 'project_eris\games'),(Join-Path $Usb 'project_eris\etc\project_eris\games'))){if(Test-Path $p){[void]$roots.Add((Get-Item $p).FullName)}}
    $roots=@($roots|Select-Object -Unique)
    if($roots.Count -eq 0){return [pscustomobject]@{Roots=@();Items=@();Issues=@([pscustomobject]@{Title='Project Eris games';Type='SCAN';Detail='No installed Project Eris games directory was found.';Path=$Usb});Games=0;MultiDisc=0;SingleDisc=0;IssuesCount=1}}
    $items=New-Object System.Collections.ArrayList;$issues=New-Object System.Collections.ArrayList;$visited=0
    foreach($root in $roots){
        $dirs=@(Get-ChildItem $root -Directory -ErrorAction SilentlyContinue|Sort-Object Name)
        if($dirs.Count -eq 0){$dirs=@(Get-Item $root)}
        foreach($dir in $dirs){
            $visited++;if($StatusCallback){& $StatusCallback ([pscustomobject]@{Phase='SCAN';Current=$visited;Total=$dirs.Count;Title=$dir.Name;Status='Scanning installed game';Detail=$dir.FullName;Identity=''})}
            $all=@(Get-ChildItem $dir.FullName -Recurse -File -ErrorAction SilentlyContinue|Where-Object{$_.Extension.ToLowerInvariant() -in @('.m3u','.cue','.chd','.pbp','.iso')})
            if($all.Count -eq 0){continue}
            $m3u=@($all|Where-Object{$_.Extension -ieq '.m3u'}|Sort-Object FullName)
            $cues=@($all|Where-Object{$_.Extension -ieq '.cue'}|Sort-Object FullName)
            $other=@($all|Where-Object{$_.Extension.ToLowerInvariant() -in @('.chd','.pbp','.iso')}|Sort-Object FullName)
            $launch=$null;$aliases=New-Object System.Collections.ArrayList;$discCount=1;$type='';$multi=$false
            if($m3u.Count -gt 0){
                $launch=$m3u[0];$type='M3U';$refs=@(Get-ErisPPM3uReferences $launch.FullName);$discCount=[Math]::Max(1,$refs.Count);$multi=($discCount -gt 1)
                [void]$aliases.Add($launch.Name);foreach($r in $refs){[void]$aliases.Add([IO.Path]::GetFileName([string]$r))}
                if($m3u.Count -gt 1){[void]$issues.Add([pscustomobject]@{Title=$dir.Name;Type='M3U';Detail='Multiple M3U files found in one Project Eris game folder; the first one was used.';Path=$dir.FullName})}
            } elseif($cues.Count -gt 0){
                if($cues.Count -gt 1){
                    $discInfo=@($cues|ForEach-Object{[pscustomobject]@{Cue=$_;Disc=(Get-ErisPPDiscInfo $_.FullName)}})
                    $discRows=@($discInfo|Where-Object{$_.Disc.IsDisc})
                    $stems=@($discRows|ForEach-Object{Normalize-Title ([string]$_.Disc.Stem)}|Where-Object{$_}|Select-Object -Unique)
                    if($discRows.Count -ne $cues.Count -or $stems.Count -ne 1){
                        [void]$issues.Add([pscustomobject]@{Title=$dir.Name;Type='AMBIGUOUS_CUE_SET';Detail='Multiple CUE files found without an M3U and they do not form one unambiguous numbered disc set; skipped to avoid linking unrelated games to one achievement ID.';Path=$dir.FullName});continue
                    }
                    $ordered=@($discInfo|Sort-Object @{Expression={$_.Disc.Order}},@{Expression={$_.Cue.Name}});$launch=$ordered[0].Cue;$type='CUE_SET';$discCount=$ordered.Count;$multi=$true;foreach($row in $ordered){[void]$aliases.Add($row.Cue.Name)}
                } else {$launch=$cues[0];$type='CUE';$discCount=1;$multi=$false;[void]$aliases.Add($launch.Name)}
            } elseif($other.Count -eq 1){
                $launch=$other[0];$type=$launch.Extension.TrimStart('.').ToUpperInvariant();[void]$aliases.Add($launch.Name)
            } else {
                [void]$issues.Add([pscustomobject]@{Title=$dir.Name;Type='AMBIGUOUS';Detail='Multiple non-CUE game images found without an M3U; skipped to avoid linking achievements to the wrong game.';Path=$dir.FullName});continue
            }
            if($null -eq $launch){continue}
            $fallback=$launch.BaseName;if($cues.Count -gt 1){$d=Get-ErisPPDiscInfo $launch.FullName;if($d.Stem){$fallback=$d.Stem}}
            $title=Get-ErisPPProjectErisGameTitle $dir.FullName $fallback
            $identity=('installed-usb:'+($dir.FullName.ToLowerInvariant()))
            [void]$items.Add([pscustomobject]@{Identity=$identity;Title=$title;Type=$type;LaunchFile=$launch.FullName;Aliases=@($aliases|Select-Object -Unique);DiscCount=$discCount;MultiDisc=$multi;Folder=$dir.FullName;Root=$root})
        }
    }
    $multiCount=@($items|Where-Object{$_.MultiDisc}).Count
    return [pscustomobject]@{Roots=$roots;Items=@($items|Sort-Object Title);Issues=@($issues);Games=$items.Count;MultiDisc=$multiCount;SingleDisc=($items.Count-$multiCount);IssuesCount=$issues.Count}
}
function Import-ErisPPInstalledUsbGames([string]$Usb,$Lib,$Scan=$null,[scriptblock]$StatusCallback=$null){
    if($null -eq $Scan){$Scan=Get-ErisPPInstalledUsbGameScan $Usb $StatusCallback}
    [void](Seed-ErisPPAchievementLibraryFromUsb $Usb);[void](Refresh-ErisPPAchievementLibraryCatalog);[void](Import-ExistingCompiledPacks $Lib)
    if($StatusCallback){& $StatusCallback ([pscustomobject]@{Phase='CACHE_INDEX';Current=0;Total=0;Title='';Status='Indexing achievement cache';Detail='Existing Project Eris games stay in place; only achievement metadata is prepared.';Identity=''})}
    [void](Build-ErisPPCacheTitleIndex $StatusCallback)
    $report=New-Object System.Collections.ArrayList
    [void]$report.Add('Project Eris ++ v1.0.21 existing USB game achievement import')
    [void]$report.Add('Generated='+(Get-Date -Format o));[void]$report.Add('USB='+$Usb)
    [void]$report.Add(('ScanGames='+$Scan.Games+' SingleDisc='+$Scan.SingleDisc+' MultiDisc='+$Scan.MultiDisc+' Issues='+$Scan.IssuesCount))
    [void]$report.Add('Policy=games remain in their existing Project Eris folders; genuine FDB/UI/content mappings are installed in place; no game image is copied or moved')
    foreach($i in @($Scan.Issues)){[void]$report.Add("ATTENTION`t$($i.Title)`t$($i.Type)`t$($i.Detail)`t$($i.Path)")}
    $ready=0;$noSet=0;$blocked=0;$linked=0;$updated=0;$idx=0;$total=[Math]::Max(1,[int]$Scan.Games)
    foreach($item in @($Scan.Items)){
        $idx++;if($StatusCallback){& $StatusCallback ([pscustomobject]@{Phase='PREFLIGHT';Current=$idx;Total=$total;Title=$item.Title;Status='Achievement preflight';Detail=('Installed game '+$idx+' of '+$total);Identity=$item.Identity})}
        $g=[pscustomobject]@{Key=[string]$item.Identity;Source='USB';Slot=0;Title=[string]$item.Title;Path=[string]$item.LaunchFile;RaId=0;OfficialSet='UNKNOWN';PackStatus='Pack needed';Supported=0;Total=0;Aliases=@($item.Aliases)}
        $pre=Ensure-ErisPPGamePack ([string]$item.LaunchFile) $g
        if(!$pre.Accepted){$blocked++;[void]$report.Add("BLOCKED`t$($item.Title)`t$($item.Type)`t$($pre.Detail)");if($StatusCallback){& $StatusCallback ([pscustomobject]@{Phase='GAME';Current=$idx;Total=$total;Title=$item.Title;Status='No achievement pack';Detail=$pre.Detail;Identity=$item.Identity})};continue}
        $gid=[int]$g.RaId;$existing=@($Lib.games|Where-Object{($_.Source -ne 'Internal') -and ([int]$_.RaId -eq $gid)}|Select-Object -First 1)
        if($existing.Count -gt 0){
            $eg=$existing[0];$eg.Title=$g.Title;$eg.Path=$g.Path;$eg.OfficialSet=$g.OfficialSet;$eg.PackStatus=$g.PackStatus;$eg.Supported=$g.Supported;$eg.Total=$g.Total
            $aliasList=New-Object System.Collections.ArrayList
            foreach($a in @(Get-ErisPPGameAliases $eg)){if($a){[void]$aliasList.Add([string]$a)}}
            foreach($a in @($item.Aliases)){if($a){[void]$aliasList.Add([string]$a)}}
            $launchAlias=[IO.Path]::GetFileName([string]$item.LaunchFile);if($launchAlias){[void]$aliasList.Add($launchAlias)}
            $merged=@($aliasList|Where-Object{$_}|Select-Object -Unique);Set-ErisPPGameAliases $eg $merged;$updated++
        } else {$Lib.games=@($Lib.games)+$g;$linked++}
        if($g.OfficialSet -eq 'NO_SET'){$noSet++}else{$ready++}
        [void]$report.Add("LINKED`t$($item.Title)`t$($item.Type)`tRA=$gid`t$($pre.Status)`tAliases=$(@($item.Aliases).Count)`t$($pre.Detail)")
        if($StatusCallback){& $StatusCallback ([pscustomobject]@{Phase='GAME';Current=$idx;Total=$total;Title=$item.Title;Status='Achievement-ready';Detail=('RA '+$gid+'; '+$pre.Status);Identity=$item.Identity})}
    }
    Save-Library $Lib;Build-Indexes $Lib
    if(($linked+$updated) -gt 0){if($StatusCallback){& $StatusCallback ([pscustomobject]@{Phase='DEPLOY';Current=1;Total=1;Title='';Status='Installing achievement mappings';Detail='No game data is copied';Identity=''})};[void](Deploy-StagedOnly $Usb $Lib);[void]$report.Add('DEPLOY_OK`tAchievement database/UI/content aliases installed; existing game files left untouched')}
    $rp=Join-Path $Usb 'PROJECT_ERIS_PP_LAST_EXISTING_USB_IMPORT.txt';$report|Set-Content $rp -Encoding UTF8
    return [pscustomobject]@{Scanned=$Scan.Games;Linked=$linked;Updated=$updated;Ready=$ready;NoSet=$noSet;Blocked=$blocked;Issues=$Scan.IssuesCount;Report=$rp;Scan=$Scan}
}
function Repair-ErisPPUniqueProgress([string]$Usb){
    if(!$Usb){return [pscustomobject]@{StateDuplicatesRemoved=0;PlayedDuplicatesRemoved=0;HistoryDuplicatesRemoved=0}}
    $root=Join-Path (Eris-Root $Usb) 'etc\erispp';$stateDir=Join-Path $root 'state';$profile=Join-Path $root 'profiles\active';$mapInfo=Get-ErisPPInstalledContentMap $Usb
    $stateRemoved=0;$playedRemoved=0;$historyRemoved=0
    if(Test-Path $stateDir){foreach($f in Get-ChildItem $stateDir -Filter '*.unlocked' -File -ErrorAction SilentlyContinue){$seen=@{};$rows=New-Object System.Collections.ArrayList;$before=0;foreach($line in Get-Content $f.FullName -ErrorAction SilentlyContinue){$t=$line.Trim();if(!$t){continue};$before++;$id=0;try{$id=[int]$t}catch{};if($id -le 0){continue};$k=[string]$id;if($seen.ContainsKey($k)){continue};$seen[$k]=$true;[void]$rows.Add($k)};$stateRemoved+=($before-$rows.Count);if($before -ne $rows.Count){$rows|Set-Content $f.FullName -Encoding ASCII}}}
    $played=Join-Path $profile 'played.tsv';if(Test-Path $played){$seen=@{};$rows=New-Object System.Collections.ArrayList;$before=0;foreach($line in Get-Content $played -ErrorAction SilentlyContinue){if(!$line){continue};$before++;$f=$line -split "`t",3;if($f.Count -lt 1){continue};$gid=0;try{$gid=[int]$f[0]}catch{};$base=if($f.Count -ge 3){[string]$f[2]}else{''};if($base -and $mapInfo.ByBase.ContainsKey($base.ToLowerInvariant())){$gid=[int]$mapInfo.ByBase[$base.ToLowerInvariant()]};if($gid -le 0){continue};$k=[string]$gid;if($seen.ContainsKey($k)){continue};$seen[$k]=$true;$when=if($f.Count -ge 2){$f[1]}else{''};[void]$rows.Add("$gid`t$when`t$base")};$playedRemoved+=($before-$rows.Count);if($before -ne $rows.Count){$rows|Set-Content $played -Encoding ASCII}}
    $hist=Join-Path $profile 'history.tsv';if(Test-Path $hist){$seen=@{};$rows=New-Object System.Collections.ArrayList;$before=0;foreach($line in Get-Content $hist -ErrorAction SilentlyContinue){if(!$line){continue};$before++;$key=$line.Trim();if($seen.ContainsKey($key)){continue};$seen[$key]=$true;[void]$rows.Add($line)};$historyRemoved+=($before-$rows.Count);if($before -ne $rows.Count){$rows|Set-Content $hist -Encoding ASCII}}
    return [pscustomobject]@{StateDuplicatesRemoved=$stateRemoved;PlayedDuplicatesRemoved=$playedRemoved;HistoryDuplicatesRemoved=$historyRemoved}
}
function Sync-InternalExport([string]$Usb,$Lib){$root=Join-Path $Usb 'PROJECT_ERIS_PP_INTERNAL_EXPORT';$m=Join-Path $root 'manifest.tsv';if(!(Test-Path $m)){return 0};$by=@{};foreach($g in $Lib.games){$by[$g.Key]=$g};$n=0;foreach($line in Get-Content $m){if(!$line -or $line.StartsWith('#')){continue};$f=$line -split "`t",5;if($f.Count -lt 5){continue};$key='internal:'+$f[0];if($by.ContainsKey($key)){$g=$by[$key];$g.Path=Join-Path $root ($f[4] -replace '/','\');$g.RaId=[int]$f[1];$g.OfficialSet=$f[2];$n++}};Save-Library $Lib;return $n}
function Core-Achievements($Cache){
    $r=New-Object System.Collections.ArrayList;$seen=@{}
    $sets=Get-ErisPPPropertyValue $Cache 'Sets'
    if($null -ne $sets){
        foreach($set in @($sets)){
            if($null -eq $set){continue}
            $type=[string](Get-ErisPPPropertyValue $set 'Type')
            if($type -and $type.ToLowerInvariant() -ne 'core'){continue}
            $achs=Get-ErisPPPropertyValue $set 'Achievements'
            if($null -eq $achs){continue}
            foreach($a in @($achs)){
                if($null -eq $a){continue}
                $id=[string](Get-ErisPPPropertyValue $a 'ID');if(!$id){$id=[string](Get-ErisPPPropertyValue $a 'id')}
                if($id -and $seen.ContainsKey($id)){continue};if($id){$seen[$id]=$true};[void]$r.Add($a)
            }
        }
    }
    if($r.Count -eq 0){
        $top=Get-ErisPPPropertyValue $Cache 'Achievements'
        if($null -ne $top){foreach($a in @($top)){if($null -eq $a){continue};$id=[string](Get-ErisPPPropertyValue $a 'ID');if(!$id){$id=[string](Get-ErisPPPropertyValue $a 'id')};if($id -and $seen.ContainsKey($id)){continue};if($id){$seen[$id]=$true};[void]$r.Add($a)}}
    }
    return @($r)
}
function Test-ErisPPCacheSchemaCompatibility{
    $missing=[pscustomobject]@{GameId=1900000001;Title='Schema Missing Set Achievements';Sets=@([pscustomobject]@{Type='core'},[pscustomobject]@{Type='bonus'})}
    $a=@(Core-Achievements $missing);if($a.Count -ne 0){throw 'Cache schema self-test failed: missing Achievements set must be skipped.'}
    $fallback=[pscustomobject]@{GameId=1900000002;Title='Schema Top Level Fallback';Sets=@([pscustomobject]@{Type='core'});Achievements=@([pscustomobject]@{ID=12345;Title='Real cached entry'})}
    $b=@(Core-Achievements $fallback);if($b.Count -ne 1){throw 'Cache schema self-test failed: top-level Achievements fallback was not preserved.'}
    return $true
}
function Test-TriggerSupported([string]$Raw){return ($null -ne (Convert-ErisPPTrigger $Raw))}
function Find-CacheJson([int]$Id,[string]$Title){$cands=@();foreach($r in Get-CacheRoots){$direct=Join-Path $r "$Id.json";if(Test-Path $direct){return $direct};$data=Join-Path $r "Data\$Id.json";if(Test-Path $data){return $data};$cands+=Get-ChildItem $r -Recurse -File -Filter '*.json' -ErrorAction SilentlyContinue|Select-Object -First 2500};foreach($f in $cands){try{$j=Get-Content $f.FullName -Raw|ConvertFrom-Json;$jid=Get-ErisPPGameIdFromCache $j;if($jid -eq $Id -and (Test-ErisPPRawCacheObject $j)){return $f.FullName}}catch{}};return $null}
function Test-ErisPPRawCacheFile([string]$Path){
    if(!$Path -or !(Test-Path $Path)){return $false}
    try{$j=Get-Content $Path -Raw -Encoding UTF8|ConvertFrom-Json;$gid=Get-ErisPPGameIdFromCache $j;return ($gid -gt 0 -and (Test-ErisPPRawCacheObject $j))}catch{return $false}
}
function Import-ErisPPRawCacheFile([string]$Path){
    if(!(Test-ErisPPRawCacheFile $Path)){return $null}
    $j=Get-Content $Path -Raw -Encoding UTF8|ConvertFrom-Json;$gid=Get-ErisPPGameIdFromCache $j
    $raw=Join-Path $script:RawCache ("$gid.json");$libraw=Join-Path $script:AchievementRaw ("$gid.json")
    if(!(Copy-ErisPPFileIfDifferent $Path $raw)){return $null}
    if(!(Copy-ErisPPFileIfDifferent $Path $libraw)){return $null}
    return $libraw
}
function Save-ErisPPCompiledPack($Game,[string]$CacheFile){
    $gid=[int]$Game.RaId;if($gid -le 0){return $false}
    if($CacheFile){[void](Import-ErisPPRawCacheFile $CacheFile)}
    $srcDb=Join-Path $script:StageRoot ("database\$gid.fdb");$srcUi=Join-Path $script:StageRoot ("ui\games\$gid.tsv")
    if(!(Test-Path $srcDb)){return $false}
    $dstDb=Join-Path $script:AchievementCompiled ("database\$gid.fdb");$dstUi=Join-Path $script:AchievementCompiled ("ui\games\$gid.tsv")
    New-Item -ItemType Directory -Force -Path (Split-Path $dstDb -Parent),(Split-Path $dstUi -Parent)|Out-Null
    Copy-Item $srcDb $dstDb -Force;if(Test-Path $srcUi){Copy-Item $srcUi $dstUi -Force}
    return $true
}
function Find-ErisPPCompiledPackByTitle([string]$Title){
    $norm=Normalize-Title $Title;if(!$norm){return $null};$db=Join-Path $script:AchievementCompiled 'database';if(!(Test-Path $db)){return $null}
    foreach($f in Get-ChildItem $db -Filter '*.fdb' -File -ErrorAction SilentlyContinue){try{$first=Get-Content $f.FullName -TotalCount 1 -Encoding ASCII;$h=$first -split "`t";if($h.Count -lt 4 -or $h[0] -ne 'ERPP2'){continue};$gid=[int]$h[1];$cnt=[int]$h[2];$ttl=[string]$h[3];if($gid -gt 0 -and $cnt -gt 0 -and (Normalize-Title $ttl) -eq $norm){$actual=@(Get-Content $f.FullName -Encoding ASCII|Where-Object{$_.StartsWith("A`t")}).Count;if($actual -ne $cnt){continue};return [pscustomobject]@{Gid=$gid;Count=$cnt;Title=$ttl;Db=$f.FullName;Ui=(Join-Path $script:AchievementCompiled ("ui\games\$gid.tsv"));Badges=(Join-Path $script:AchievementCompiled ("ui\badges\$gid"))}}}catch{}}
    return $null
}
function Stage-ErisPPCompiledPack($Pack){
    if($null -eq $Pack -or !(Test-Path $Pack.Db)){return $false};$gid=[int]$Pack.Gid;$db=Join-Path $script:StageRoot 'database';$uig=Join-Path $script:StageRoot 'ui\games';$uib=Join-Path $script:StageRoot 'ui\badges';New-Item -ItemType Directory -Force -Path $db,$uig,$uib|Out-Null;Copy-Item $Pack.Db (Join-Path $db ("$gid.fdb")) -Force;if($Pack.Ui -and (Test-Path $Pack.Ui)){Copy-Item $Pack.Ui (Join-Path $uig ("$gid.tsv")) -Force};if($Pack.Badges -and (Test-Path $Pack.Badges)){Copy-Tree $Pack.Badges (Join-Path $uib ("$gid"))};return (Test-ErisPPStagedPack $gid)
}
function Test-ErisPPStagedPack([int]$Gid){
    $f=Join-Path $script:StageRoot ("database\$Gid.fdb");if(!(Test-Path $f)){return $false}
    $lines=@(Get-Content $f -Encoding ASCII);if($lines.Count -lt 2){return $false};$h=$lines[0] -split "`t";if($h.Count -lt 4 -or $h[0] -ne 'ERPP2' -or [int]$h[1] -ne $Gid){return $false}
    $decl=[int]$h[2];$actual=@($lines|Where-Object{$_.StartsWith("A`t")}).Count;return ($decl -gt 0 -and $decl -eq $actual)
}
function Seed-ErisPPAchievementLibraryFromUsb([string]$Usb){
    if(!$Usb){return 0};$root=Join-Path (Eris-Root $Usb) 'etc\erispp';$db=Join-Path $root 'database';$ui=Join-Path $root 'ui\games';$badges=Join-Path $root 'ui\badges';if(!(Test-Path $db)){return 0};$n=0
    foreach($f in Get-ChildItem $db -Filter '*.fdb' -File -ErrorAction SilentlyContinue){$dst=Join-Path $script:AchievementCompiled ("database\"+$f.Name);Copy-Item $f.FullName $dst -Force;$u=Join-Path $ui ($f.BaseName+'.tsv');if(Test-Path $u){Copy-Item $u (Join-Path $script:AchievementCompiled ("ui\games\"+$f.BaseName+'.tsv')) -Force};$b=Join-Path $badges $f.BaseName;if(Test-Path $b){Copy-Tree $b (Join-Path $script:AchievementCompiled ("ui\badges\"+$f.BaseName))};$n++}
    return $n
}
function Refresh-ErisPPAchievementLibraryCatalog{
    $rows=New-Object System.Collections.ArrayList;$seen=@{};$copied=0;$libRoot=$script:AchievementLibrary.ToLowerInvariant()
    foreach($r in Get-CacheRoots){if(!$r){continue};$rp=[string]$r;if($rp.ToLowerInvariant().StartsWith($libRoot)){continue};foreach($f in Get-ChildItem $r -Recurse -File -Filter '*.json' -ErrorAction SilentlyContinue|Select-Object -First 5000){
        try{$j=Get-Content $f.FullName -Raw -Encoding UTF8|ConvertFrom-Json;$gid=Get-ErisPPGameIdFromCache $j;if($gid -le 0 -or !(Test-ErisPPRawCacheObject $j)){continue};if($seen.ContainsKey($gid)){continue};$seen[$gid]=$true;$dst=Join-Path $script:AchievementRaw ("$gid.json");if(!(Test-Path $dst) -or $f.LastWriteTimeUtc -gt (Get-Item $dst).LastWriteTimeUtc){Copy-Item $f.FullName $dst -Force;$copied++};$count=@(Core-Achievements $j).Count;$title=Safe ([string](Get-ErisPPPropertyValue $j 'Title'));[void]$rows.Add("$gid`t$title`t$count`t$($f.FullName)") }catch{}
    }}
    $rows|Set-Content (Join-Path $script:AchievementLibrary 'catalog.tsv') -Encoding UTF8;return $copied
}
function Find-ErisPPDuckStationExe{
    $c=New-Object System.Collections.ArrayList
    foreach($p in @((Join-Path $env:LOCALAPPDATA 'Programs\DuckStation\duckstation-qt-x64-ReleaseLTCG.exe'),(Join-Path $env:LOCALAPPDATA 'Programs\DuckStation\duckstation-qt-x64-Release.exe'),(Join-Path $env:ProgramFiles 'DuckStation\duckstation-qt-x64-ReleaseLTCG.exe'),(Join-Path $env:ProgramFiles 'DuckStation\duckstation-qt-x64-Release.exe'))){if($p -and (Test-Path $p)){[void]$c.Add($p)}}
    foreach($base in @((Join-Path $env:LOCALAPPDATA 'Programs\DuckStation'),(Join-Path $env:ProgramFiles 'DuckStation'))){if(Test-Path $base){$x=Get-ChildItem $base -Filter 'duckstation-qt*.exe' -File -ErrorAction SilentlyContinue|Select-Object -First 1;if($x){[void]$c.Add($x.FullName)}}}
    return @($c|Select-Object -Unique|Select-Object -First 1)[0]
}
function Get-ErisPPDuckCacheData([string]$DuckExe){
    $c=@();if($DuckExe){$c+=Join-Path (Split-Path $DuckExe -Parent) 'RACache\Data'};$c+=Join-Path $env:LOCALAPPDATA 'DuckStation\RACache\Data';foreach($p in $c){if(Test-Path $p){return $p}};if($DuckExe){return (Join-Path (Split-Path $DuckExe -Parent) 'RACache\Data')};return $null
}
function Harvest-ErisPPGameCache([string]$GameFile,[string]$Title){
    $duck=Find-ErisPPDuckStationExe;if(!$duck){return [pscustomobject]@{Cache=$null;Reason='DuckStation not found'}}
    $raDll=Join-Path (Split-Path $duck -Parent) 'RA_Integration.dll';if(!(Test-Path $raDll)){return [pscustomobject]@{Cache=$null;Reason='RA_Integration.dll not found next to DuckStation'}}
    $cacheDir=Get-ErisPPDuckCacheData $duck;if(!$cacheDir){return [pscustomobject]@{Cache=$null;Reason='DuckStation RACache path not found'}};New-Item -ItemType Directory -Force -Path $cacheDir|Out-Null
    $before=@{};foreach($f in Get-ChildItem $cacheDir -File -Filter '*.json' -ErrorAction SilentlyContinue){$before[$f.FullName.ToLowerInvariant()]="$($f.Length):$($f.LastWriteTimeUtc.Ticks)"}
    $proc=$null;$chosen=$null;$reason='timeout';$norm=Normalize-Title $Title
    try{
        $argLine='-batch -fastboot -nofullscreen -- "'+$GameFile.Replace('"','')+'"';$proc=Start-Process -FilePath $duck -ArgumentList $argLine -PassThru;$deadline=(Get-Date).AddSeconds(120)
        while((Get-Date) -lt $deadline){Start-Sleep -Milliseconds 750;$changed=New-Object System.Collections.ArrayList
            foreach($f in Get-ChildItem $cacheDir -File -Filter '*.json' -ErrorAction SilentlyContinue){try{$key=$f.FullName.ToLowerInvariant();$sig="$($f.Length):$($f.LastWriteTimeUtc.Ticks)";$j=Get-Content $f.FullName -Raw -Encoding UTF8|ConvertFrom-Json;$gid=Get-ErisPPGameIdFromCache $j;if($gid -le 0 -or !(Test-ErisPPRawCacheObject $j)){continue};$cacheTitle=[string](Get-ErisPPPropertyValue $j 'Title');$titleMatch=($cacheTitle -and (Normalize-Title $cacheTitle) -eq $norm);$isChanged=(!$before.ContainsKey($key) -or $before[$key] -ne $sig);if($titleMatch){$chosen=$f.FullName;$reason='title-match';break};if($isChanged){[void]$changed.Add($f.FullName)}}catch{}}
            if($chosen){break};if($changed.Count -eq 1){$chosen=[string]$changed[0];$reason='single-changed-cache';break};try{$proc.Refresh()}catch{};if($proc.HasExited -and (Get-Date) -gt $deadline.AddSeconds(-105)){break}
        }
    } finally {try{if($proc -and !$proc.HasExited){[void]$proc.CloseMainWindow();Start-Sleep -Milliseconds 700;$proc.Refresh();if(!$proc.HasExited){Stop-Process -Id $proc.Id -Force}}}catch{}}
    if($chosen -and (Test-ErisPPRawCacheFile $chosen)){return [pscustomobject]@{Cache=$chosen;Reason=$reason}};return [pscustomobject]@{Cache=$null;Reason=$reason}
}
function Ensure-ErisPPGamePack([string]$GameFile,$Game){
    $cache=Find-CachePathByTitle ([string]$Game.Title);$origin='local-cache';$harvestReason=''
    if(!$cache){
        $compiled=Find-ErisPPCompiledPackByTitle ([string]$Game.Title)
        if($compiled){$Game.RaId=[int]$compiled.Gid;$Game.Title=Safe ([string]$compiled.Title);$Game.OfficialSet='SET';$Game.Supported=[int]$compiled.Count;$Game.Total=[int]$compiled.Count;$Game.PackStatus='Ready';if(Stage-ErisPPCompiledPack $compiled){return [pscustomobject]@{Accepted=$true;Status='READY_CACHED_FDB';Detail=("Validated FDB already present in local library: RA $($compiled.Gid), $($compiled.Count) achievements");Cache=''}}}
        $h=Harvest-ErisPPGameCache $GameFile ([string]$Game.Title);$cache=$h.Cache;$harvestReason=[string]$h.Reason;$origin='duckstation-harvest'
    }
    if(!$cache){return [pscustomobject]@{Accepted=$false;Status='BLOCKED';Detail=('No genuine achievement cache or validated local FDB: '+$harvestReason);Cache=''}}
    $canon=Import-ErisPPRawCacheFile $cache;if(!$canon){return [pscustomobject]@{Accepted=$false;Status='BLOCKED';Detail='Achievement cache is invalid';Cache=$cache}}
    $j=Get-Content $canon -Raw -Encoding UTF8|ConvertFrom-Json;$gid=Get-ErisPPGameIdFromCache $j;$Game.RaId=$gid;$cacheTitle=[string](Get-ErisPPPropertyValue $j 'Title');if($cacheTitle){$Game.Title=Safe $cacheTitle};$achs=@(Core-Achievements $j);$Game.Total=$achs.Count
    if($achs.Count -eq 0){$Game.OfficialSet='NO_SET';$Game.PackStatus='No Set';$Game.Supported=0;return [pscustomobject]@{Accepted=$true;Status='NO_SET';Detail='Verified genuine local cache contains no core achievements';Cache=$canon}}
    $Game.OfficialSet='SET';$ok=Build-Pack $Game $canon;if(!$ok -or !(Test-ErisPPStagedPack $gid)){return [pscustomobject]@{Accepted=$false;Status='BLOCKED';Detail='Genuine cache found but FDB compile/validation failed';Cache=$canon}}
    [void](Save-ErisPPCompiledPack $Game $canon)
    return [pscustomobject]@{Accepted=$true;Status=$Game.PackStatus;Detail=("FDB ready $($Game.Supported)/$($Game.Total) from $origin");Cache=$canon}
}
function Build-Pack($Game,[string]$CacheFile){return (Build-ErisPPRichPack $Game $CacheFile $script:StageRoot)}
function Compile-AvailablePacks($Lib){$built=0;foreach($g in $Lib.games){$id=[int]$g.RaId;$c=$null;if($g.Source -ne 'Internal' -and (Test-LocalGameId $id)){$c=Find-CachePathByTitle ([string]$g.Title)}elseif($id -gt 0){$c=Find-CacheJson $id ([string]$g.Title)};if(!$c -and $g.Source -ne 'Internal'){$c=Find-CachePathByTitle ([string]$g.Title)};if($c){try{$canon=Import-ErisPPRawCacheFile $c;if($canon -and (Build-Pack $g $canon)){[void](Save-ErisPPCompiledPack $g $canon);$built++}}catch{Write-Warning ("Pack compile failed for "+$g.Title+": "+$_.Exception.Message)}}};Save-Library $Lib;return $built}
function Get-LegacyCompiledRoots{
    $roots=New-Object System.Collections.ArrayList
    $bundled=Join-Path $PSScriptRoot 'bundled_packs\database';if(Test-Path $bundled){[void]$roots.Add($bundled)}
    try{foreach($d in Get-ChildItem $env:LOCALAPPDATA -Directory -ErrorAction SilentlyContinue){if($d.Name -match 'RuntimeCompiler'){$p=Join-Path $d.FullName 'PSClassicExport\database';if(Test-Path $p){[void]$roots.Add($p)}}}}catch{}
    foreach($p in @((Join-Path $script:AppRoot 'compiled\database'),(Join-Path $script:AppRoot 'achievement_library\compiled\database'))){if(Test-Path $p){[void]$roots.Add($p)}}
    return @($roots|Select-Object -Unique)
}
function Import-ExistingCompiledPacks($Lib){
    $db=Join-Path $script:StageRoot 'database';$uig=Join-Path $script:StageRoot 'ui\games';$uib=Join-Path $script:StageRoot 'ui\badges';New-Item -ItemType Directory -Force -Path $db,$uig|Out-Null;Remove-Item (Join-Path $db '*.fdb') -Force -ErrorAction SilentlyContinue;Remove-Item (Join-Path $uig '*.tsv') -Force -ErrorAction SilentlyContinue;Remove-Item $uib -Recurse -Force -ErrorAction SilentlyContinue;New-Item -ItemType Directory -Force -Path $uib|Out-Null;$n=0
    foreach($r in Get-LegacyCompiledRoots){foreach($f in Get-ChildItem $r -Filter '*.fdb' -File -ErrorAction SilentlyContinue){
        try{
            $lines=@(Get-Content $f.FullName -Encoding UTF8);if($lines.Count -lt 2){continue};$h=$lines[0] -split "`t";if($h.Count -lt 4){continue}
            $tag=[string]$h[0];if($tag -eq 'ERISPPFDB1'){continue};if($tag.Length -ne 5 -and $tag -ne 'ERPP2'){continue}
            $gid=[int]$h[1];$cnt=[int]$h[2];$h[0]='ERPP2';$lines[0]=$h -join "`t";$lines|Set-Content (Join-Path $db "$gid.fdb") -Encoding ASCII
            $ui=New-Object System.Collections.ArrayList
            foreach($ln in $lines){if($ln.StartsWith("A`t")){ $a=$ln -split "`t",6;if($a.Count -ge 6){[void]$ui.Add("$($a[1])`t$($a[2])`t$(Safe $a[4])`t$(Safe $a[5])`t`t")}}}
            $localBase=Split-Path $r -Parent;$localUi=Join-Path $localBase ("ui\games\$gid.tsv");if(Test-Path $localUi){Copy-Item $localUi (Join-Path $uig "$gid.tsv") -Force}elseif($ui.Count -gt 0){$ui|Set-Content (Join-Path $uig "$gid.tsv") -Encoding ASCII};$localBadges=Join-Path $localBase ("ui\badges\$gid");if(Test-Path $localBadges){Copy-Tree $localBadges (Join-Path $script:StageRoot ("ui\badges\$gid"))}
            if($null -ne $Lib){foreach($g in $Lib.games){if([int]$g.RaId -eq $gid){$g.Supported=$cnt;if([int]$g.Total -le 0){$g.Total=$cnt};$g.PackStatus=if([int]$g.Total -gt $cnt){'Partial'}else{'Ready'}}}}
            $n++
        }catch{}
    }}
    if($null -ne $Lib){Save-Library $Lib};return $n
}
function Build-Indexes($Lib){
    $ui=Join-Path $script:StageRoot 'ui';New-Item -ItemType Directory -Force -Path $ui,(Join-Path $ui 'games')|Out-Null;$lines=New-Object System.Collections.ArrayList;$map=New-Object System.Collections.ArrayList;$seen=@{}
    foreach($g in @($Lib.games|Sort-Object @{Expression={if($_.Source -eq 'Internal'){0}else{1}}},Title)){$gid=0;try{$gid=[int]$g.RaId}catch{};if($gid -le 0){continue};$status=if($g.OfficialSet -eq 'NO_SET'){'NO_SET'}elseif($g.PackStatus -eq 'Partial'){'PARTIAL'}else{'PACK'};$src=if($g.Source -eq 'Internal'){'INTERNAL'}else{'EXTERNAL'};$base='';if($g.Path){$base=[IO.Path]::GetFileName([string]$g.Path)};if(!$seen.ContainsKey([string]$gid)){[void]$lines.Add("$gid`t$(Safe $g.Title)`t$([int]$g.Supported)`t$status`t$src`t$(Safe $base)");$seen[[string]$gid]=$true};if($base){[void]$map.Add("$gid`t$base`t$($src):$(Safe $g.Title)")};foreach($alias in @(Get-ErisPPGameAliases $g)){if($alias){[void]$map.Add("$gid`t$(Safe $alias)`t$($src):$(Safe $g.Title)")}};if($g.Source -eq 'Internal' -and $g.Path){$dir=Split-Path ([string]$g.Path) -Parent;if(Test-Path $dir){foreach($a in Get-ChildItem $dir -File -ErrorAction SilentlyContinue|Where-Object{$_.Extension.ToLowerInvariant() -in @('.cue','.pbp','.chd','.iso','.m3u')}){[void]$map.Add("$gid`t$($a.Name)`tINTERNAL:$(Safe $g.Title)")}}}}
    $lines|Set-Content (Join-Path $ui 'games.tsv') -Encoding ASCII;$map|Select-Object -Unique|Set-Content (Join-Path $script:StageRoot 'content_map.tsv') -Encoding ASCII
}
function Write-Profile([string]$Name){if([string]::IsNullOrWhiteSpace($Name)){$Name='Player'};$n=Safe $Name;New-Item -ItemType Directory -Force -Path $script:ProfileRoot|Out-Null;@("name`t$n","display`t$n","created`t$((Get-Date).ToString('o'))","version`t1")|Set-Content (Join-Path $script:ProfileRoot 'profile.tsv') -Encoding ASCII;Copy-Item (Join-Path $script:PackageRoot 'assets\default_avatar.bmp') (Join-Path $script:ProfileRoot 'avatar.bmp') -Force;Copy-Item (Join-Path $script:PackageRoot 'assets\default_avatar.png') (Join-Path $script:ProfileRoot 'avatar.png') -Force}
function Configure-RetroArch([string]$Usb,[string]$Backup){
    $eris=Eris-Root $Usb
    $ra=Ra-Root $Usb
    $func=Join-Path $eris 'FUNC\0030_retroarch.funcs'
    Backup-One $func $Usb $Backup
    Copy-Item (Join-Path $PSScriptRoot 'payload\0030_retroarch.funcs') $func -Force
    foreach($ini in @((Join-Path $eris 'CFG\project_eris_cfg.INI'),(Join-Path $eris 'CFG\project_eris_cfg_DEFAULT.INI'))){
        Backup-One $ini $Usb $Backup
        Set-IniValue $ini 'LAUNCH_RA_FROM_STOCK_UI' '1'
    }
    $raDir=Join-Path $ra 'config\retroarch'
    $cfgs=@((Join-Path $raDir 'retroarch.cfg'),(Join-Path $raDir 'retroarch_DEFAULT.cfg'),(Join-Path $raDir 'ra-game.cfg'),(Join-Path $raDir 'config\PCSX-ReARMed\title.cfg'))
    foreach($cfg in $cfgs){
        if(Test-Path $cfg){
            Backup-One $cfg $Usb $Backup
            Set-RaSetting $cfg 'enable_device_vibration' 'true'
            Set-RaSetting $cfg 'input_libretro_device_p1' '5'
            Set-RaSetting $cfg 'load_dummy_on_core_shutdown' 'false'
            Set-RaSetting $cfg 'savestate_auto_save' 'true'
            Set-RaSetting $cfg 'savestate_directory' '/tmp/ra_savestate'
            Set-RaSetting $cfg 'savestate_thumbnail_enable' 'true'
            Set-RaSetting $cfg 'savestate_file_compression' 'false'
            Set-RaSetting $cfg 'block_sram_overwrite' 'false'
            Set-RaSetting $cfg 'video_message_pos_x' '0.030000'
            Set-RaSetting $cfg 'video_message_pos_y' '0.950000'
            Set-RaSetting $cfg 'video_font_enable' 'true'
            Clear-ErisPPLegacyDmix $cfg
            Clear-ErisPPDsp $cfg
            Set-RaSetting $cfg 'network_cmd_enable' 'true'
            Set-RaSetting $cfg 'network_cmd_port' '55355'
            Set-RaSetting $cfg 'savestate_auto_index' 'false'
            Set-RaSetting $cfg 'state_slot' '0'
            Set-RaSetting $cfg 'notification_show_save_state' 'false'
        }
    }
    $pcsxCfg=Join-Path $raDir 'config\PCSX-ReARMed'
    if(Test-Path $pcsxCfg){
        foreach($cfg in Get-ChildItem $pcsxCfg -Filter '*.cfg' -File -ErrorAction SilentlyContinue){
            Set-RaSetting $cfg.FullName 'video_message_pos_x' '0.030000'
            Set-RaSetting $cfg.FullName 'video_message_pos_y' '0.950000'
            Set-RaSetting $cfg.FullName 'video_font_enable' 'true'
            Clear-ErisPPDsp $cfg.FullName
            Clear-ErisPPLegacyDmix $cfg.FullName
            Set-RaSetting $cfg.FullName 'network_cmd_enable' 'true'
            Set-RaSetting $cfg.FullName 'network_cmd_port' '55355'
            Set-RaSetting $cfg.FullName 'savestate_auto_index' 'false'
            Set-RaSetting $cfg.FullName 'state_slot' '0'
            Set-RaSetting $cfg.FullName 'savestate_directory' '/tmp/ra_savestate'
        }
    }
    Set-RaSetting (Join-Path $raDir 'ra-game.cfg') 'savestate_auto_load' 'true'
    Set-RaSetting (Join-Path $raDir 'ra-game.cfg') 'savestate_directory' '/tmp/ra_savestate'
    Set-RaSetting (Join-Path $raDir 'ra-game.cfg') 'savefile_directory' '/tmp/ra_save'
}
function Get-ErisPPUsbFreeBytes([string]$Usb){
    if([string]::IsNullOrWhiteSpace($Usb)){return [int64]0}
    try{$root=[IO.Path]::GetPathRoot($Usb);$drive=New-Object System.IO.DriveInfo -ArgumentList $root;if($drive.IsReady){return [int64]$drive.AvailableFreeSpace}}catch{}
    return [int64]0
}
function Get-ErisPPFirstInstallSpaceStatus([string]$Usb){
    $free=Get-ErisPPUsbFreeBytes $Usb
    $required=[int64]$script:InternalExportMinimumFreeBytes
    $ok=($free -ge $required)
    return [pscustomobject]@{OK=$ok;FreeBytes=$free;RequiredBytes=$required;FreeGiB=[math]::Round(($free/1GB),2);RequiredGiB=$script:InternalExportMinimumFreeGiB}
}
function Assert-ErisPPFirstInstallFreeSpace([string]$Usb){
    if(Test-ErisPPInternalExportComplete $Usb){return}
    $space=Get-ErisPPFirstInstallSpaceStatus $Usb
    if(!$space.OK){throw ("First-install free-space preflight failed. Automatic Internal 20 export needs at least {0:N1} GiB free on the Project Eris USB before installation; only {1:N2} GiB is available. Free space and run the installer again. No first-boot exporter has been staged." -f $space.RequiredGiB,$space.FreeGiB)}
}
function Test-ErisPPElfFile([string]$Path){
    if(!(Test-Path $Path)){return $false}
    try{$fs=[IO.File]::OpenRead($Path);try{$b=New-Object byte[] 4;$n=$fs.Read($b,0,4);return ($n -eq 4 -and $b[0] -eq 0x7f -and $b[1] -eq 0x45 -and $b[2] -eq 0x4c -and $b[3] -eq 0x46)}finally{$fs.Dispose()}}catch{return $false}
}
function Restore-ErisPPFirstBootRetroArch([string]$Usb){
    $ra=Join-Path (Ra-Root $Usb) 'retroarch';$real=$ra+'.erispp_real'
    if(Test-ErisPPElfFile $real){Remove-Item $ra -Force -ErrorAction SilentlyContinue;Move-Item $real $ra -Force;return $true}
    return (Test-ErisPPElfFile $ra)
}
function Restore-ErisPPFirstBootConfigs([string]$Usb){
    $eris=Eris-Root $Usb;$first=Join-Path $eris 'etc\erispp\firstboot';$cfgDir=Join-Path $eris 'CFG'
    foreach($n in @('project_eris_cfg.INI','project_eris_cfg_DEFAULT.INI')){$bak=Join-Path $first ('original_'+$n);$dst=Join-Path $cfgDir $n;if(Test-Path $bak){Copy-Item $bak $dst -Force}}
}
function Test-ErisPPInternalExportComplete([string]$Usb){
    $root=Join-Path $Usb 'PROJECT_ERIS_PP_INTERNAL_EXPORT';$marker=Join-Path $root 'EXPORT_COMPLETE.txt';if(Test-Path $marker){return $true}
    $manifest=Join-Path $root 'manifest.tsv';if(Test-Path $manifest){try{$rows=@(Get-Content $manifest -ErrorAction Stop|Where-Object{$_ -and !$_.StartsWith('#')});if($rows.Count -ge 20){return $true}}catch{}}
    $log=Join-Path $Usb 'PROJECT_ERIS_PP_INTERNAL_EXPORT.log';if(Test-Path $log){try{if(Select-String -Path $log -SimpleMatch 'EXPORT COMPLETE' -Quiet){return $true}}catch{}}
    return $false
}
function Remove-ErisPPExporterDirectory([string]$Usb){
    $eris=Eris-Root $Usb
    $legacy=Join-Path $eris 'SUP\launchers\erispp_internal_export'
    $first=Join-Path $eris 'etc\erispp\firstboot'
    $hidden=Join-Path $first 'exporter'
    $cleanupRoot=Join-Path $first 'cleanup'
    foreach($path in @($legacy,$hidden)){if(Test-Path $path){Remove-Item $path -Recurse -Force -ErrorAction SilentlyContinue}}
    if(Test-Path $cleanupRoot){Remove-Item $cleanupRoot -Recurse -Force -ErrorAction SilentlyContinue}
    return (!(Test-Path $legacy) -and !(Test-Path $hidden) -and !(Test-Path $cleanupRoot))
}
function Clear-ErisPPFirstBootExport([string]$Usb,[bool]$RemoveExporter=$true){
    $eris=Eris-Root $Usb;$root=Join-Path $eris 'etc\erispp';$first=Join-Path $root 'firstboot';$removed=$true
    Restore-ErisPPFirstBootConfigs $Usb
    [void](Restore-ErisPPFirstBootRetroArch $Usb)
    Remove-Item (Join-Path $root 'runtime\FIRST_BOOT_EXPORT_PENDING.flag') -Force -ErrorAction SilentlyContinue
    Remove-Item (Join-Path $root 'runtime\AUTO_INTERNAL_EXPORT.flag') -Force -ErrorAction SilentlyContinue
    if($RemoveExporter){$removed=Remove-ErisPPExporterDirectory $Usb}
    foreach($n in @('original_project_eris_cfg.INI','original_project_eris_cfg_DEFAULT.INI')){Remove-Item (Join-Path $first $n) -Force -ErrorAction SilentlyContinue}
    if($RemoveExporter -and (Test-Path $first)){Remove-Item $first -Recurse -Force -ErrorAction SilentlyContinue}
    if($RemoveExporter){$removed=($removed -and !(Test-Path $first))}
    return $removed
}
function Clear-ErisPPFirstBootExportPermanent([string]$Usb,[string]$Reason='maintenance'){
    $eris=Eris-Root $Usb;$root=Join-Path $eris 'etc\erispp';$legacy=Join-Path $eris 'SUP\launchers\erispp_internal_export';$first=Join-Path $root 'firstboot';$marker=Join-Path $Usb 'PROJECT_ERIS_PP_FIRSTBOOT_EXPORT.txt'
    Restore-ErisPPFirstBootConfigs $Usb
    $retroOk=Restore-ErisPPFirstBootRetroArch $Usb
    Remove-Item (Join-Path $root 'runtime\FIRST_BOOT_EXPORT_PENDING.flag') -Force -ErrorAction SilentlyContinue
    Remove-Item (Join-Path $root 'runtime\AUTO_INTERNAL_EXPORT.flag') -Force -ErrorAction SilentlyContinue
    Remove-Item (Join-Path $root 'runtime\erispp_firstboot_export.sh') -Force -ErrorAction SilentlyContinue
    Remove-Item $legacy -Recurse -Force -ErrorAction SilentlyContinue
    if(Test-Path $first){Remove-Item $first -Recurse -Force -ErrorAction SilentlyContinue}
    # A stale backup must never keep the first-boot shim alive after permanent cleanup.
    $real=Join-Path (Ra-Root $Usb) 'retroarch.erispp_real'
    if((Test-Path $real) -and (Test-ErisPPElfFile (Join-Path (Ra-Root $Usb) 'retroarch'))){Remove-Item $real -Force -ErrorAction SilentlyContinue}
    $menuRemoved=!(Test-Path $legacy);$filesRemoved=!(Test-Path $first);$pendingRemoved=!(Test-Path (Join-Path $root 'runtime\FIRST_BOOT_EXPORT_PENDING.flag')) -and !(Test-Path (Join-Path $root 'runtime\AUTO_INTERNAL_EXPORT.flag'));$runnerRemoved=!(Test-Path (Join-Path $root 'runtime\erispp_firstboot_export.sh'))
    @('Project Eris ++ 1.0.21 first-boot exporter cleanup','Mode=PERMANENTLY_REMOVED',('Reason='+$Reason),('Prepared='+(Get-Date -Format o)),('ExporterMenuRemoved='+$menuRemoved),('ExporterFilesRemoved='+$filesRemoved),('PendingFlagsRemoved='+$pendingRemoved),('FirstBootRunnerRemoved='+$runnerRemoved),('RetroArchRestored='+$retroOk),'RetryPolicy=disabled')|Set-Content $marker -Encoding ASCII
    return ($menuRemoved -and $filesRemoved -and $pendingRemoved -and $runnerRemoved -and $retroOk)
}
function Configure-ErisPPFirstBootExport([string]$Usb,[string]$Backup){
    $eris=Eris-Root $Usb;$root=Join-Path $eris 'etc\erispp';$runtime=Join-Path $root 'runtime';$first=Join-Path $root 'firstboot';$exporter=Join-Path $first 'exporter';$legacy=Join-Path $eris 'SUP\launchers\erispp_internal_export';$marker=Join-Path $Usb 'PROJECT_ERIS_PP_FIRSTBOOT_EXPORT.txt'
    if(Test-ErisPPInternalExportComplete $Usb){$ok=Clear-ErisPPFirstBootExportPermanent $Usb 'internal-export-already-complete';return $(if($ok){'ALREADY_COMPLETE_PERMANENTLY_CLEANED'}else{'ALREADY_COMPLETE_CLEANUP_REQUIRED'})}
    # This assertion happens before any first-boot exporter files, flags, boot configuration or RetroArch shim are written.
    Assert-ErisPPFirstInstallFreeSpace $Usb
    New-Item -ItemType Directory -Force -Path $runtime,$first|Out-Null
    Remove-Item $legacy -Recurse -Force -ErrorAction SilentlyContinue
    if(Test-Path $exporter){Remove-Item $exporter -Recurse -Force -ErrorAction SilentlyContinue}
    Copy-Tree (Join-Path $script:PackageRoot 'console\internal_export') $exporter
    $pending=Join-Path $runtime 'FIRST_BOOT_EXPORT_PENDING.flag'
    foreach($n in @('project_eris_cfg.INI','project_eris_cfg_DEFAULT.INI')){
        $cfg=Join-Path $eris ('CFG\'+$n);$snap=Join-Path $first ('original_'+$n)
        if(Test-Path $cfg){Copy-Item $cfg $snap -Force;Set-IniValue $cfg 'boot_target_stock_UI' '0';Set-IniValue $cfg 'boot_target_stock_RA' '1';Set-IniValue $cfg 'boot_target_stock_BM' '0';Set-IniValue $cfg 'boot_quick' '1'}
    }
    $ra=Join-Path (Ra-Root $Usb) 'retroarch';$real=$ra+'.erispp_real';$shim=Join-Path $script:PackageRoot 'console\firstboot\retroarch'
    if(!(Test-Path $shim)){throw 'First-boot RetroArch shim is missing from the package.'}
    if(Test-ErisPPElfFile $ra){Backup-One $ra $Usb $Backup;if(Test-Path $real){Remove-Item $real -Force};Move-Item $ra $real -Force}
    elseif(!(Test-ErisPPElfFile $real)){throw 'RetroArch first-boot preparation stopped: no valid original RetroArch binary was found.'}
    Copy-Item $shim $ra -Force;Write-LF $ra (Get-Content $ra -Raw)
    'pending'|Set-Content $pending -Encoding ASCII
    Remove-Item (Join-Path $runtime 'AUTO_INTERNAL_EXPORT.flag') -Force -ErrorAction SilentlyContinue
    $space=Get-ErisPPFirstInstallSpaceStatus $Usb
    @('Project Eris ++ 1.0.21 automatic internal export','Mode=AUTO_PENDING',('Prepared='+(Get-Date -Format o)),('PreflightRequiredGiB='+$space.RequiredGiB),('PreflightFreeGiB='+$space.FreeGiB),'NextBoot=RetroArch shim launches Internal 20 exporter before Carousel','SuccessAction=restore normal boot; permanently remove exporter payload; power off','FailureAction=restore normal boot; permanently remove exporter payload; no automatic retry')|Set-Content $marker -Encoding ASCII
    return 'AUTO_PENDING'
}
function Deploy-ProjectErisPP([string]$Usb,[string]$ProfileName,$Lib){
    Assert-ErisPPFirstInstallFreeSpace $Usb
    $eris=Eris-Root $Usb;$stamp=Get-Date -Format 'yyyyMMdd_HHmmss';$backup=Join-Path $Usb "project_eris\backup\erispp_$stamp";New-Item -ItemType Directory -Force -Path $backup|Out-Null
    Configure-RetroArch $Usb $backup;Write-Profile $ProfileName;Sync-InternalExport $Usb $Lib|Out-Null;Import-ExistingCompiledPacks $Lib|Out-Null;Compile-AvailablePacks $Lib|Out-Null;Build-Indexes $Lib
    $launcher=Join-Path $eris 'SUP\launchers\projecterispp';Copy-Tree (Join-Path $script:PackageRoot 'console\launcher') $launcher
    $root=Join-Path $eris 'etc\erispp';New-Item -ItemType Directory -Force -Path $root,(Join-Path $root 'database'),(Join-Path $root 'state'),(Join-Path $root 'profiles\active'),(Join-Path $root 'ui'),(Join-Path $root 'reset'),(Join-Path $root 'runtime')|Out-Null
    Copy-Tree (Join-Path $script:PackageRoot 'console\runtime') (Join-Path $root 'runtime')
    foreach($legacy in @('erispp_audio_prepare.sh','erispp_unlock_audio.sh','erispp_audio_once.sh','erispp_dsp.so','TEST_AUDIO.flag','TEST_AUDIO_DSP.flag','PLAY_CHIME.flag')){Remove-Item (Join-Path (Join-Path $root 'runtime') $legacy) -Force -ErrorAction SilentlyContinue}
    Remove-Item (Join-Path $root 'database\*.fdb') -Force -ErrorAction SilentlyContinue;Remove-Item (Join-Path $root 'ui\games\*.tsv') -Force -ErrorAction SilentlyContinue;Copy-Tree (Join-Path $script:StageRoot 'database') (Join-Path $root 'database');Copy-Tree (Join-Path $script:StageRoot 'ui') (Join-Path $root 'ui');Sync-InstalledBadgeAssets $Usb $Lib|Out-Null
    Remove-Item (Join-Path $Usb 'PROJECT_ERIS_PP_BADGE_RUNTIME.log') -Force -ErrorAction SilentlyContinue;Remove-Item (Join-Path $Usb 'PROJECT_ERIS_PP_AUDIO.log') -Force -ErrorAction SilentlyContinue;Remove-Item (Join-Path $Usb 'PROJECT_ERIS_PP_DSP.log') -Force -ErrorAction SilentlyContinue
    if(Test-Path (Join-Path $script:StageRoot 'content_map.tsv')){Copy-Item (Join-Path $script:StageRoot 'content_map.tsv') (Join-Path $root 'content_map.tsv') -Force};Copy-Item (Join-Path $script:ProfileRoot '*') (Join-Path $root 'profiles\active') -Force
    $gamesTsv=Join-Path $root 'ui\games.tsv';if(!(Test-Path $gamesTsv) -or (Get-Item $gamesTsv).Length -lt 5){$seed=@();foreach($i in Get-InternalCatalog){$seed+="$($i.RaId)`t$($i.Title)`t0`t$(if($i.Set -eq 'NO_SET'){'NO_SET'}else{'PACK'})`tINTERNAL"};$seed|Set-Content $gamesTsv -Encoding ASCII}
    foreach($shellRoot in @((Join-Path $root 'runtime'),(Join-Path $eris 'SUP\launchers\projecterispp'))){if(Test-Path $shellRoot){foreach($sh in Get-ChildItem $shellRoot -Recurse -Filter '*.sh' -File -ErrorAction SilentlyContinue){Write-LF $sh.FullName (Get-Content $sh.FullName -Raw)}}}
    $raLaunch=Join-Path $eris 'SUP\scripts\ra_launch.sh';Backup-One $raLaunch $Usb $backup;Patch-RaLaunch $raLaunch
    $firstBootMode=Configure-ErisPPFirstBootExport $Usb $backup
    @('Project Eris ++ 1.0.21',"Installed=$(Get-Date -Format o)","Profile=$(Safe $ProfileName)","Backup=$backup",('InternalExportFirstBoot='+$firstBootMode))|Set-Content (Join-Path $Usb 'PROJECT_ERIS_PP_INSTALL.txt') -Encoding ASCII
    @('PROJECT ERIS ++ 1.0.21','PlayStation Classic enhancement and local achievement system.','Use the Windows Project Eris ++ installer to add one game, a game folder, or link games already present in the USB games folder.','Game images are never included with Project Eris ++. Use only files you are legally allowed to use.','Copyright Frozsti 2026')|Set-Content (Join-Path $Usb 'PROJECT_ERIS_PP_README.txt') -Encoding ASCII
    return $backup
}
function Get-ErisPPCueReferences([string]$Cue){
    $refs=New-Object System.Collections.ArrayList;if(!(Test-Path $Cue)){return @($refs)};$dir=Split-Path $Cue -Parent
    foreach($line in Get-Content $Cue){$rel=$null;if($line -match '^\s*FILE\s+"([^"]+)"\s+\S+'){$rel=$matches[1]}elseif($line -match '^\s*FILE\s+(.+?)\s+(?:BINARY|WAVE|MP3|MOTOROLA|AIFF)\s*$'){$rel=$matches[1]};if($rel){$p=Join-Path $dir $rel.Trim();if(Test-Path $p){[void]$refs.Add((Get-Item $p).FullName)}}}
    return @($refs)
}
function Copy-CueSet([string]$Cue,[string]$Dest){
    if(!(Test-Path $Cue)){return}
    $fi=Get-Item $Cue;$dir=$fi.DirectoryName;$out=New-Object System.Collections.ArrayList
    foreach($line in Get-Content $fi.FullName){
        $rel=$null;$typ=$null
        if($line -match '^\s*FILE\s+"([^"]+)"\s+(\S+)'){$rel=$matches[1];$typ=$matches[2]}
        elseif($line -match '^\s*FILE\s+(.+?)\s+(BINARY|WAVE|MP3|MOTOROLA|AIFF)\s*$'){$rel=$matches[1];$typ=$matches[2]}
        if($rel){$comp=Join-Path $dir $rel.Trim();if(Test-Path $comp){$name=[IO.Path]::GetFileName($comp);Copy-Item $comp (Join-Path $Dest $name) -Force;[void]$out.Add(('FILE "'+$name+'" '+$typ));continue}}
        [void]$out.Add($line)
    }
    Write-LF (Join-Path $Dest $fi.Name) (($out -join "`n")+"`n")
}
function Get-ErisPPM3uReferences([string]$M3u){
    $refs=New-Object System.Collections.ArrayList;if(!(Test-Path $M3u)){return @($refs)};$dir=Split-Path $M3u -Parent
    foreach($line in Get-Content $M3u){$trim=$line.Trim();if(!$trim -or $trim.StartsWith('#')){continue};$rel=$trim -replace '/','\';$p=Join-Path $dir $rel;if(Test-Path $p){[void]$refs.Add((Get-Item $p).FullName)}}
    return @($refs)
}
function Copy-GameTransferFile([string]$File,[string]$Dest){
    if(!(Test-Path $File)){return}
    $fi=Get-Item $File;$ext=$fi.Extension.ToLowerInvariant()
    if($ext -eq '.cue'){Copy-CueSet $fi.FullName $Dest;return}
    if($ext -eq '.m3u'){
        $out=New-Object System.Collections.ArrayList;foreach($line in Get-Content $fi.FullName){$trim=$line.Trim();if(!$trim -or $trim.StartsWith('#')){[void]$out.Add($line);continue};$ref=Join-Path $fi.DirectoryName ($trim -replace '/','\');if(Test-Path $ref){$rf=Get-Item $ref;if($rf.Extension -ieq '.cue'){Copy-CueSet $rf.FullName $Dest}else{Copy-Item $rf.FullName (Join-Path $Dest $rf.Name) -Force};[void]$out.Add($rf.Name)}else{[void]$out.Add($line)}}
        Write-LF (Join-Path $Dest $fi.Name) (($out -join "`n")+"`n");return
    }
    Copy-Item $fi.FullName (Join-Path $Dest $fi.Name) -Force
}
function Build-ErisPPCacheTitleIndex([scriptblock]$StatusCallback=$null){
    $idx=@{};$seen=@{};$n=0
    foreach($root in Get-CacheRoots){foreach($j in Get-ChildItem $root -Recurse -File -Filter '*.json' -ErrorAction SilentlyContinue|Select-Object -First 10000){$fk=$j.FullName.ToLowerInvariant();if($seen.ContainsKey($fk)){continue};$seen[$fk]=$true;try{$x=Get-Content $j.FullName -Raw -Encoding UTF8|ConvertFrom-Json;if((Get-ErisPPPropertyValue $x 'Title') -and (Get-ErisPPGameIdFromCache $x) -gt 0 -and (Test-ErisPPRawCacheObject $x)){$norm=Normalize-Title ([string]$x.Title);if($norm -and !$idx.ContainsKey($norm)){$idx[$norm]=$j.FullName};$n++;if($StatusCallback -and (($n % 250) -eq 0)){& $StatusCallback ([pscustomobject]@{Phase='CACHE_INDEX';Current=$n;Total=0;Title='';Status='Indexing achievement cache';Detail=('Caches indexed: '+$n);Identity=''})}}}catch{}}}
    $script:CacheTitleIndex=$idx;return $idx.Count
}
function Find-CachePathByTitle([string]$Title){
    $norm=Normalize-Title $Title;if(!$norm){return $null}
    if($null -ne $script:CacheTitleIndex -and $script:CacheTitleIndex.ContainsKey($norm)){$p=[string]$script:CacheTitleIndex[$norm];if(Test-Path $p){return $p}}
    foreach($root in Get-CacheRoots){foreach($j in Get-ChildItem $root -Recurse -File -Filter '*.json' -ErrorAction SilentlyContinue|Select-Object -First 1000){try{$x=Get-Content $j.FullName -Raw|ConvertFrom-Json;if((Get-ErisPPPropertyValue $x 'Title') -and (Normalize-Title ([string](Get-ErisPPPropertyValue $x 'Title'))) -eq $norm -and (Get-ErisPPGameIdFromCache $x) -gt 0 -and (Test-ErisPPRawCacheObject $x)){return $j.FullName}}catch{}}}
    return $null
}
function Find-CacheByTitle([string]$Title){$p=Find-CachePathByTitle $Title;if(!$p){return $null};try{return (Get-Content $p -Raw|ConvertFrom-Json)}catch{return $null}}
function Import-RawCacheFolder([string]$Folder){
    if(!(Test-Path $Folder)){return 0};$n=0
    foreach($j in Get-ChildItem $Folder -Recurse -File -Filter '*.json' -ErrorAction SilentlyContinue){try{$x=Get-Content $j.FullName -Raw -Encoding UTF8|ConvertFrom-Json;$gid=Get-ErisPPGameIdFromCache $x;if($gid -gt 0 -and (Test-ErisPPRawCacheObject $x)){if(Copy-ErisPPFileIfDifferent $j.FullName (Join-Path $script:RawCache ("$gid.json"))){$n++}}}catch{}}
    return $n
}
function Add-GameFiles([string]$Usb,[string[]]$Files,$Lib){
    $dest=Join-Path $Usb 'transfer';New-Item -ItemType Directory -Force -Path $dest|Out-Null
    [void](Seed-ErisPPAchievementLibraryFromUsb $Usb);[void](Refresh-ErisPPAchievementLibraryCatalog);[void](Import-ExistingCompiledPacks $Lib)
    $added=0;$blocked=0;$ready=0;$noSet=0;$already=0;$pending=New-Object System.Collections.ArrayList;$report=New-Object System.Collections.ArrayList;$installed=Get-ErisPPInstalledContentMap $Usb
    [void]$report.Add('Project Eris ++ v1.0.21 add-game achievement preflight');[void]$report.Add('Generated='+(Get-Date -Format o));[void]$report.Add('Policy=FDB-first transaction; runtime FDB/UI is installed before any accepted game is copied to transfer')
    foreach($f in $Files){
        if(!(Test-Path $f)){continue};$fi=Get-Item $f;$title=Safe $fi.BaseName
        $g=[pscustomobject]@{Key='external:'+$fi.Name.ToLowerInvariant();Source='USB';Slot=0;Title=$title;Path='';RaId=0;OfficialSet='UNKNOWN';PackStatus='Pack needed';Supported=0;Total=0}
        $pre=Ensure-ErisPPGamePack $fi.FullName $g
        if(!$pre.Accepted){$blocked++;[void]$report.Add("BLOCKED`t$($fi.Name)`t$($pre.Detail)");continue}
        $g.Path=Join-Path $dest $fi.Name;$gId=[int]$g.RaId;$gKey=[string]$g.Key;$baseKey=$fi.Name.ToLowerInvariant();$existingGame=@($Lib.games|Where-Object{($gId -gt 0) -and ($_.Source -ne 'Internal') -and ([int]$_.RaId -eq $gId)}|Select-Object -First 1);$alreadyMapped=($gId -gt 0 -and $installed.ByBase.ContainsKey($baseKey) -and [int]$installed.ByBase[$baseKey] -eq $gId);if($alreadyMapped){$already++;if($existingGame.Count -gt 0){$eg=$existingGame[0];$eg.Title=$g.Title;$eg.OfficialSet=$g.OfficialSet;$eg.PackStatus=$g.PackStatus;$eg.Supported=$g.Supported;$eg.Total=$g.Total}else{$existingBase=if($installed.ByGidBase.ContainsKey([string]$gId)){[string]$installed.ByGidBase[[string]$gId]}else{$fi.Name};$g.Path=Join-Path $dest $existingBase;$Lib.games=@($Lib.games)+$g};[void]$report.Add("ALREADY_PRESENT`t$($fi.Name)`tRA=$gId`tExisting content mapping retained")}else{$Lib.games=@($Lib.games|Where-Object{$_.Key -ne $gKey})+$g;$added++}
        if($g.OfficialSet -eq 'NO_SET'){$noSet++}else{$ready++}
        if(!$alreadyMapped){[void]$pending.Add([pscustomobject]@{File=$fi.FullName;Name=$fi.Name;Game=$g;Pre=$pre})}
        [void]$report.Add("FDB_READY`t$($fi.Name)`tRA=$($g.RaId)`t$($pre.Status)`t$($pre.Detail)")
    }
    Save-Library $Lib;Build-Indexes $Lib
    if($added -gt 0){
        [void](Deploy-StagedOnly $Usb $Lib)
        [void]$report.Add('FDB_INSTALL`tUSB runtime database/UI updated successfully BEFORE transfer copy; linked badges persisted back to local library')
        foreach($x in $pending){Copy-GameTransferFile ([string]$x.File) $dest;[void]$report.Add("TRANSFERRED`t$($x.Name)`tRA=$($x.Game.RaId)`t$($x.Pre.Status)")}
    }
    $rp=Join-Path $Usb 'PROJECT_ERIS_PP_LAST_ADD_GAME.txt';$report|Set-Content $rp -Encoding UTF8
    return [pscustomobject]@{Added=$added;AlreadyPresent=$already;Blocked=$blocked;Ready=$ready;NoSet=$noSet;Report=$rp}
}
function Get-ErisPPDiscInfo([string]$File){
    $fi=Get-Item $File;$base=$fi.BaseName;$stem=$base;$order=0;$isDisc=$false;$groupDir=$fi.DirectoryName
    $m=[regex]::Match($base,'(?i)(?:^|[\s._\-\(\[])(?:disc|disk|cd)\s*[-_. ]*([0-9]+|[ivx]+|[a-z])(?:\s*(?:of|/)\s*\d+)?(?:[\s._\-\)\]]|$)')
    if($m.Success){$isDisc=$true;$tok=$m.Groups[1].Value.ToLowerInvariant();$stem=($base.Remove($m.Index,$m.Length) -replace '[\s._-]+$','').Trim();if(!$stem){$stem=$base};if($tok -match '^\d+$'){$order=[int]$tok}else{$roman=@{i=1;ii=2;iii=3;iv=4;v=5;vi=6;vii=7;viii=8;ix=9;x=10};if($roman.ContainsKey($tok)){$order=$roman[$tok]}elseif($tok.Length -eq 1){$order=([int][char]$tok)-96}}}
    if(!$isDisc){$leaf=Split-Path $fi.DirectoryName -Leaf;$dm=[regex]::Match($leaf,'(?i)^(?:disc|disk|cd)\s*[-_. ]*([0-9]+|[ivx]+|[a-z])$');if($dm.Success){$isDisc=$true;$tok=$dm.Groups[1].Value.ToLowerInvariant();$parent=Split-Path $fi.DirectoryName -Parent;if($parent){$groupDir=$parent;$stem=Split-Path $parent -Leaf};if($tok -match '^\d+$'){$order=[int]$tok}else{$roman=@{i=1;ii=2;iii=3;iv=4;v=5;vi=6;vii=7;viii=8;ix=9;x=10};if($roman.ContainsKey($tok)){$order=$roman[$tok]}elseif($tok.Length -eq 1){$order=([int][char]$tok)-96}}}}
    return [pscustomobject]@{Stem=(Safe $stem);Order=$order;IsDisc=$isDisc;GroupDir=$groupDir}
}
function Get-ErisPPLibraryScan([string]$Folder,[scriptblock]$StatusCallback=$null){
    if(!(Test-Path $Folder)){throw 'Library folder does not exist.'}
    $supported=@('.cue','.chd','.pbp','.iso','.m3u');$files=New-Object System.Collections.ArrayList;$seenFiles=0
    foreach($f in Get-ChildItem $Folder -Recurse -File -ErrorAction SilentlyContinue){$seenFiles++;if($supported -contains $f.Extension.ToLowerInvariant()){[void]$files.Add($f)};if($StatusCallback -and (($seenFiles % 200) -eq 0)){& $StatusCallback ([pscustomobject]@{Phase='SCAN';Current=$seenFiles;Total=0;Title='';Status='Scanning';Detail=('Files scanned: '+$seenFiles);Identity=''})}}
    $items=New-Object System.Collections.ArrayList;$issues=New-Object System.Collections.ArrayList;$consumed=@{};$m3us=@($files|Where-Object{$_.Extension -ieq '.m3u'}|Sort-Object FullName)
    foreach($m3u in $m3us){$refs=@(Get-ErisPPM3uReferences $m3u.FullName);if($refs.Count -eq 0){[void]$issues.Add([pscustomobject]@{Title=$m3u.BaseName;Type='M3U';Detail='M3U does not reference any existing game files';Path=$m3u.FullName});continue};$dup=$false;foreach($r in $refs){if($consumed.ContainsKey($r.ToLowerInvariant())){$dup=$true}};if($dup){[void]$issues.Add([pscustomobject]@{Title=$m3u.BaseName;Type='M3U';Detail='M3U references a disc that is already claimed by another M3U';Path=$m3u.FullName});continue};foreach($r in $refs){$consumed[$r.ToLowerInvariant()]=$true};$id=$m3u.FullName.ToLowerInvariant();[void]$items.Add([pscustomobject]@{Identity=$id;Title=(Safe $m3u.BaseName);Type='M3U';LaunchFile=$m3u.FullName;DiscFiles=@($refs);DiscCount=$refs.Count;MultiDisc=($refs.Count -gt 1);GeneratedM3u=$false;Root=$Folder})}
    $groups=@{};$singles=New-Object System.Collections.ArrayList
    foreach($f in @($files|Where-Object{$_.Extension -ine '.m3u'})){
        if($consumed.ContainsKey($f.FullName.ToLowerInvariant())){continue};$d=Get-ErisPPDiscInfo $f.FullName
        if($d.IsDisc){$key=([string]$d.GroupDir).ToLowerInvariant()+'|'+(Normalize-Title ([string]$d.Stem));if(!$groups.ContainsKey($key)){$groups[$key]=New-Object System.Collections.ArrayList};[void]$groups[$key].Add([pscustomobject]@{File=$f;Disc=$d})}else{[void]$singles.Add($f)}
    }
    foreach($key in $groups.Keys){$g=@($groups[$key]|Sort-Object @{Expression={$_.Disc.Order}},@{Expression={$_.File.Name}});if($g.Count -gt 1){$title=Safe ([string]$g[0].Disc.Stem);if(!$title){$title=$g[0].File.BaseName};$discFiles=@($g|ForEach-Object{$_.File.FullName});[void]$items.Add([pscustomobject]@{Identity=('auto-m3u:'+($key));Title=$title;Type='AUTO_M3U';LaunchFile=$g[0].File.FullName;DiscFiles=$discFiles;DiscCount=$discFiles.Count;MultiDisc=$true;GeneratedM3u=$true;Root=$Folder})}else{[void]$singles.Add($g[0].File)}}
    foreach($f in @($singles|Sort-Object FullName)){[void]$items.Add([pscustomobject]@{Identity=$f.FullName.ToLowerInvariant();Title=(Safe $f.BaseName);Type=$f.Extension.TrimStart('.').ToUpperInvariant();LaunchFile=$f.FullName;DiscFiles=@($f.FullName);DiscCount=1;MultiDisc=$false;GeneratedM3u=$false;Root=$Folder})}
    $multi=@($items|Where-Object{$_.MultiDisc}).Count;return [pscustomobject]@{Root=$Folder;Items=@($items|Sort-Object Title);Issues=@($issues);SupportedFiles=$files.Count;FilesVisited=$seenFiles;Games=$items.Count;MultiDisc=$multi;SingleDisc=($items.Count-$multi);IssuesCount=$issues.Count}
}
function Get-ErisPPSafeFileStem([string]$Text){$s=Safe $Text;$s=$s -replace '[\\/:*?"<>|]','_';$s=$s.Trim().TrimEnd('.');if(!$s){$s='Game'};if($s.Length -gt 80){$s=$s.Substring(0,80)};return $s}
function Reserve-ErisPPTransferName([string]$Name,[string]$Title,[string]$Dest,[hashtable]$Reserved){
    $candidate=[IO.Path]::GetFileName($Name);$key=$candidate.ToLowerInvariant();if(!$Reserved.ContainsKey($key) -and !(Test-Path (Join-Path $Dest $candidate))){$Reserved[$key]=$true;return $candidate}
    $prefix=Get-ErisPPSafeFileStem $Title;$candidate=$prefix+' - '+[IO.Path]::GetFileName($Name);$key=$candidate.ToLowerInvariant();$n=2;while($Reserved.ContainsKey($key) -or (Test-Path (Join-Path $Dest $candidate))){$candidate=$prefix+' - '+$n+' - '+[IO.Path]::GetFileName($Name);$key=$candidate.ToLowerInvariant();$n++};$Reserved[$key]=$true;return $candidate
}
function Prepare-ErisPPCueTransfer([string]$Cue,[string]$Title,[string]$Stage,[string]$Dest,[hashtable]$Reserved,[hashtable]$SourceMap,[System.Collections.ArrayList]$Plan){
    $fi=Get-Item $Cue;$cueName=Reserve-ErisPPTransferName $fi.Name $Title $Dest $Reserved;$out=New-Object System.Collections.ArrayList
    foreach($line in Get-Content $fi.FullName){$rel=$null;$typ=$null;if($line -match '^\s*FILE\s+"([^"]+)"\s+(\S+)'){$rel=$matches[1];$typ=$matches[2]}elseif($line -match '^\s*FILE\s+(.+?)\s+(BINARY|WAVE|MP3|MOTOROLA|AIFF)\s*$'){$rel=$matches[1];$typ=$matches[2]};if($rel){$src=Join-Path $fi.DirectoryName $rel.Trim();if(!(Test-Path $src)){throw ('CUE component is missing: '+$src)};$full=(Get-Item $src).FullName;$sk=$full.ToLowerInvariant();if($SourceMap.ContainsKey($sk)){$assetName=[string]$SourceMap[$sk]}else{$assetName=Reserve-ErisPPTransferName ([IO.Path]::GetFileName($full)) $Title $Dest $Reserved;$SourceMap[$sk]=$assetName;[void]$Plan.Add([pscustomobject]@{Source=$full;Name=$assetName;Generated=$false})};[void]$out.Add(('FILE "'+$assetName+'" '+$typ));continue};[void]$out.Add($line)}
    $cueStage=Join-Path $Stage $cueName;Write-LF $cueStage (($out -join "`n")+"`n");[void]$Plan.Add([pscustomobject]@{Source=$cueStage;Name=$cueName;Generated=$true});$SourceMap[$fi.FullName.ToLowerInvariant()]=$cueName;return $cueName
}
function Prepare-ErisPPDiscTransfer([string]$File,[string]$Title,[string]$Stage,[string]$Dest,[hashtable]$Reserved,[hashtable]$SourceMap,[System.Collections.ArrayList]$Plan){
    $fi=Get-Item $File;$sk=$fi.FullName.ToLowerInvariant();if($SourceMap.ContainsKey($sk)){return [string]$SourceMap[$sk]};if($fi.Extension -ieq '.cue'){return (Prepare-ErisPPCueTransfer $fi.FullName $Title $Stage $Dest $Reserved $SourceMap $Plan)};$name=Reserve-ErisPPTransferName $fi.Name $Title $Dest $Reserved;$SourceMap[$sk]=$name;[void]$Plan.Add([pscustomobject]@{Source=$fi.FullName;Name=$name;Generated=$false});return $name
}
function Prepare-ErisPPLibraryTransferItem($Item,[string]$Stage,[string]$Dest,[hashtable]$Reserved){
    $sourceMap=@{};$plan=New-Object System.Collections.ArrayList;$launchName='';$title=[string]$Item.Title
    if($Item.Type -eq 'M3U'){$out=New-Object System.Collections.ArrayList;$fi=Get-Item ([string]$Item.LaunchFile);foreach($line in Get-Content $fi.FullName){$trim=$line.Trim();if(!$trim -or $trim.StartsWith('#')){[void]$out.Add($line);continue};$ref=Join-Path $fi.DirectoryName ($trim -replace '/','\');if(!(Test-Path $ref)){throw ('M3U reference is missing: '+$ref)};$n=Prepare-ErisPPDiscTransfer $ref $title $Stage $Dest $Reserved $sourceMap $plan;[void]$out.Add($n)};$launchName=Reserve-ErisPPTransferName $fi.Name $title $Dest $Reserved;$m3uStage=Join-Path $Stage $launchName;Write-LF $m3uStage (($out -join "`n")+"`n");[void]$plan.Add([pscustomobject]@{Source=$m3uStage;Name=$launchName;Generated=$true})}
    elseif($Item.Type -eq 'AUTO_M3U'){$out=New-Object System.Collections.ArrayList;foreach($d in @($Item.DiscFiles)){$n=Prepare-ErisPPDiscTransfer ([string]$d) $title $Stage $Dest $Reserved $sourceMap $plan;[void]$out.Add($n)};$launchName=Reserve-ErisPPTransferName ((Get-ErisPPSafeFileStem $title)+'.m3u') $title $Dest $Reserved;$m3uStage=Join-Path $Stage $launchName;Write-LF $m3uStage (($out -join "`n")+"`n");[void]$plan.Add([pscustomobject]@{Source=$m3uStage;Name=$launchName;Generated=$true})}
    else{$launchName=Prepare-ErisPPDiscTransfer ([string]$Item.LaunchFile) $title $Stage $Dest $Reserved $sourceMap $plan}
    return [pscustomobject]@{LaunchName=$launchName;Stage=$Stage;Files=@($plan)}
}
function Import-ErisPPGameLibrary([string]$Usb,[string]$Folder,$Lib,$Scan=$null,[scriptblock]$StatusCallback=$null){
    if($null -eq $Scan){$Scan=Get-ErisPPLibraryScan $Folder $StatusCallback};$dest=Join-Path $Usb 'transfer';New-Item -ItemType Directory -Force -Path $dest|Out-Null
    [void](Seed-ErisPPAchievementLibraryFromUsb $Usb);[void](Refresh-ErisPPAchievementLibraryCatalog);[void](Import-ExistingCompiledPacks $Lib)
    $report=New-Object System.Collections.ArrayList;[void]$report.Add('Project Eris ++ v1.0.21 recursive library import');[void]$report.Add('Generated='+(Get-Date -Format o));[void]$report.Add('Root='+$Folder);[void]$report.Add(('ScanGames='+$Scan.Games+' SingleDisc='+$Scan.SingleDisc+' MultiDisc='+$Scan.MultiDisc+' Issues='+$Scan.IssuesCount));[void]$report.Add('Policy=M3U first; CUE dependencies preserved; auto M3U for detected multi-disc; FDB installed before transfer')
    foreach($i in @($Scan.Issues)){[void]$report.Add("ATTENTION`t$($i.Title)`t$($i.Type)`t$($i.Detail)`t$($i.Path)")}
    $reserved=@{};if(Test-Path $dest){foreach($f in Get-ChildItem $dest -File -ErrorAction SilentlyContinue){$reserved[$f.Name.ToLowerInvariant()]=$true}}
    if($StatusCallback){& $StatusCallback ([pscustomobject]@{Phase='CACHE_INDEX';Current=0;Total=0;Title='';Status='Indexing achievement cache';Detail='Local RA caches are indexed once for fast bulk import';Identity=''})};[void](Build-ErisPPCacheTitleIndex $StatusCallback)
    $stageBase=Join-Path $script:AppRoot ('LibraryTransferStaging\'+(Get-Date -Format 'yyyyMMdd_HHmmss'));New-Item -ItemType Directory -Force -Path $stageBase|Out-Null
    $pending=New-Object System.Collections.ArrayList;$added=0;$already=0;$blocked=0;$ready=0;$noSet=0;$idx=0;$total=[Math]::Max(1,[int]$Scan.Games);$installed=Get-ErisPPInstalledContentMap $Usb
    foreach($item in @($Scan.Items)){$idx++;if($StatusCallback){& $StatusCallback ([pscustomobject]@{Phase='PREFLIGHT';Current=$idx;Total=$total;Title=$item.Title;Status='FDB preflight';Detail=('Game '+$idx+' of '+$total);Identity=$item.Identity})};$g=[pscustomobject]@{Key=('external-library:'+$item.Identity);Source='USB';Slot=0;Title=[string]$item.Title;Path='';RaId=0;OfficialSet='UNKNOWN';PackStatus='Pack needed';Supported=0;Total=0};$pre=Ensure-ErisPPGamePack ([string]$item.LaunchFile) $g;if(!$pre.Accepted){$blocked++;[void]$report.Add("BLOCKED`t$($item.Title)`t$($item.Type)`t$($pre.Detail)");if($StatusCallback){& $StatusCallback ([pscustomobject]@{Phase='GAME';Current=$idx;Total=$total;Title=$item.Title;Status='Blocked';Detail=$pre.Detail;Identity=$item.Identity})};continue};$itemStage=Join-Path $stageBase ('g'+$idx.ToString('0000'));New-Item -ItemType Directory -Force -Path $itemStage|Out-Null;try{$prep=Prepare-ErisPPLibraryTransferItem $item $itemStage $dest $reserved}catch{$blocked++;[void]$report.Add("BLOCKED`t$($item.Title)`tTRANSFER_PREP`t$($_.Exception.Message)");if($StatusCallback){& $StatusCallback ([pscustomobject]@{Phase='GAME';Current=$idx;Total=$total;Title=$item.Title;Status='Blocked';Detail=$_.Exception.Message;Identity=$item.Identity})};continue};$g.Path=Join-Path $dest $prep.LaunchName;$gKey=[string]$g.Key;$gId=[int]$g.RaId;$existingGame=@($Lib.games|Where-Object{($gId -gt 0) -and ($_.Source -ne 'Internal') -and ([int]$_.RaId -eq $gId)}|Select-Object -First 1);$launchKey=([string]$prep.LaunchName).ToLowerInvariant();$alreadyInstalled=($gId -gt 0 -and $installed.ByBase.ContainsKey($launchKey) -and [int]$installed.ByBase[$launchKey] -eq $gId);if($alreadyInstalled){$already++;if($existingGame.Count -gt 0){$eg=$existingGame[0];$eg.Title=$g.Title;$eg.OfficialSet=$g.OfficialSet;$eg.PackStatus=$g.PackStatus;$eg.Supported=$g.Supported;$eg.Total=$g.Total}else{$existingBase=if($installed.ByGidBase.ContainsKey([string]$gId)){[string]$installed.ByGidBase[[string]$gId]}else{$prep.LaunchName};$g.Path=Join-Path $dest $existingBase;$Lib.games=@($Lib.games)+$g};[void]$report.Add("ALREADY_PRESENT`t$($item.Title)`t$($item.Type)`tRA=$gId`tInstalled achievement identity reused")}else{$Lib.games=@($Lib.games|Where-Object{$_.Key -ne $gKey})+$g;$added++;[void]$pending.Add([pscustomobject]@{Item=$item;Game=$g;Pre=$pre;Prep=$prep})};if($g.OfficialSet -eq 'NO_SET'){$noSet++}else{$ready++};[void]$report.Add("FDB_READY`t$($item.Title)`t$($item.Type)`tRA=$($g.RaId)`t$($pre.Status)`tDiscs=$($item.DiscCount)");if($StatusCallback){& $StatusCallback ([pscustomobject]@{Phase='GAME';Current=$idx;Total=$total;Title=$item.Title;Status='FDB ready';Detail=($pre.Status+'; '+$item.DiscCount+' disc(s)');Identity=$item.Identity})}}
    Save-Library $Lib;Build-Indexes $Lib
    if($added -gt 0){if($StatusCallback){& $StatusCallback ([pscustomobject]@{Phase='DEPLOY';Current=0;Total=$added;Title='';Status='Installing FDB';Detail='Runtime database/UI is updated first';Identity=''})};[void](Deploy-StagedOnly $Usb $Lib);[void]$report.Add('FDB_INSTALL`tUSB runtime database/UI updated BEFORE library transfer copy');$copyIndex=0;foreach($x in $pending){$copyIndex++;foreach($pf in @($x.Prep.Files)){Copy-Item ([string]$pf.Source) (Join-Path $dest ([string]$pf.Name)) -Force};[void]$report.Add("TRANSFERRED`t$($x.Item.Title)`t$($x.Prep.LaunchName)`tRA=$($x.Game.RaId)`tDiscs=$($x.Item.DiscCount)");if($StatusCallback){& $StatusCallback ([pscustomobject]@{Phase='TRANSFER';Current=$copyIndex;Total=$added;Title=$x.Item.Title;Status='Copying to transfer';Detail=$x.Prep.LaunchName;Identity=$x.Item.Identity})}}}
    $rp=Join-Path $Usb 'PROJECT_ERIS_PP_LAST_LIBRARY_IMPORT.txt';$report|Set-Content $rp -Encoding UTF8;return [pscustomobject]@{Scanned=$Scan.Games;SingleDisc=$Scan.SingleDisc;MultiDisc=$Scan.MultiDisc;Issues=$Scan.IssuesCount;Added=$added;AlreadyPresent=$already;Blocked=$blocked;Ready=$ready;NoSet=$noSet;Report=$rp;Scan=$Scan}
}
function Get-ErisPPHttpBytes([string]$Url,[int]$TimeoutMs=7000){
    if([string]::IsNullOrWhiteSpace($Url)){return $null}
    try{[Net.ServicePointManager]::SecurityProtocol=[Net.SecurityProtocolType]::Tls12}catch{};$req=[Net.HttpWebRequest]::Create($Url);$req.Timeout=$TimeoutMs;$req.ReadWriteTimeout=$TimeoutMs;$req.UserAgent='ProjectErisPlusPlus/1.0.21'
    $resp=$null;$stream=$null;$ms=$null
    try{$resp=$req.GetResponse();$stream=$resp.GetResponseStream();$ms=New-Object IO.MemoryStream;$stream.CopyTo($ms);return $ms.ToArray()}catch{return $null}finally{if($stream){$stream.Dispose()};if($resp){$resp.Close()};if($ms){$ms.Dispose()}}
}
function Save-ErisPPBadgeBmp([byte[]]$Bytes,[string]$Path){
    if($null -eq $Bytes -or $Bytes.Length -lt 64){return $false}
    try{
        Add-Type -AssemblyName System.Drawing -ErrorAction SilentlyContinue
        $ms=New-Object IO.MemoryStream;$ms.Write($Bytes,0,$Bytes.Length);$ms.Position=0;$img=[Drawing.Image]::FromStream($ms,$true,$true)
        $bmp=New-Object Drawing.Bitmap -ArgumentList @($img.Width,$img.Height,[Drawing.Imaging.PixelFormat]::Format24bppRgb);$g=[Drawing.Graphics]::FromImage($bmp);$g.DrawImage($img,0,0,$img.Width,$img.Height)
        New-Item -ItemType Directory -Force -Path (Split-Path $Path -Parent)|Out-Null;$bmp.Save($Path,[Drawing.Imaging.ImageFormat]::Bmp)
        $g.Dispose();$bmp.Dispose();$img.Dispose();$ms.Dispose();return (Test-Path $Path)
    }catch{return $false}
}
function Sync-ErisPPUiBadges([string]$UiRoot,[int]$Gid,[string]$CacheFile){
    $tsv=Join-Path $UiRoot ("games\$Gid.tsv");if(!(Test-Path $tsv) -or !(Test-Path $CacheFile)){return [pscustomobject]@{Linked=0;Downloaded=0;Failed=0}}
    try{$cache=Get-Content $CacheFile -Raw -Encoding UTF8|ConvertFrom-Json}catch{return [pscustomobject]@{Linked=0;Downloaded=0;Failed=0}}
    $by=@{};foreach($a in @(Core-Achievements $cache)){try{$id=0;$rawId=Get-ErisPPPropertyValue $a 'ID';if($null -eq $rawId){$rawId=Get-ErisPPPropertyValue $a 'id'};if($null -ne $rawId){$id=[int]$rawId};if($id -gt 0){$by[$id]=$a}}catch{}}
    $out=New-Object System.Collections.ArrayList;$linked=0;$downloaded=0;$failed=0
    foreach($line in Get-Content $tsv){
        $f=$line -split "`t",6;if($f.Count -lt 4){[void]$out.Add($line);continue}
        $id=0;try{$id=[int]$f[0]}catch{};$badge='';$locked=''
        if($id -gt 0 -and $by.ContainsKey($id)){
            $a=$by[$id];$bn='';if($a.PSObject.Properties.Name -contains 'BadgeName'){$bn=Safe ([string]$a.BadgeName)}
            if($bn){
                $dir=Join-Path $UiRoot ("badges\$Gid");$bmp=Join-Path $dir ($bn+'.bmp');$lbmp=Join-Path $dir ($bn+'_lock.bmp')
                if(!(Test-Path $bmp)){
                    $url='';if($a.PSObject.Properties.Name -contains 'BadgeURL'){$url=[string]$a.BadgeURL};if(!$url){$url='https://media.retroachievements.org/Badge/'+$bn+'.png'}
                    $bytes=Get-ErisPPHttpBytes $url;if(Save-ErisPPBadgeBmp $bytes $bmp){$downloaded++}else{$failed++}
                }
                if(Test-Path $bmp){if(!(Test-Path $lbmp)){Copy-Item $bmp $lbmp -Force};$badge=('badges/'+$Gid+'/'+$bn+'.bmp');$locked=('badges/'+$Gid+'/'+$bn+'_lock.bmp');$linked++}
            }
        }
        while($f.Count -lt 6){$f+= ''};$f[4]=$badge;$f[5]=$locked;[void]$out.Add(($f -join "`t"))
    }
    $out|Set-Content $tsv -Encoding ASCII
    return [pscustomobject]@{Linked=$linked;Downloaded=$downloaded;Failed=$failed}
}
function Sync-InstalledBadgeAssets([string]$Usb,$Lib){
    $ui=Join-Path (Eris-Root $Usb) 'etc\erispp\ui';if(!(Test-Path $ui)){return 0};$linked=0;$downloaded=0;$failed=0;$games=0
    foreach($g in @($Lib.games)){$gid=0;try{$gid=[int]$g.RaId}catch{};if($gid -le 0){continue};$tsv=Join-Path $ui ("games\$gid.tsv");if(!(Test-Path $tsv)){continue};$c=Find-CacheJson $gid ([string]$g.Title);if(!$c){continue};$r=Sync-ErisPPUiBadges $ui $gid $c;$linked+=$r.Linked;$downloaded+=$r.Downloaded;$failed+=$r.Failed;$games++}
    @('Project Eris ++ 1.0.21 badge sync',('Generated='+(Get-Date -Format o)),('Games='+$games),('Linked='+$linked),('Downloaded='+$downloaded),('Failed='+$failed))|Set-Content (Join-Path $Usb 'PROJECT_ERIS_PP_BADGES_1.0.21.txt') -Encoding ASCII
    return $linked
}

function Test-Preflight([string]$Usb){
    $r=@();$eris=Eris-Root $Usb
    $checks=@(
        [pscustomobject]@{Name='Project Eris configuration';Path=(Join-Path $eris 'CFG\project_eris_cfg.INI')},
        [pscustomobject]@{Name='Carousel RetroArch integration';Path=(Join-Path $eris 'FUNC\0030_retroarch.funcs')},
        [pscustomobject]@{Name='RetroArch launcher';Path=(Join-Path $eris 'SUP\scripts\ra_launch.sh')},
        [pscustomobject]@{Name='RetroArch configuration';Path=(Join-Path (Ra-Root $Usb) 'config\retroarch\retroarch.cfg')}
    )
    foreach($c in $checks){$r+=[pscustomobject]@{Name=$c.Name;OK=(Test-Path $c.Path);Detail=$c.Path}}
    if(!(Test-ErisPPInternalExportComplete $Usb)){$space=Get-ErisPPFirstInstallSpaceStatus $Usb;$r+=[pscustomobject]@{Name=('Internal 20 staging space ('+$space.RequiredGiB.ToString('0.0')+' GiB free minimum)');OK=$space.OK;Detail=('Available: '+$space.FreeGiB.ToString('0.00')+' GiB')}}
    try{$probe=Join-Path $Usb '.erispp_write_test';[IO.File]::WriteAllText($probe,'ok');Remove-Item $probe -Force;$r+=[pscustomobject]@{Name='USB writable';OK=$true;Detail=$Usb}}catch{$r+=[pscustomobject]@{Name='USB writable';OK=$false;Detail=$_.Exception.Message}}
    try{$selfCache=Join-Path $PSScriptRoot 'bundled_cache\11278.json';$selfRoot=Join-Path $script:AppRoot 'SelfTest';[void](Test-ErisPPRichCompilerSelfTest $selfCache $selfRoot);$r+=[pscustomobject]@{Name='Achievement compiler 124/124 self-test';OK=$true;Detail='Gran Turismo 2 reference pack'}}catch{$r+=[pscustomobject]@{Name='Achievement compiler 124/124 self-test';OK=$false;Detail=$_.Exception.Message}}
    try{[void](Test-ErisPPCacheSchemaCompatibility);$r+=[pscustomobject]@{Name='Achievement cache schema compatibility';OK=$true;Detail='Missing per-set Achievements is safe'}}catch{$r+=[pscustomobject]@{Name='Achievement cache schema compatibility';OK=$false;Detail=$_.Exception.Message}}
    return $r
}
function Install-PCShortcuts {
    $programDir=Join-Path $env:LOCALAPPDATA 'Programs\Project Eris PlusPlus'
    $dest=$null
    try{$pkg=(Resolve-Path $script:PackageRoot).Path.TrimEnd('\');$prog=$programDir.TrimEnd('\');if($pkg.StartsWith($prog,[System.StringComparison]::OrdinalIgnoreCase)){$dest=$script:PackageRoot}}catch{}
    if(!$dest){
        $dest=Join-Path $script:AppRoot 'InstalledPackage'
        try{if((Resolve-Path $script:PackageRoot).Path -ne (Resolve-Path $dest -ErrorAction SilentlyContinue).Path){if(Test-Path $dest){Remove-Item $dest -Recurse -Force};Copy-Item $script:PackageRoot $dest -Recurse -Force}}catch{if(Test-Path $dest){Remove-Item $dest -Recurse -Force -ErrorAction SilentlyContinue};Copy-Item $script:PackageRoot $dest -Recurse -Force}
    }
    $ws=New-Object -ComObject WScript.Shell;$icon=Join-Path $dest 'assets\projecterispp.ico';$target=Join-Path $dest 'windows\ProjectErisPlusPlus.DesktopWizard.ps1'
    $desk=[Environment]::GetFolderPath('Desktop');foreach($oldName in @('Project Eris ++ Wizard.lnk','Project Eris ++ Reset Lab.lnk')){$old=Join-Path $desk $oldName;if(Test-Path $old){Remove-Item $old -Force -ErrorAction SilentlyContinue}}
    $lnk=Join-Path $desk 'Project Eris ++.lnk';$sc=$ws.CreateShortcut($lnk);$sc.TargetPath='powershell.exe';$sc.Arguments='-NoLogo -NoProfile -ExecutionPolicy Bypass -File "'+$target+'"';$sc.WorkingDirectory=(Split-Path $target -Parent);$sc.Description='Project Eris ++';if(Test-Path $icon){$sc.IconLocation=$icon};$sc.Save()
    $sm=Join-Path $env:APPDATA 'Microsoft\Windows\Start Menu\Programs\Project Eris ++';New-Item -ItemType Directory -Force -Path $sm|Out-Null;$sml=Join-Path $sm 'Project Eris ++.lnk';$sc2=$ws.CreateShortcut($sml);$sc2.TargetPath='powershell.exe';$sc2.Arguments=$sc.Arguments;$sc2.WorkingDirectory=$sc.WorkingDirectory;$sc2.Description='Project Eris ++';if(Test-Path $icon){$sc2.IconLocation=$icon};$sc2.Save()
}
function Get-ProfileName {
    $p=Join-Path $script:ProfileRoot 'profile.tsv'
    if(Test-Path $p){foreach($line in Get-Content $p){$f=$line -split "`t",2;if($f.Count -eq 2 -and $f[0] -eq 'display'){return $f[1]}}}
    return 'Player'
}
function Deploy-StagedOnly([string]$Usb,$Lib){
    Build-Indexes $Lib
    $eris=Eris-Root $Usb;$root=Join-Path $eris 'etc\erispp';$usbDb=Join-Path $root 'database';$usbUiGames=Join-Path $root 'ui\games'
    New-Item -ItemType Directory -Force -Path $root,$usbDb,(Join-Path $root 'ui'),$usbUiGames,(Join-Path $root 'runtime')|Out-Null
    Remove-Item (Join-Path $usbDb '*.fdb') -Force -ErrorAction SilentlyContinue
    Remove-Item (Join-Path $usbUiGames '*.tsv') -Force -ErrorAction SilentlyContinue
    Copy-Tree (Join-Path $script:PackageRoot 'console\runtime') (Join-Path $root 'runtime')
    if(!(Test-Path (Join-Path $root 'runtime\FIRST_BOOT_EXPORT_PENDING.flag'))){Remove-Item (Join-Path $root 'runtime\erispp_firstboot_export.sh') -Force -ErrorAction SilentlyContinue}
    foreach($legacy in @('erispp_audio_prepare.sh','erispp_unlock_audio.sh','erispp_audio_once.sh','erispp_dsp.so','TEST_AUDIO.flag','TEST_AUDIO_DSP.flag','PLAY_CHIME.flag')){Remove-Item (Join-Path (Join-Path $root 'runtime') $legacy) -Force -ErrorAction SilentlyContinue}
    Copy-Tree (Join-Path $script:StageRoot 'database') $usbDb
    Copy-Tree (Join-Path $script:StageRoot 'ui') (Join-Path $root 'ui')
    if(Test-Path (Join-Path $script:StageRoot 'content_map.tsv')){Copy-Item (Join-Path $script:StageRoot 'content_map.tsv') (Join-Path $root 'content_map.tsv') -Force}
    [void](Sync-InstalledBadgeAssets $Usb $Lib)
}

# v1.0.14 performance overrides are loaded last so all callers use the incremental implementations.
. (Join-Path $PSScriptRoot 'ProjectErisPlusPlus.Performance.ps1')
