﻿$ErrorActionPreference='Stop'
Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing
[System.Windows.Forms.Application]::EnableVisualStyles()
. (Join-Path $PSScriptRoot 'ProjectErisPlusPlus.Core.ps1')

function Find-DuckStationExe {
    $candidates=New-Object System.Collections.ArrayList
    foreach($p in @(
        (Join-Path $env:LOCALAPPDATA 'Programs\DuckStation\duckstation-qt-x64-ReleaseLTCG.exe'),
        (Join-Path $env:LOCALAPPDATA 'Programs\DuckStation\duckstation-qt-x64-Release.exe'),
        (Join-Path $env:ProgramFiles 'DuckStation\duckstation-qt-x64-ReleaseLTCG.exe'),
        (Join-Path $env:ProgramFiles 'DuckStation\duckstation-qt-x64-Release.exe')
    )){if($p -and (Test-Path $p)){[void]$candidates.Add($p)}}
    foreach($base in @((Join-Path $env:LOCALAPPDATA 'Programs\DuckStation'),(Join-Path $env:ProgramFiles 'DuckStation'))){
        if(Test-Path $base){$x=Get-ChildItem $base -Filter 'duckstation-qt*.exe' -File -ErrorAction SilentlyContinue|Select-Object -First 1;if($x){[void]$candidates.Add($x.FullName)}}
    }
    try{
        $ws=New-Object -ComObject WScript.Shell
        foreach($d in @([Environment]::GetFolderPath('Desktop'),(Join-Path $env:APPDATA 'Microsoft\Windows\Start Menu'))){
            if(!(Test-Path $d)){continue}
            foreach($lnk in Get-ChildItem $d -Recurse -Filter '*DuckStation*.lnk' -File -ErrorAction SilentlyContinue|Select-Object -First 20){$target=$ws.CreateShortcut($lnk.FullName).TargetPath;if($target -and (Test-Path $target)){[void]$candidates.Add($target)}}
        }
    }catch{}
    return @($candidates|Select-Object -Unique|Select-Object -First 1)[0]
}

function Get-DuckCacheData([string]$DuckExe) {
    $c=@()
    if($DuckExe){$c+=Join-Path (Split-Path $DuckExe -Parent) 'RACache\Data'}
    $c+=Join-Path $env:LOCALAPPDATA 'DuckStation\RACache\Data'
    foreach($p in $c){if(Test-Path $p){return $p}}
    if($DuckExe){return (Join-Path (Split-Path $DuckExe -Parent) 'RACache\Data')}
    return $null
}

function Get-CacheFile([string]$Cache,[int]$Id) {
    if(!$Cache){return $null}
    foreach($p in @((Join-Path $Cache "$Id.json"),(Join-Path $Cache ([string]$Id)))){if(Test-Path $p){return $p}}
    return $null
}

function Test-RawCacheFile([string]$Path) {
    if(!$Path -or !(Test-Path $Path)){return $false}
    try{$t=Get-Content $Path -Raw -ErrorAction Stop;return ($t -match '"MemAddr"' -and $t -match '"Achievements"')}catch{return $false}
}

function Import-RawCacheFile([string]$Path,[int]$Id) {
    if(!(Test-RawCacheFile $Path)){return $false}
    Copy-Item $Path (Join-Path $script:RawCache "$Id.json") -Force
    return $true
}

function Select-DuckStationExe {
    $p=Find-DuckStationExe
    if($p){return $p}
    $o=New-Object System.Windows.Forms.OpenFileDialog
    $o.Title='Select DuckStation Qt'
    $o.Filter='DuckStation Qt|duckstation-qt*.exe|Executable|*.exe'
    if($o.ShowDialog() -eq 'OK'){return $o.FileName}
    return $null
}

function Ensure-RAIntegration([string]$DuckExe) {
    $dir=Split-Path $DuckExe -Parent;$dest=Join-Path $dir 'RA_Integration.dll'
    if(Test-Path $dest){return $true}
    $o=New-Object System.Windows.Forms.OpenFileDialog
    $o.Title='Select your existing RA_Integration.dll'
    $o.Filter='RA Integration|RA_Integration.dll|DLL|*.dll'
    if($o.ShowDialog() -ne 'OK'){return $false}
    try{Copy-Item $o.FileName $dest -Force;return (Test-Path $dest)}catch{[System.Windows.Forms.MessageBox]::Show("The DLL could not be placed next to DuckStation.`r`n`r`n$($_.Exception.Message)",'Project Eris ++')|Out-Null;return $false}
}

function Write-RepairLine([string]$Text) {
    Write-Host $Text
    if($script:Report -ne $null){$script:Report.Add($Text)|Out-Null}
}

try{
    $script:Report=New-Object System.Collections.ArrayList
    Write-RepairLine 'Project Eris ++ Achievement Recovery 1.0.17'
    Write-RepairLine ('Started='+((Get-Date).ToString('o')))
    $selfCache=Join-Path $PSScriptRoot 'bundled_cache\11278.json';$selfRoot=Join-Path $script:AppRoot 'SelfTest';[void](Test-ErisPPRichCompilerSelfTest $selfCache $selfRoot);Write-RepairLine 'Rich compiler self-test=124/124 PASS'
    $usb=Find-ErisUsb
    if(!$usb){throw 'Project Eris USB drive not found. Insert the USB drive and try again.'}
    Write-RepairLine ('USB='+$usb)
    $lib=Get-Library
    [void](Seed-ErisPPAchievementLibraryFromUsb $usb)
    [void](Refresh-ErisPPAchievementLibraryCatalog)
    $synced=Sync-InternalExport $usb $lib
    Write-RepairLine ("Internal slots synchronized=$synced")

    $legacy=Import-ExistingCompiledPacks $lib
    $built=Compile-AvailablePacks $lib
    Write-RepairLine ("Existing/bundled packs imported=$legacy")
    Write-RepairLine ("Packs compiled from local cache=$built")
    Deploy-StagedOnly $usb $lib

    $gt2=@($lib.games|Where-Object{(Normalize-Title ([string]$_.Title)) -eq 'granturismo2'}|Select-Object -First 1)
    if($gt2.Count -gt 0){Write-RepairLine ("Gran Turismo 2: RA ID=$($gt2[0].RaId), supported=$($gt2[0].Supported), total=$($gt2[0].Total), status=$($gt2[0].PackStatus)")}

    $missing=New-Object System.Collections.ArrayList
    foreach($g in $lib.games){
        if($g.Source -ne 'Internal' -or $g.OfficialSet -eq 'NO_SET'){continue}
        $cache=Find-CacheJson ([int]$g.RaId) ([string]$g.Title)
        if(!$cache){[void]$missing.Add($g)}
    }

    if($missing.Count -gt 0 -and $synced -gt 0){
        $answer=[System.Windows.Forms.MessageBox]::Show(
            "$($missing.Count) internal games still have no genuine RAIntegration cache.`r`n`r`nProject Eris ++ can start them in DuckStation one by one to harvest the genuine achievement logic. RA_Integration.dll must already be configured by you.`r`n`r`nContinue?",
            'Internal 20 achievement harvest',[System.Windows.Forms.MessageBoxButtons]::YesNo,[System.Windows.Forms.MessageBoxIcon]::Question)
        if($answer -eq [System.Windows.Forms.DialogResult]::Yes){
            $duck=Select-DuckStationExe
            if(!$duck){throw 'DuckStation was not selected.'}
            if(!(Ensure-RAIntegration $duck)){throw 'RA_Integration.dll is missing next to DuckStation.'}
            $cacheDir=Get-DuckCacheData $duck;New-Item -ItemType Directory -Force -Path $cacheDir|Out-Null
            Write-RepairLine ('DuckStation='+$duck);Write-RepairLine ('RA cache='+$cacheDir)
            $index=0
            foreach($g in $missing){
                $index++;$gid=[int]$g.RaId;$title=[string]$g.Title;$game=[string]$g.Path
                if(!(Test-Path $game)){Write-RepairLine ("$gid`tEXPORT_FILE_MISSING`t$title`t$game");continue}
                $existing=Get-CacheFile $cacheDir $gid
                if(Test-RawCacheFile $existing){Import-RawCacheFile $existing $gid|Out-Null;Write-RepairLine ("$gid`tCACHE_ALREADY_OK`t$title");continue}
                Write-Host "[$index/$($missing.Count)] Harvesting $title (RA $gid)..." -ForegroundColor Cyan
                $argLine='-batch -fastboot -nofullscreen -- "'+$game.Replace('"','')+'"'
                $proc=Start-Process -FilePath $duck -ArgumentList $argLine -PassThru
                $ok=$false;$deadline=(Get-Date).AddSeconds(120)
                while((Get-Date) -lt $deadline){
                    Start-Sleep -Milliseconds 750
                    $cf=Get-CacheFile $cacheDir $gid
                    if(Test-RawCacheFile $cf){$ok=$true;break}
                    try{$proc.Refresh()}catch{}
                    if($proc.HasExited -and (Get-Date) -gt $deadline.AddSeconds(-105)){break}
                }
                if($ok){Start-Sleep -Milliseconds 800;$cf=Get-CacheFile $cacheDir $gid;Import-RawCacheFile $cf $gid|Out-Null;Write-RepairLine ("$gid`tHARVEST_OK`t$title")}
                else{Write-RepairLine ("$gid`tHARVEST_TIMEOUT`t$title")}
                try{if(!$proc.HasExited){[void]$proc.CloseMainWindow();Start-Sleep -Milliseconds 800;$proc.Refresh();if(!$proc.HasExited){Stop-Process -Id $proc.Id -Force}}}catch{}
            }
            Import-ExistingCompiledPacks $lib|Out-Null
            $built2=Compile-AvailablePacks $lib
            Deploy-StagedOnly $usb $lib
            Write-RepairLine ("Post-harvest packs compiled=$built2")
        }
    }

    $lib=Get-Library;$ready=@($lib.games|Where-Object{$_.PackStatus -in @('Ready','Partial')}).Count;$need=@($lib.games|Where-Object{$_.OfficialSet -ne 'NO_SET' -and $_.PackStatus -notin @('Ready','Partial')}).Count;$noset=@($lib.games|Where-Object{$_.OfficialSet -eq 'NO_SET'}).Count
    Write-RepairLine ("ReadyOrPartial=$ready")
    Write-RepairLine ("PackNeeded=$need")
    Write-RepairLine ("NoSet=$noset")
    Write-RepairLine ('Finished='+((Get-Date).ToString('o')))
    $rp=Join-Path $usb 'PROJECT_ERIS_PP_ACHIEVEMENT_REPAIR.txt';$script:Report|Set-Content $rp -Encoding UTF8
    [System.Windows.Forms.MessageBox]::Show("Achievement repair completed.`r`n`r`nReady/Partial: $ready`r`nPack needed: $need`r`nNo set: $noset`r`n`r`nReport:`r`n$rp",'Project Eris ++')|Out-Null
}catch{
    $msg=$_.Exception.Message
    try{$logDir=Join-Path $script:AppRoot 'Logs';New-Item -ItemType Directory -Force -Path $logDir|Out-Null;$log=Join-Path $logDir ('achievement_repair_error_'+(Get-Date -Format 'yyyyMMdd_HHmmss')+'.txt');@('Project Eris ++ Achievement Recovery error','Time='+(Get-Date -Format o),'Message='+$msg,'',[string]$_.InvocationInfo.PositionMessage,'',[string]$_.ScriptStackTrace,'',[string]($_|Out-String))|Set-Content $log -Encoding UTF8}catch{$log='(log could not be written)'}
    [System.Windows.Forms.MessageBox]::Show("$msg`r`n`r`nLog: $log",'Project Eris ++ Achievement Repair')|Out-Null
    exit 1
}
