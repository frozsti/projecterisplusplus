﻿$ErrorActionPreference='Stop'
Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing
[System.Windows.Forms.Application]::EnableVisualStyles()
. (Join-Path $PSScriptRoot 'ProjectErisPlusPlus.Core.ps1')

$script:Usb=$null
$script:Lib=$null
$script:Installed=$false
$script:Busy=$false

$C_BG=[System.Drawing.Color]::FromArgb(8,15,30)
$C_HEADER=[System.Drawing.Color]::FromArgb(11,23,45)
$C_CARD=[System.Drawing.Color]::FromArgb(16,29,52)
$C_CARD2=[System.Drawing.Color]::FromArgb(20,36,62)
$C_TEXT=[System.Drawing.Color]::FromArgb(235,242,250)
$C_MUTED=[System.Drawing.Color]::FromArgb(156,177,202)
$C_ACCENT=[System.Drawing.Color]::FromArgb(108,224,255)
$C_GOOD=[System.Drawing.Color]::FromArgb(103,232,172)
$C_WARN=[System.Drawing.Color]::FromArgb(255,190,105)
$C_BAD=[System.Drawing.Color]::FromArgb(255,112,128)
$C_BORDER=[System.Drawing.Color]::FromArgb(42,64,92)

$form=New-Object System.Windows.Forms.Form
$form.Text='Project Eris ++ 1.0.21'
$form.StartPosition='CenterScreen'
$form.Size=New-Object System.Drawing.Size(900,690)
$form.MinimumSize=$form.Size
$form.MaximumSize=$form.Size
$form.BackColor=$C_BG
$form.ForeColor=$C_TEXT
$form.Font=New-Object System.Drawing.Font('Segoe UI',10)
$form.FormBorderStyle=[System.Windows.Forms.FormBorderStyle]::FixedSingle
$form.MaximizeBox=$false
$icon=Join-Path (Split-Path -Parent $PSScriptRoot) 'assets\projecterispp.ico'
if(Test-Path $icon){try{$form.Icon=New-Object System.Drawing.Icon -ArgumentList $icon}catch{}}

function New-Label([string]$Text,[int]$X,[int]$Y,[int]$W,[int]$H,[int]$Size=10,[bool]$Bold=$false,[System.Drawing.Color]$Color=$C_TEXT,[System.Windows.Forms.Control]$Parent=$form){
    $l=New-Object System.Windows.Forms.Label
    $l.Text=$Text
    $l.Location=New-Object System.Drawing.Point($X,$Y)
    $l.Size=New-Object System.Drawing.Size($W,$H)
    $l.ForeColor=$Color
    $l.BackColor=[System.Drawing.Color]::Transparent
    $style=if($Bold){[System.Drawing.FontStyle]::Bold}else{[System.Drawing.FontStyle]::Regular}
    $l.Font=New-Object System.Drawing.Font('Segoe UI',$Size,$style)
    $Parent.Controls.Add($l)
    return $l
}
function New-Button([string]$Text,[int]$X,[int]$Y,[int]$W,[int]$H,[System.Windows.Forms.Control]$Parent,[bool]$Primary=$false){
    $b=New-Object System.Windows.Forms.Button
    $b.Text=$Text
    $b.Location=New-Object System.Drawing.Point($X,$Y)
    $b.Size=New-Object System.Drawing.Size($W,$H)
    $b.FlatStyle=[System.Windows.Forms.FlatStyle]::Flat
    $b.FlatAppearance.BorderSize=1
    $b.Cursor=[System.Windows.Forms.Cursors]::Hand
    $b.Font=New-Object System.Drawing.Font('Segoe UI',10,[System.Drawing.FontStyle]::Bold)
    if($Primary){$b.BackColor=$C_ACCENT;$b.ForeColor=[System.Drawing.Color]::FromArgb(6,25,40);$b.FlatAppearance.BorderColor=$C_ACCENT}
    else{$b.BackColor=$C_CARD2;$b.ForeColor=$C_TEXT;$b.FlatAppearance.BorderColor=$C_BORDER}
    $Parent.Controls.Add($b)
    return $b
}
function New-Card([int]$X,[int]$Y,[int]$W,[int]$H,[System.Windows.Forms.Control]$Parent=$form){
    $p=New-Object System.Windows.Forms.Panel
    $p.Location=New-Object System.Drawing.Point($X,$Y)
    $p.Size=New-Object System.Drawing.Size($W,$H)
    $p.BackColor=$C_CARD
    $p.BorderStyle=[System.Windows.Forms.BorderStyle]::FixedSingle
    $Parent.Controls.Add($p)
    return $p
}
function Set-Status([string]$Text,[string]$State='good'){
    $script:StatusLabel.Text=$Text
    if($State -eq 'bad'){$script:StatusLabel.ForeColor=$C_BAD;$script:StatusDot.BackColor=$C_BAD}
    elseif($State -eq 'warn'){$script:StatusLabel.ForeColor=$C_WARN;$script:StatusDot.BackColor=$C_WARN}
    else{$script:StatusLabel.ForeColor=$C_GOOD;$script:StatusDot.BackColor=$C_GOOD}
    $form.Refresh()
    [System.Windows.Forms.Application]::DoEvents()
}
function Set-Busy([bool]$Value,[string]$Text='Working...'){
    $script:Busy=$Value
    $script:Progress.Visible=$Value
    foreach($b in @($script:ScanButton,$script:InstallButton,$script:OneGameButton,$script:FolderButton,$script:UsbLibraryButton,$script:GuideButton,$script:CloseButton)){if($null -ne $b){$b.Enabled=!$Value}}
    if($Value){Set-Status $Text 'warn'}
}
function Read-UsbProfile([string]$Usb){
    if(!$Usb){return (Get-ProfileName)}
    $p=Join-Path (Eris-Root $Usb) 'etc\erispp\profiles\active\profile.tsv'
    if(Test-Path $p){foreach($line in Get-Content $p){$f=$line -split "`t",2;if($f.Count -eq 2 -and $f[0] -eq 'display'){return $f[1]}}}
    return (Get-ProfileName)
}
function Refresh-UsbState {
    if($script:Busy){return}
    $script:Usb=Find-ErisUsb
    if(!$script:Usb){
        $script:UsbValue.Text='NOT FOUND'
        $script:UsbValue.ForeColor=$C_BAD
        $script:InstallButton.Enabled=$false
        $script:GamePanel.Visible=$false
        Set-Status 'Connect a USB drive with a working Project Eris installation, then click Scan Again.' 'bad'
        return
    }
    $script:UsbValue.Text='FOUND - '+$script:Usb
    $script:UsbValue.ForeColor=$C_GOOD
    $script:ProfileBox.Text=Read-UsbProfile $script:Usb
    $fail=@(Test-Preflight $script:Usb|Where-Object{!$_.OK})
    if($fail.Count -gt 0){
        $script:InstallButton.Enabled=$false
        $script:GamePanel.Visible=$false
        Set-Status ('USB check failed: '+$fail[0].Name+'. No changes were made.') 'bad'
        return
    }
    $script:Installed=Test-Path (Join-Path $script:Usb 'PROJECT_ERIS_PP_INSTALL.txt')
    $script:InstallButton.Enabled=$true
    if($script:Installed){
        $script:InstallButton.Text='REINSTALL / REPAIR PROJECT ERIS ++'
        $script:GamePanel.Visible=$true
        Set-Status 'Project Eris ++ is installed. Choose one of the three game options below.' 'good'
    }else{
        $script:InstallButton.Text='INSTALL PROJECT ERIS ++ TO USB'
        $script:GamePanel.Visible=$false
        Set-Status 'Clean Project Eris USB detected. Install Project Eris ++ first.' 'good'
    }
}
function Invoke-BaseInstall {
    if(!$script:Usb){return}
    if([string]::IsNullOrWhiteSpace($script:ProfileBox.Text)){$script:ProfileBox.Text='Player'}
    try{
        Set-Busy $true 'Installing Project Eris ++ and validating the USB...'
        $script:Lib=Get-Library
        [void](Deploy-ProjectErisPP $script:Usb $script:ProfileBox.Text $script:Lib)
        [void](Set-ErisPPPerformanceMode 'Fast')
        $script:Installed=$true
        $script:GamePanel.Visible=$true
        $script:InstallButton.Text='REINSTALL / REPAIR PROJECT ERIS ++'
        Set-Status 'Project Eris ++ installation completed. Now choose how you want to add games.' 'good'
        [System.Windows.Forms.MessageBox]::Show("Project Eris ++ was installed successfully.`r`n`r`nNext: choose one of the three game options in the main window.",'Project Eris ++')|Out-Null
    }catch{
        Set-Status $_.Exception.Message 'bad'
        [System.Windows.Forms.MessageBox]::Show($_.Exception.Message,'Project Eris ++ Setup')|Out-Null
    }finally{Set-Busy $false}
}
function Invoke-OneGame {
    $o=New-Object System.Windows.Forms.OpenFileDialog
    $o.Title='Select one PlayStation game image'
    $o.Filter='PlayStation images|*.m3u;*.cue;*.pbp;*.chd;*.iso|All files|*.*'
    $o.Multiselect=$false
    if($o.ShowDialog() -ne 'OK'){return}
    try{
        Set-Busy $true 'Preparing the game and its genuine achievement data...'
        $script:Lib=Get-Library
        $r=Add-GameFiles $script:Usb @($o.FileName) $script:Lib
        $msg="Completed.`r`n`r`nAdded: $($r.Added)`r`nAlready present: $($r.AlreadyPresent)`r`nAchievement-ready: $($r.Ready)`r`nNo achievement set: $($r.NoSet)`r`nBlocked: $($r.Blocked)`r`n`r`nReport: $($r.Report)"
        Set-Status ('Single game complete: '+$r.Added+' added, '+$r.Blocked+' blocked.') $(if($r.Blocked -gt 0){'warn'}else{'good'})
        [System.Windows.Forms.MessageBox]::Show($msg,'Install One Game')|Out-Null
    }catch{Set-Status $_.Exception.Message 'bad';[System.Windows.Forms.MessageBox]::Show($_.Exception.Message,'Install One Game')|Out-Null}
    finally{Set-Busy $false}
}
function Invoke-GameFolder {
    $o=New-Object System.Windows.Forms.FolderBrowserDialog
    $o.Description='Select the folder containing your PlayStation game library'
    if($o.ShowDialog() -ne 'OK'){return}
    try{
        Set-Busy $true 'Scanning the selected game folder...'
        $script:Lib=Get-Library
        $tick=[Diagnostics.Stopwatch]::StartNew()
        $scanCb={param($e);if($tick.ElapsedMilliseconds -lt 200){return};$tick.Restart();if($e.Detail){Set-Status $e.Detail 'warn'}}.GetNewClosure()
        $scan=Get-ErisPPLibraryScan $o.SelectedPath $scanCb
        if($scan.Games -eq 0){throw 'No supported PlayStation game images were found in the selected folder.'}
        $cb={param($e);if($e.Total -gt 0){$pct=[int](100.0*[double]$e.Current/[double]$e.Total);if($pct -lt 0){$pct=0};if($pct -gt 100){$pct=100};$script:Progress.Style=[System.Windows.Forms.ProgressBarStyle]::Continuous;$script:Progress.Value=$pct};$text=if($e.Title){$e.Status+': '+$e.Title}else{$e.Detail};if($text){Set-Status $text 'warn'}}
        $r=Import-ErisPPGameLibrary $script:Usb $o.SelectedPath $script:Lib $scan $cb
        $script:Progress.Style=[System.Windows.Forms.ProgressBarStyle]::Marquee
        $msg="Completed.`r`n`r`nScanned games: $($r.Scanned)`r`nAdded: $($r.Added)`r`nAlready present: $($r.AlreadyPresent)`r`nAchievement-ready: $($r.Ready)`r`nNo achievement set: $($r.NoSet)`r`nBlocked: $($r.Blocked)`r`nMulti-disc: $($r.MultiDisc)`r`n`r`nReport: $($r.Report)"
        Set-Status ('Game folder complete: '+$r.Added+' added, '+$r.Blocked+' blocked.') $(if($r.Blocked -gt 0){'warn'}else{'good'})
        [System.Windows.Forms.MessageBox]::Show($msg,'Install a Game Folder')|Out-Null
    }catch{Set-Status $_.Exception.Message 'bad';[System.Windows.Forms.MessageBox]::Show($_.Exception.Message,'Install a Game Folder')|Out-Null}
    finally{$script:Progress.Style=[System.Windows.Forms.ProgressBarStyle]::Marquee;Set-Busy $false}
}
function Invoke-UsbLibrary {
    try{
        Set-Busy $true 'Scanning the existing Project Eris games folder...'
        $script:Lib=Get-Library
        $tick=[Diagnostics.Stopwatch]::StartNew()
        $scanCb={param($e);if($tick.ElapsedMilliseconds -lt 200){return};$tick.Restart();if($e.Detail){Set-Status $e.Detail 'warn'}}.GetNewClosure()
        $scan=Get-ErisPPInstalledUsbGameScan $script:Usb $scanCb
        if($scan.Games -eq 0){throw 'No installed PlayStation games were found in the Project Eris games folder.'}
        $cb={param($e);if($e.Title){Set-Status ($e.Status+': '+$e.Title) 'warn'}elseif($e.Detail){Set-Status $e.Detail 'warn'}}
        $r=Import-ErisPPInstalledUsbGames $script:Usb $script:Lib $scan $cb
        $msg="Completed.`r`n`r`nInstalled games scanned: $($scan.Games)`r`nNewly linked: $($r.Linked)`r`nUpdated: $($r.Updated)`r`nAchievement-ready: $($r.Ready)`r`nNo achievement set: $($r.NoSet)`r`nBlocked: $($r.Blocked)`r`n`r`nExisting game images were not copied, moved or renamed.`r`n`r`nReport: $($r.Report)"
        Set-Status ('Existing USB library complete: '+$r.Ready+' ready, '+$r.Blocked+' blocked.') $(if($r.Blocked -gt 0){'warn'}else{'good'})
        [System.Windows.Forms.MessageBox]::Show($msg,'Use Current USB Library')|Out-Null
    }catch{Set-Status $_.Exception.Message 'bad';[System.Windows.Forms.MessageBox]::Show($_.Exception.Message,'Use Current USB Library')|Out-Null}
    finally{Set-Busy $false}
}

$hero=New-Object System.Windows.Forms.Panel
$hero.Location=New-Object System.Drawing.Point(0,0)
$hero.Size=New-Object System.Drawing.Size(900,100)
$hero.BackColor=$C_HEADER
$form.Controls.Add($hero)
[void](New-Label 'PROJECT ERIS ++' 28 17 470 42 25 $true $C_ACCENT $hero)
[void](New-Label 'Simple USB installer for PlayStation Classic' 31 60 520 24 10 $false $C_MUTED $hero)
$ver=New-Label 'VERSION 1.0.21' 730 26 130 28 9 $true $C_ACCENT $hero
$ver.TextAlign=[System.Drawing.ContentAlignment]::MiddleCenter
$ver.BackColor=$C_CARD2
$ver.BorderStyle=[System.Windows.Forms.BorderStyle]::FixedSingle

$setup=New-Card 24 120 852 220
[void](New-Label '1. INSTALL PROJECT ERIS ++' 22 17 500 28 13 $true $C_TEXT $setup)
[void](New-Label 'Start with a USB drive that already has a working Project Eris installation. This installer keeps the existing Project Eris structure and creates a backup before changes.' 22 49 800 43 9 $false $C_MUTED $setup)
[void](New-Label 'USB drive' 22 104 120 24 9 $true $C_MUTED $setup)
$script:UsbValue=New-Label 'Scanning...' 145 102 520 28 10 $true $C_WARN $setup
$script:ScanButton=New-Button 'SCAN AGAIN' 682 96 145 36 $setup $false
[void](New-Label 'Profile name' 22 145 120 24 9 $true $C_MUTED $setup)
$script:ProfileBox=New-Object System.Windows.Forms.TextBox
$script:ProfileBox.Location=New-Object System.Drawing.Point(145,143)
$script:ProfileBox.Size=New-Object System.Drawing.Size(280,30)
$script:ProfileBox.Font=New-Object System.Drawing.Font('Segoe UI',10)
$script:ProfileBox.Text=Get-ProfileName
$setup.Controls.Add($script:ProfileBox)
$script:InstallButton=New-Button 'INSTALL PROJECT ERIS ++ TO USB' 447 140 380 40 $setup $true

$script:GamePanel=New-Card 24 360 852 210
[void](New-Label '2. CHOOSE HOW TO ADD GAMES' 22 17 500 28 13 $true $C_TEXT $script:GamePanel)
[void](New-Label 'Pick one option. You can return to this screen later and use another option.' 22 47 790 28 9 $false $C_MUTED $script:GamePanel)
$script:OneGameButton=New-Button 'INSTALL ONE GAME' 22 85 250 54 $script:GamePanel $true
$script:FolderButton=New-Button 'INSTALL A GAME FOLDER' 300 85 250 54 $script:GamePanel $false
$script:UsbLibraryButton=New-Button 'USE CURRENT USB LIBRARY' 578 85 250 54 $script:GamePanel $false
[void](New-Label 'Select one M3U, CUE, PBP, CHD or ISO.' 22 145 250 42 8 $false $C_MUTED $script:GamePanel)
[void](New-Label 'Scan a folder recursively, including multi-disc sets.' 300 145 250 42 8 $false $C_MUTED $script:GamePanel)
[void](New-Label 'Use games already present in the USB games folder. No game images are copied.' 578 145 250 42 8 $false $C_MUTED $script:GamePanel)
$script:GamePanel.Visible=$false

$statusPanel=New-Object System.Windows.Forms.Panel
$statusPanel.Location=New-Object System.Drawing.Point(24,590)
$statusPanel.Size=New-Object System.Drawing.Size(852,46)
$statusPanel.BackColor=$C_HEADER
$statusPanel.BorderStyle=[System.Windows.Forms.BorderStyle]::FixedSingle
$form.Controls.Add($statusPanel)
$script:StatusDot=New-Object System.Windows.Forms.Panel
$script:StatusDot.Location=New-Object System.Drawing.Point(14,17)
$script:StatusDot.Size=New-Object System.Drawing.Size(10,10)
$script:StatusDot.BackColor=$C_WARN
$statusPanel.Controls.Add($script:StatusDot)
$script:StatusLabel=New-Label 'Scanning your USB drive...' 36 10 790 26 9 $true $C_WARN $statusPanel
$script:Progress=New-Object System.Windows.Forms.ProgressBar
$script:Progress.Location=New-Object System.Drawing.Point(24,643)
$script:Progress.Size=New-Object System.Drawing.Size(510,8)
$script:Progress.Style=[System.Windows.Forms.ProgressBarStyle]::Marquee
$script:Progress.MarqueeAnimationSpeed=22
$script:Progress.Visible=$false
$form.Controls.Add($script:Progress)
$script:GuideButton=New-Button 'SETUP GUIDE' 551 640 145 30 $form $false
$script:CloseButton=New-Button 'CLOSE' 713 640 163 30 $form $false
$copyright=New-Label 'Copyright Frozsti 2026' 24 655 400 22 8 $false $C_MUTED $form

$script:ScanButton.Add_Click({Refresh-UsbState})
$script:InstallButton.Add_Click({Invoke-BaseInstall})
$script:OneGameButton.Add_Click({Invoke-OneGame})
$script:FolderButton.Add_Click({Invoke-GameFolder})
$script:UsbLibraryButton.Add_Click({Invoke-UsbLibrary})
$script:GuideButton.Add_Click({$g=Join-Path (Split-Path -Parent $PSScriptRoot) 'README_SETUP_EN.txt';if(Test-Path $g){Start-Process notepad.exe $g}})
$script:CloseButton.Add_Click({$form.Close()})

Refresh-UsbState
[void]$form.ShowDialog()
