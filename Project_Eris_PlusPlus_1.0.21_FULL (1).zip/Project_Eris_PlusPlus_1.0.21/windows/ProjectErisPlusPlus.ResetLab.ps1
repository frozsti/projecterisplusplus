﻿$ErrorActionPreference='Stop'
Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing
[System.Windows.Forms.Application]::EnableVisualStyles()
. (Join-Path $PSScriptRoot 'ProjectErisPlusPlus.Core.ps1')
$form=New-Object System.Windows.Forms.Form;$form.Text='Project Eris ++ Reset Lab';$form.Size=New-Object System.Drawing.Size(720,510);$form.StartPosition='CenterScreen';$form.BackColor=[System.Drawing.Color]::FromArgb(22,14,28);$form.ForeColor=[System.Drawing.Color]::White;$form.Font=New-Object System.Drawing.Font('Segoe UI',10)
$h=New-Object System.Windows.Forms.Label;$h.Text='PROJECT ERIS ++ RESET LAB';$h.Font=New-Object System.Drawing.Font('Segoe UI',20,[System.Drawing.FontStyle]::Bold);$h.ForeColor=[System.Drawing.Color]::FromArgb(255,160,190);$h.Location=New-Object System.Drawing.Point(22,18);$h.Size=New-Object System.Drawing.Size(650,45);$form.Controls.Add($h)
$warn=New-Object System.Windows.Forms.Label;$warn.Text='All actions below are destructive test tools. Every action requires separate confirmation.';$warn.Location=New-Object System.Drawing.Point(25,78);$warn.Size=New-Object System.Drawing.Size(650,55);$form.Controls.Add($warn)
$status=New-Object System.Windows.Forms.Label;$status.Location=New-Object System.Drawing.Point(25,138);$status.Size=New-Object System.Drawing.Size(650,30);$form.Controls.Add($status)
function USB{Find-ErisUsb}
function Btn([string]$t,[int]$y){$b=New-Object System.Windows.Forms.Button;$b.Text=$t;$b.Location=New-Object System.Drawing.Point(25,$y);$b.Size=New-Object System.Drawing.Size(630,50);$form.Controls.Add($b);return $b}
function Confirm([string]$Text){return ([System.Windows.Forms.MessageBox]::Show($Text,'Project Eris ++ Reset Lab',[System.Windows.Forms.MessageBoxButtons]::YesNo,[System.Windows.Forms.MessageBoxIcon]::Warning) -eq 'Yes')}
function SetS([string]$t){$status.Text=$t;$form.Refresh()}
$bAch=Btn 'Delete all earned achievements for this profile' 180
$bProfile=Btn 'Delete profile (achievements + history + played list)' 245
$bSaves=Btn 'Delete ALL save files and save states' 310
$bAll=Btn 'Full test reset: profile + achievements + all saves' 375
$bAch.Add_Click({$u=USB;if(!$u){return [System.Windows.Forms.MessageBox]::Show('No Project Eris USB drive found.')};if(!(Confirm 'Delete all achievement unlocks and history?')){return};$r=Join-Path (Eris-Root $u) 'etc\erispp';Remove-Item (Join-Path $r 'state\*.unlocked') -Force -ErrorAction SilentlyContinue;Remove-Item (Join-Path $r 'profiles\active\history.tsv') -Force -ErrorAction SilentlyContinue;SetS 'Achievements and history have been deleted.'})
$bProfile.Add_Click({$u=USB;if(!$u){return [System.Windows.Forms.MessageBox]::Show('No Project Eris USB drive found.')};if(!(Confirm 'Delete the active Project Eris ++ profile completely?')){return};$p=Join-Path (Eris-Root $u) 'etc\erispp\profiles\active';Remove-Item $p -Recurse -Force -ErrorAction SilentlyContinue;New-Item -ItemType Directory -Force -Path $p|Out-Null;SetS 'Profile deleted. The main wizard can create a new profile.'})
function Queue-SaveReset([string]$u){$eris=Eris-Root $u;$root=Join-Path $eris 'etc\erispp';Remove-Item (Join-Path (Ra-Root $u) 'saves\*') -Force -Recurse -ErrorAction SilentlyContinue;Remove-Item (Join-Path (Ra-Root $u) 'savestates\*') -Force -Recurse -ErrorAction SilentlyContinue;$d=Join-Path $root 'reset';New-Item -ItemType Directory -Force -Path $d|Out-Null;'RESET_ALL_INTERNAL_SAVES'|Set-Content (Join-Path $d 'RESET_INTERNAL_SAVES.flag') -Encoding ASCII}
$bSaves.Add_Click({$u=USB;if(!$u){return [System.Windows.Forms.MessageBox]::Show('No Project Eris USB drive found.')};if(!(Confirm 'Delete ALL RetroArch saves/states now and delete internal PlayStation Classic saves on the next game launch?')){return};Queue-SaveReset $u;SetS 'USB saves deleted. Internal saves will be removed before the next game launch.'})
$bAll.Add_Click({$u=USB;if(!$u){return [System.Windows.Forms.MessageBox]::Show('No Project Eris USB drive found.')};if(!(Confirm 'Run a FULL TEST RESET? This deletes the profile, unlocks, history and all save games.')){return};$root=Join-Path (Eris-Root $u) 'etc\erispp';Remove-Item (Join-Path $root 'state\*.unlocked') -Force -ErrorAction SilentlyContinue;Remove-Item (Join-Path $root 'profiles\active') -Recurse -Force -ErrorAction SilentlyContinue;New-Item -ItemType Directory -Force -Path (Join-Path $root 'profiles\active')|Out-Null;Queue-SaveReset $u;SetS 'Full test reset prepared. Internal saves will be deleted on the next launch.'})
$u=USB;$status.Text=if($u){'USB found: '+$u}else{'No Project Eris USB drive found.'}
[void]$form.ShowDialog()
