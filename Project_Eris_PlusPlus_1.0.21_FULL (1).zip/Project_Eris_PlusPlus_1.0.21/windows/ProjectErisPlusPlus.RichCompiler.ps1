﻿$ErrorActionPreference = 'Stop'

function Convert-ErisPPSafeText([object]$Value) {
    if ($null -eq $Value) { return '' }
    $s = [string]$Value
    $s = $s -replace "`t|`r|`n", ' '
    $s = $s -replace '[^ -~]', '?'
    return (($s -replace '\s+', ' ').Trim())
}

function Convert-ErisPPUnsigned([long]$Value) {
    if ($Value -lt 0) { return [uint32](4294967296L + $Value) }
    return [uint32]$Value
}

function New-ErisPPOperand([string]$Kind,[string]$Mod,[string]$Size,[uint32]$Value,[bool]$Supported) {
    return [pscustomobject]@{ Kind=$Kind; Mod=$Mod; Size=$Size; Value=$Value; Supported=$Supported }
}

function Convert-ErisPPOperand([string]$Text) {
    if ($null -eq $Text) { return (New-ErisPPOperand 'none' 'n' 'n' 0 $true) }
    $original = [string]$Text
    $s = $original.Trim()
    if ($s.ToLowerInvariant() -eq '{recall}') { return (New-ErisPPOperand 'r' 'n' 'n' 0 $true) }
    if ($s -match '^@[A-Za-z][A-Za-z0-9_]*$') { return (New-ErisPPOperand 'raw' 'n' 'n' 0 $false) }

    $mod = 'n'
    if ($s.Length -gt 0) {
        $first = [string]$s[0]
        if ($first -eq 'd' -or $first -eq 'p' -or $first -eq 'b') {
            if ($first -eq 'b') { $mod='c' } else { $mod=$first }
            $s=$s.Substring(1).Trim()
        } elseif ($first -eq '~') {
            $mod='v';$s=$s.Substring(1).Trim()
        }
    }

    if ($s -match '^[hH]([0-9A-Fa-f]+)$') {
        $v=[Convert]::ToUInt32($Matches[1],16)
        return (New-ErisPPOperand 'c' 'n' 'n' $v $true)
    }
    if ($s -match '^[vV]([+-]?\d+)$') {
        $v=Convert-ErisPPUnsigned ([long]$Matches[1])
        return (New-ErisPPOperand 'c' 'n' 'n' $v $true)
    }
    if ($s -match '^([+-]\d+)$') {
        $v=Convert-ErisPPUnsigned ([long]$Matches[1])
        return (New-ErisPPOperand 'c' 'n' 'n' $v $true)
    }
    if ($s -match '^[fF]([+-]?(?:\d+\.\d*|\d*\.\d+|\d+))$') {
        $fv=[single]::Parse($Matches[1],[Globalization.CultureInfo]::InvariantCulture)
        $v=[BitConverter]::ToUInt32([BitConverter]::GetBytes($fv),0)
        return (New-ErisPPOperand 'f' 'n' 'n' $v $true)
    }
    if ($s -match '^[fF]([FBHIML])([0-9A-Fa-f]+)$') {
        $sc=$Matches[1]
        $size=if($sc -eq 'F'){'F'}elseif($sc -eq 'B'){'B'}else{'?'}
        $ok=($size -ne '?')
        $v=[Convert]::ToUInt32($Matches[2],16)
        return (New-ErisPPOperand 'm' $mod $size $v $ok)
    }
    if ($s.StartsWith('0x',[StringComparison]::OrdinalIgnoreCase)) {
        $body=$s.Substring(2)
        if ($body.Length -gt 0) {
            $sc=[string]$body[0]
            $map=@{
                'M'='0';'N'='1';'O'='2';'P'='3';'Q'='4';'R'='5';'S'='6';'T'='7';
                'L'='l';'U'='u';'H'='8';' '='w';'W'='t';'X'='x';'I'='I';'J'='J';'G'='G';'K'='K'
            }
            if ($map.ContainsKey($sc)) {
                $rest=$body.Substring(1)
                if ($sc -eq ' ') { $rest=$rest.Trim() }
                if ($rest -match '^[0-9A-Fa-f]+$') {
                    $v=[Convert]::ToUInt32($rest,16)
                    return (New-ErisPPOperand 'm' $mod ([string]$map[$sc]) $v $true)
                }
            }
            $compact=$body.Trim()
            if ($compact -match '^[0-9A-Fa-f]+$') {
                $v=[Convert]::ToUInt32($compact,16)
                return (New-ErisPPOperand 'm' $mod 'w' $v $true)
            }
        }
    }
    if ($s -match '^\d+$') {
        $v=[uint32]::Parse($s,[Globalization.CultureInfo]::InvariantCulture)
        return (New-ErisPPOperand 'c' 'n' 'n' $v $true)
    }
    return (New-ErisPPOperand 'raw' 'n' 'n' 0 $false)
}

function Split-ErisPPOperator([string]$Token) {
    foreach($op in @('!=','>=','<=','=','<','>')) {
        $i=$Token.IndexOf($op,[StringComparison]::Ordinal)
        if($i -gt 0){return [pscustomobject]@{Left=$Token.Substring(0,$i);Op=$op;Right=$Token.Substring($i+$op.Length);Kind='compare'}}
    }
    foreach($op in @('*','/','%','+','-','&','^')) {
        $i=$Token.IndexOf($op,1,[StringComparison]::Ordinal)
        if($i -gt 0){return [pscustomobject]@{Left=$Token.Substring(0,$i);Op=$op;Right=$Token.Substring($i+$op.Length);Kind='modify'}}
    }
    return [pscustomobject]@{Left=$Token;Op='.';Right=$null;Kind='none'}
}

function Convert-ErisPPCondition([string]$Raw) {
    $token=$Raw.Trim();$flag='S'
    if($token.Length -ge 2 -and $token[1] -eq ':') {
        $p=[string]$token[0]
        if(@('P','R','Z','A','B','C','D','I','N','O','M','G','Q','T','K') -contains $p){$flag=$p;$token=$token.Substring(2)}
    }
    $hit=0
    if($token -match '\.(\d+)\.$'){$hit=[int]$Matches[1];$token=$token.Substring(0,$token.Length-$Matches[0].Length)}
    $sp=Split-ErisPPOperator $token
    $left=Convert-ErisPPOperand $sp.Left
    $right=if($null -eq $sp.Right){New-ErisPPOperand 'none' 'n' 'n' 0 $true}else{Convert-ErisPPOperand $sp.Right}
    $ok=($left.Supported -and $right.Supported)
    return [pscustomobject]@{Flag=$flag;Left=$left;Op=$sp.Op;Right=$right;Hit=$hit;Supported=$ok}
}

function Split-ErisPPTriggerGroups([string]$Logic) {
    $result=New-Object System.Collections.ArrayList
    $sb=New-Object Text.StringBuilder
    for($i=0;$i -lt $Logic.Length;$i++) {
        $ch=$Logic[$i];$isAlt=$false
        if($ch -eq 'S') {
            if(!($i -ge 2 -and $Logic.Substring($i-2,2).ToLowerInvariant() -eq '0x')){$isAlt=$true}
        }
        if($isAlt){[void]$result.Add($sb.ToString());[void]$sb.Clear()}else{[void]$sb.Append($ch)}
    }
    [void]$result.Add($sb.ToString())
    return @($result)
}

function Convert-ErisPPTrigger([string]$Logic) {
    if([string]::IsNullOrWhiteSpace($Logic)){return $null}
    $groups=New-Object System.Collections.ArrayList
    $gi=0
    foreach($rawGroup in (Split-ErisPPTriggerGroups $Logic)) {
        $conds=New-Object System.Collections.ArrayList
        $addAddressPending=$false;$supported=$true
        foreach($rawCond in ($rawGroup -split '_')) {
            if([string]::IsNullOrWhiteSpace($rawCond)){continue}
            $c=Convert-ErisPPCondition $rawCond
            if(!$c.Supported){$supported=$false}
            foreach($opd in @($c.Left,$c.Right)) {
                if($addAddressPending -and $opd.Kind -eq 'm' -and @('d','p') -contains $opd.Mod){$supported=$false}
            }
            if($c.Flag -eq 'I'){$addAddressPending=$true}elseif(@('A','B','K') -notcontains $c.Flag){$addAddressPending=$false}
            [void]$conds.Add($c)
        }
        [void]$groups.Add([pscustomobject]@{Type=$(if($gi -eq 0){'C'}else{'A'});Conditions=@($conds)})
        $gi++
        if(!$supported){return $null}
    }
    if($groups.Count -eq 0){return $null}
    return @($groups)
}

function Get-ErisPPCoreAchievements($Cache) {
    $out=New-Object System.Collections.ArrayList
    $seen=@{}
    $setsProp=$null;if($null -ne $Cache){$setsProp=$Cache.PSObject.Properties['Sets']}
    if($null -ne $setsProp -and $null -ne $setsProp.Value) {
        foreach($set in @($setsProp.Value)) {
            if($null -eq $set){continue}
            $typeProp=$set.PSObject.Properties['Type'];$type=if($null -ne $typeProp){[string]$typeProp.Value}else{''}
            if($type -and $type.ToLowerInvariant() -ne 'core'){continue}
            $achProp=$set.PSObject.Properties['Achievements'];if($null -eq $achProp -or $null -eq $achProp.Value){continue}
            foreach($a in @($achProp.Value)) {
                if($null -eq $a){continue}
                $id='';$idp=$a.PSObject.Properties['ID'];if($null -ne $idp){$id=[string]$idp.Value};if(!$id){$idp=$a.PSObject.Properties['id'];if($null -ne $idp){$id=[string]$idp.Value}}
                if(!$id -or $seen.ContainsKey($id)){continue};$seen[$id]=$true;[void]$out.Add($a)
            }
        }
    }
    if($out.Count -eq 0) {
        $topProp=$null;if($null -ne $Cache){$topProp=$Cache.PSObject.Properties['Achievements']}
        if($null -ne $topProp -and $null -ne $topProp.Value){
            foreach($a in @($topProp.Value)) {
                if($null -eq $a){continue}
                $id='';$idp=$a.PSObject.Properties['ID'];if($null -ne $idp){$id=[string]$idp.Value};if(!$id){$idp=$a.PSObject.Properties['id'];if($null -ne $idp){$id=[string]$idp.Value}}
                if(!$id -or $seen.ContainsKey($id)){continue};$seen[$id]=$true;[void]$out.Add($a)
            }
        }
    }
    return @($out)
}

function Get-ErisPPOperandFields($Operand) {
    if($null -eq $Operand -or $Operand.Kind -eq 'none'){return @('n','n','n','0')}
    return @([string]$Operand.Kind,[string]$Operand.Mod,[string]$Operand.Size,[string]([uint32]$Operand.Value))
}

function Build-ErisPPRichPack($Game,[string]$CacheFile,[string]$StageRoot) {
    if(!(Test-Path $CacheFile)){return $false}
    $cache=Get-Content $CacheFile -Raw -Encoding UTF8|ConvertFrom-Json
    $gid=0
    foreach($name in @('GameId','GameID','ID')){if($cache.PSObject.Properties.Name -contains $name){$gid=[int]$cache.$name;if($gid -gt 0){break}}}
    if($gid -le 0){return $false}
    $Game.RaId=$gid
    $cacheTitle=$cache.PSObject.Properties['Title'];if($null -ne $cacheTitle -and $cacheTitle.Value){$Game.Title=Convert-ErisPPSafeText $cacheTitle.Value}
    $achs=@(Get-ErisPPCoreAchievements $cache)
    $Game.Total=$achs.Count
    if($achs.Count -eq 0){$Game.OfficialSet='NO_SET';$Game.PackStatus='No Set';$Game.Supported=0;return $false}
    $Game.OfficialSet='SET'
    $db=Join-Path $StageRoot 'database';$uig=Join-Path $StageRoot 'ui\games'
    New-Item -ItemType Directory -Force -Path $db,$uig|Out-Null
    $compiled=New-Object System.Collections.ArrayList
    foreach($a in $achs) {
        $raw='';$mp=$a.PSObject.Properties['MemAddr'];if($null -ne $mp){$raw=[string]$mp.Value};if(!$raw){$mp=$a.PSObject.Properties['memAddr'];if($null -ne $mp){$raw=[string]$mp.Value}}
        $groups=Convert-ErisPPTrigger $raw
        if($null -eq $groups){continue}
        $id=0;$ip=$a.PSObject.Properties['ID'];if($null -eq $ip){$ip=$a.PSObject.Properties['id']};try{if($null -ne $ip){$id=[int]$ip.Value}}catch{};if($id -le 0){continue}
        $points=0;$pp=$a.PSObject.Properties['Points'];try{if($null -ne $pp){$points=[int]$pp.Value}}catch{};$tp=$a.PSObject.Properties['Title'];$dp=$a.PSObject.Properties['Description'];$at=if($null -ne $tp){[string]$tp.Value}else{('Achievement '+$id)};$ad=if($null -ne $dp){[string]$dp.Value}else{''}
        [void]$compiled.Add([pscustomobject]@{Id=$id;Points=$points;Title=(Convert-ErisPPSafeText $at);Description=(Convert-ErisPPSafeText $ad);Groups=@($groups)})
    }
    $n=$compiled.Count
    if($n -eq 0){$Game.Supported=0;$Game.PackStatus='Unsupported';return $false}
    $fd=New-Object System.Collections.ArrayList
    [void]$fd.Add("ERPP2`t$gid`t$n`t$(Convert-ErisPPSafeText $Game.Title)")
    $ui=New-Object System.Collections.ArrayList
    foreach($a in $compiled) {
        [void]$fd.Add("A`t$($a.Id)`t$($a.Points)`t$($a.Groups.Count)`t$($a.Title)`t$($a.Description)")
        [void]$ui.Add("$($a.Id)`t$($a.Points)`t$($a.Title)`t$($a.Description)`t`t")
        foreach($g in $a.Groups) {
            [void]$fd.Add("G`t$($g.Type)`t$($g.Conditions.Count)")
            foreach($c in $g.Conditions) {
                $lf=Get-ErisPPOperandFields $c.Left;$rf=Get-ErisPPOperandFields $c.Right
                [void]$fd.Add((@('C',$c.Flag,$lf[0],$lf[1],$lf[2],$lf[3],$c.Op,$rf[0],$rf[1],$rf[2],$rf[3],[string]$c.Hit) -join "`t"))
            }
        }
    }
    $fd|Set-Content (Join-Path $db "$gid.fdb") -Encoding ASCII
    $ui|Set-Content (Join-Path $uig "$gid.tsv") -Encoding ASCII
    $Game.Supported=$n
    if($n -lt $achs.Count){$Game.PackStatus='Partial'}else{$Game.PackStatus='Ready'}
    return $true
}

function Test-ErisPPRichCompilerSelfTest([string]$CacheFile,[string]$TempRoot) {
    if(!(Test-Path $CacheFile)){throw 'Bundled GT2 self-test cache is missing.'}
    if(Test-Path $TempRoot){Remove-Item $TempRoot -Recurse -Force}
    New-Item -ItemType Directory -Force -Path $TempRoot|Out-Null
    try{
        $g=[pscustomobject]@{RaId=11278;Title='Gran Turismo 2';OfficialSet='SET';PackStatus='Pack needed';Supported=0;Total=0}
        $ok=Build-ErisPPRichPack $g $CacheFile $TempRoot
        if(!$ok){throw 'Rich compiler could not compile the GT2 reference cache.'}
        if([int]$g.Total -ne 124 -or [int]$g.Supported -ne 124){throw "Rich compiler self-test expected 124/124 but got $($g.Supported)/$($g.Total)."}
        $f=Join-Path $TempRoot 'database\11278.fdb';$u=Join-Path $TempRoot 'ui\games\11278.tsv'
        if(!(Test-Path $f) -or !(Test-Path $u)){throw 'Rich compiler self-test output is missing.'}
        $lines=@(Get-Content $f);if($lines.Count -lt 2 -or !$lines[0].StartsWith("ERPP2`t11278`t124`t")){throw 'Rich compiler self-test FDB header is invalid.'}
        $ac=@($lines|Where-Object{$_.StartsWith("A`t")}).Count;if($ac -ne 124){throw "Rich compiler self-test FDB contains $ac achievements instead of 124."}
        return $true
    } finally {
        Remove-Item $TempRoot -Recurse -Force -ErrorAction SilentlyContinue
    }
}
