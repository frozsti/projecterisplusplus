@echo off
setlocal
cd /d "%~dp0"
powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0windows\Validate-PowerShell.ps1" "%~dp0windows\Collect-RuntimeCheck.ps1"
if errorlevel 1 (
  echo.
  echo Runtime check stopped: PowerShell parser validation failed.
  pause
  exit /b 10
)
powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0windows\Collect-RuntimeCheck.ps1"
pause
