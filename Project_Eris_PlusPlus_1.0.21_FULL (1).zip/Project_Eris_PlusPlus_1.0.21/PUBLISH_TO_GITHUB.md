# Publishing Project Eris ++ to GitHub

This package is prepared to be used as a GitHub repository. Decide first whether the repository
should be **Private** or **Public**. Before publishing publicly, read `LICENSING_TODO.md` and verify
the origin and license of every derived file before choosing a project-wide license.

## 1. Create an empty repository on GitHub

For example, create `Project-Eris-PlusPlus`. Leave the README, .gitignore and LICENSE options empty
when creating the repository because this source package already contains the relevant files.

## 2. Extract the GitHub-ready ZIP

Open PowerShell, Windows Terminal or Git Bash inside the extracted folder.

## 3. Initialize Git

```bash
git init
git branch -M main
git add .
git commit -m "Project Eris ++ v1.0.21"
```

## 4. Connect the GitHub repository

Replace `OWNER` and `REPOSITORY`:

```bash
git remote add origin https://github.com/OWNER/REPOSITORY.git
git push -u origin main
```

Use GitHub Credential Manager, GitHub CLI or SSH for authentication. Do not use your GitHub account
password as a Git password.

## 5. Tag the release

```bash
git tag -a v1.0.21 -m "Project Eris ++ v1.0.21"
git push origin v1.0.21
```

## 6. Create a GitHub Release

On GitHub: Repository -> Releases -> Draft a new release -> select tag `v1.0.21`.

Recommended release assets:

- `Project_Eris_PlusPlus_Setup_v1.0.21.exe`
- `Project_Eris_PlusPlus_v1.0.21.zip`
- `Project_Eris_PlusPlus_v1.0.21_SHA256.txt`
- relevant validation reports

The source code belongs in the repository. Large generated release binaries do not need to be kept
in Git history.

Using GitHub CLI, a release can be created with:

```bash
gh release create v1.0.21 \
  Project_Eris_PlusPlus_Setup_v1.0.21.exe \
  Project_Eris_PlusPlus_v1.0.21.zip \
  Project_Eris_PlusPlus_v1.0.21_SHA256.txt \
  --title "Project Eris ++ v1.0.21" \
  --notes-file RELEASE_NOTES_1.0.21.txt
```

## 7. Automatic Windows installer build

`.github/workflows/build-windows-installer.yml` builds the native Windows x64 installer from
`installer/ProjectErisPlusPlusSetup.go` using `installer/Build-Installer.ps1`.

## Important before making the repository public

Do not commit ROMs/disc images, PlayStation BIOS files, RetroAchievements credentials,
`RA_Integration.dll`, DuckStation binaries, or any other files you do not have permission to
redistribute.
