# Project Eris ++ 1.0.21 - Simple Installer Guide

**Project Eris ++** is an unofficial Project Eris add-on for the PlayStation Classic. Version 1.0.21 keeps the working achievement/runtime base from 1.0.20 and adds a much simpler Windows installation flow.

## Before you start

You need:

- A USB drive with a **working Project Eris installation already on it**.
- Windows 10 or Windows 11, 64-bit.
- Your own legally obtained PlayStation game images.
- Enough free space on the USB for the Project Eris ++ preflight.

Project Eris ++ does **not** include ROMs, disc images, PlayStation BIOS files, DuckStation, RA_Integration.dll or RetroAchievements credentials.

## Installation

1. Run `Project_Eris_PlusPlus_Setup_v1.0.21.exe`.
2. Open **Project Eris ++** from the Desktop shortcut.
3. Insert your Project Eris USB drive.
4. The app automatically checks the USB. If a required Project Eris file is missing, it stops before making changes.
5. Enter your profile name.
6. Click **INSTALL PROJECT ERIS ++ TO USB**.
7. Project Eris ++ creates its normal backup and installs the complete package.
8. When that finishes, choose one of three game options.

## The three game options

### 1. Install One Game

Choose one `M3U`, `CUE`, `PBP`, `CHD` or `ISO` file. Project Eris ++ prepares genuine achievement data first and then copies accepted game files to the normal Project Eris transfer workflow. CUE dependencies are included automatically.

### 2. Install a Game Folder

Choose a folder containing one or more PlayStation games. The installer scans recursively, prefers M3U playlists, preserves CUE dependencies and can group supported multi-disc naming into one launch entry.

### 3. Use Current USB Library

Choose this if your games are already installed on the Project Eris USB in its games library. Project Eris ++ scans the existing library and links achievement data **in place**. Existing game images are not copied, moved or renamed.

## Achievements

Project Eris ++ only uses genuine RetroAchievements definitions from validated local cache/FDB data. It does not generate fake triggers. If the required data is not already cached, DuckStation plus `RA_Integration.dll` can be used to create the genuine local cache.

If a game cannot obtain a valid achievement pack, the report marks it as blocked instead of inventing achievement data.

## After installation

Safely eject the USB drive and boot the PlayStation Classic normally. The first-boot Internal 20 export behavior remains the same as in the working 1.0.20 base.

## Troubleshooting

If something fails, keep the report file written to the USB and run `Check_Runtime_After_Test.bat` after a console test when runtime diagnostics are needed. The detailed Windows prerequisites are in `README_SETUP_EN.txt`.

## 1.0.21 bug fix

The legacy Manager performance-mode selector was fixed so its event handler no longer references an unset `$modeBox` variable.

Project Eris ++ is an unofficial community project and is not affiliated with Sony, Project Eris/ModMyClassic, Libretro/RetroArch, DuckStation or RetroAchievements.

**Copyright Frozsti 2026**
