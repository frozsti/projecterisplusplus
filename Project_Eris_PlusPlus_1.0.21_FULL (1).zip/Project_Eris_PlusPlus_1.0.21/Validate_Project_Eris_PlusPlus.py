from pathlib import Path
import hashlib, json, struct, subprocess, re, sys
ROOT=Path(__file__).resolve().parent
PASS=0; FAIL=0; rows=[]

def check(name, ok, detail=''):
    global PASS,FAIL
    if ok:
        PASS+=1; rows.append('PASS '+name+((' :: '+detail) if detail else ''))
    else:
        FAIL+=1; rows.append('FAIL '+name+((' :: '+detail) if detail else ''))

def pstext(rel):
    b=(ROOT/rel).read_bytes()
    if b.startswith(b'\xef\xbb\xbf'): b=b[3:]
    return b.decode('ascii')

def ascii_ps(path):
    b=path.read_bytes(); bom=b.startswith(b'\xef\xbb\xbf')
    try: (b[3:] if bom else b).decode('ascii'); asc=True
    except Exception: asc=False
    return bom,asc

def simple_ps_balance(text):
    out=[]; i=0; n=len(text); state='code'
    while i<n:
        c=text[i]; nxt=text[i:i+2]
        if state=='code':
            if nxt=='<#': state='blockcomment'; i+=2; continue
            if c=='#': state='linecomment'; i+=1; continue
            if text.startswith("@'",i): state='heresingle'; i+=2; continue
            if text.startswith('@"',i): state='heredouble'; i+=2; continue
            if c=="'": state='single'; i+=1; continue
            if c=='"': state='double'; i+=1; continue
            out.append(c); i+=1; continue
        if state=='linecomment':
            if c in '\r\n': state='code'; out.append(c)
            i+=1; continue
        if state=='blockcomment':
            if nxt=='#>': state='code'; i+=2
            else: i+=1
            continue
        if state=='single':
            if c=="'":
                if i+1<n and text[i+1]=="'": i+=2; continue
                state='code'
            i+=1; continue
        if state=='double':
            if c=='`' and i+1<n: i+=2; continue
            if c=='"': state='code'
            i+=1; continue
        if state=='heresingle':
            if (i==0 or text[i-1] in '\r\n') and text.startswith("'@",i): state='code'; i+=2
            else: i+=1
            continue
        if state=='heredouble':
            if (i==0 or text[i-1] in '\r\n') and text.startswith('"@',i): state='code'; i+=2
            else: i+=1
            continue
    if state not in ('code','linecomment'): return False,'unterminated '+state
    pairs={')':'(',']':'[','}':'{'}; stack=[]
    for idx,c in enumerate(''.join(out)):
        if c in '([{': stack.append((c,idx))
        elif c in ')]}':
            if not stack or stack[-1][0]!=pairs[c]: return False,f'mismatch {c} at {idx}'
            stack.pop()
    return (not stack, '' if not stack else 'unclosed '+stack[-1][0])

required=[
 'VERSION.json','README.md','README_SETUP_EN.txt','QUICK_START.txt','PUBLISH_TO_GITHUB.md','THIRD_PARTY_NOTES.txt','LICENSING_TODO.md',
 'RELEASE_NOTES_1.0.21.txt','UPDATE_EXISTING_PROJECT_ERIS_PP.bat','Start_Project_Eris_PlusPlus.bat','Check_Runtime_After_Test.bat',
 'windows/ProjectErisPlusPlus.Core.ps1','windows/ProjectErisPlusPlus.Wizard.ps1','windows/ProjectErisPlusPlus.DesktopWizard.ps1','windows/ProjectErisPlusPlus.SimpleWizard.ps1',
 'windows/ProjectErisPlusPlus.InPlaceUpdate.ps1','windows/ProjectErisPlusPlus.Performance.ps1','windows/Collect-RuntimeCheck.ps1',
 'console/runtime/erispp_eval.arm','console/runtime/erispp_audio_bridge.so','console/runtime/erispp_hook.sh','console/runtime/erispp_prelaunch.sh',
 'console/launcher/projecterispp_libretro.so','installer/ProjectErisPlusPlusSetup.go','installer/Build-Installer.ps1','installer/README_INSTALLER_SOURCE.txt',
 '.github/workflows/build-windows-installer.yml'
]
for rel in required: check('exists:'+rel,(ROOT/rel).is_file())

v=json.loads((ROOT/'VERSION.json').read_text())
check('version',v.get('version')=='1.0.21',str(v.get('version')))
check('product',v.get('product')=='Project Eris ++')
check('ui-language',v.get('ui_language')=='English only')
check('scope-english-only','english-only-distribution' in v.get('scope',''))
check('scope-existing-usb','existing-usb-achievement-import' in v.get('scope',''))
check('scope-performance','performance-index' in v.get('scope',''))
check('scope-save-state','exit-only-savestate' in v.get('scope',''))
check('scope-exporter-cleanup','permanent-exporter-cleanup' in v.get('scope',''))

for p in sorted((ROOT/'windows').glob('*.ps1')):
    bom,asc=ascii_ps(p); check('ps-bom:'+p.name,bom); check('ps-ascii:'+p.name,asc)
    if asc:
        ok,detail=simple_ps_balance(pstext('windows/'+p.name)); check('ps-balance:'+p.name,ok,detail)

for p in list(sorted((ROOT/'console').rglob('*.sh'))) + [ROOT/'console/firstboot/retroarch']:
    if not p.exists(): continue
    r=subprocess.run(['sh','-n',str(p)],capture_output=True,text=True)
    check('sh-syntax:'+str(p.relative_to(ROOT)),r.returncode==0,r.stderr.strip())

# Proven runtime binaries must remain byte-for-byte identical.
e=ROOT/'console/runtime/erispp_eval.arm'; eh=hashlib.sha256(e.read_bytes()).hexdigest()
check('evaluator-v105-byte-identity',eh=='13f97c5c8aec2da104e7e66bd42f3707d9a7d952da6e22541b6f0b1ddf7e52f4',eh)
a=ROOT/'console/runtime/erispp_audio_bridge.so'; ah=hashlib.sha256(a.read_bytes()).hexdigest()
check('audio-bridge-v110-byte-identity',ah=='d81568348f1dfc237bd096b3378f60bff5f3385c12bb5f3d094ce1a00c4f3c65',ah)
for label,p in [('audio-bridge',a),('hub-core',ROOT/'console/launcher/projecterispp_libretro.so')]:
    raw=p.read_bytes(); check(label+'-elf32-arm',raw[:4]==b'\x7fELF' and raw[4]==1 and struct.unpack_from('<H',raw,18)[0]==40)
    if raw[:4]==b'\x7fELF' and len(raw)>=40: check(label+'-hardfloat',bool(struct.unpack_from('<I',raw,36)[0] & 0x400))

core=pstext('windows/ProjectErisPlusPlus.Core.ps1')
wizard=pstext('windows/ProjectErisPlusPlus.Wizard.ps1')
desktop=pstext('windows/ProjectErisPlusPlus.DesktopWizard.ps1')
simple=pstext('windows/ProjectErisPlusPlus.SimpleWizard.ps1')
perf=pstext('windows/ProjectErisPlusPlus.Performance.ps1')
checker=pstext('windows/Collect-RuntimeCheck.ps1')
funcs=(ROOT/'windows/payload/0030_retroarch.funcs').read_text()
ui_src=(ROOT/'source/projecterispp_ui.c').read_text()
setupgo=(ROOT/'installer/ProjectErisPlusPlusSetup.go').read_text()

# v1.0.21 English-only public surface.
for rel in ['README.md','README_SETUP_EN.txt','QUICK_START.txt','PUBLISH_TO_GITHUB.md','RELEASE_NOTES_1.0.21.txt']:
    check('english-doc-name:'+rel,(ROOT/rel).is_file())
check('no-language-specific-readme',not (ROOT/'README_NL.txt').exists() and not (ROOT/'README_SETUP_NL.txt').exists())
check('no-language-specific-publish-guide',not (ROOT/'PUBLISH_TO_GITHUB_NL.md').exists())
check('desktop-english-guide','SETUP GUIDE' in desktop and 'README_SETUP_EN.txt' in desktop)
check('simple-english-title','Project Eris ++ 1.0.21' in simple)
check('desktop-no-old-guide-label','Open Dutch setup guide' not in desktop)
check('setup-go-version','const version = "1.0.21"' in setupgo)
check('setup-go-english-install','will be installed for the current Windows user' in setupgo)
check('setup-go-english-uninstall','Remove Project Eris ++?' in setupgo)
check('setup-go-english-guide','README_SETUP_EN.txt' in setupgo and 'Setup Guide.lnk' in setupgo)

# Simple front-door wizard markers.
for marker in ['INSTALL PROJECT ERIS ++ TO USB','INSTALL ONE GAME','INSTALL A GAME FOLDER','USE CURRENT USB LIBRARY','SCAN AGAIN','SETUP GUIDE','VERSION 1.0.21','Copyright Frozsti 2026']:
    check('simple-ui:'+marker,marker in simple)
check('simple-three-game-actions',simple.count("=New-Button 'INSTALL ONE GAME'")==1 and simple.count("=New-Button 'INSTALL A GAME FOLDER'")==1 and simple.count("=New-Button 'USE CURRENT USB LIBRARY'")==1)
check('simple-one-game-core','Add-GameFiles $script:Usb' in simple)
check('simple-folder-core','Import-ErisPPGameLibrary $script:Usb' in simple)
check('simple-existing-core','Import-ErisPPInstalledUsbGames $script:Usb' in simple)
check('simple-usb-preflight','Test-Preflight $script:Usb' in simple)
check('simple-deploy-core','Deploy-ProjectErisPP $script:Usb' in simple)
check('simple-copyright','Copyright Frozsti 2026' in simple and 'PROJECT_ERIS_PP_README.txt' in core)
check('setup-launches-simple','ProjectErisPlusPlus.SimpleWizard.ps1' in setupgo)
check('manager-modebox-sender-bugfix','param($sender,$eventArgs)' in wizard and '$selected=[string]$sender.SelectedItem' in wizard)
check('manager-no-modebox-handler-reference','$modeBox.Add_SelectedIndexChanged({if($modeBox.SelectedItem)' not in wizard)
check('manager-flat-buttons','FlatStyle' in wizard and 'FlatAppearance.BorderColor' in wizard)
check('manager-installed-import-accent',"$existingUsb.BackColor" in wizard)

# Existing USB import behavior remains no-copy/FDB-first.
check('existing-usb-scan','function Get-ErisPPInstalledUsbGameScan' in core)
check('existing-usb-import','function Import-ErisPPInstalledUsbGames' in core)
check('existing-usb-ui','Import installed USB games' in wizard)
func=core[core.index('function Import-ErisPPInstalledUsbGames'):core.index('function Repair-ErisPPUniqueProgress')]
check('existing-usb-no-transfer-copy','Copy-GameTransferFile' not in func)
check('existing-usb-no-copy-item','Copy-Item' not in func)
check('existing-usb-report','PROJECT_ERIS_PP_LAST_EXISTING_USB_IMPORT.txt' in core)
check('existing-usb-fdb-first','Ensure-ErisPPGamePack' in func)

# Previously proven behavior remains present.
check('performance-fast-mode','Fast' in perf and 'Verify' in wizard and 'Full rebuild' in wizard)
check('performance-ui-throttle','ElapsedMilliseconds -ge 250' in wizard or 'ElapsedMilliseconds -lt 250' in wizard)
check('save-state-exit-only','SnapshotPolicy=exit-only' in funcs and 'ScreenshotPolicy=exit-only-thumbnail' in funcs)
check('save-state-no-live-worker','erispp_live_snapshot_worker' not in funcs)
check('save-state-no-periodic-screenshot','erispp_send_ra_command "SCREENSHOT"' not in funcs)
check('save-state-resume-load','erispp_send_ra_command "LOAD_STATE"' in funcs)
check('hub-alpha-sort','sort_games_alpha' in ui_src and 'title_cmp_ci' in ui_src)
check('hub-header-small','text(70,21,"PROJECT ERIS ++",3' in ui_src)
check('hub-achievement-shift','text(360,25,"ACHIEVEMENTS",3' in ui_src)
check('runtime-check-existing-import','[EXISTING USB GAME IMPORT LAST]' in checker)

# GT2 reference data remains intact.
f=ROOT/'windows/bundled_packs/database/11278.fdb'; lines=f.read_text(errors='replace').splitlines()
check('gt2-fdb-header',bool(lines) and lines[0].startswith('ERPP2\t11278\t124\t'))
check('gt2-fdb-achievements',sum(1 for x in lines if x.startswith('A\t'))==124)

# Public release must not accidentally contain games/BIOS binaries.
rom_ext={'.bin','.cue','.iso','.chd','.pbp','.m3u','.img','.mdf','.ccd','.sub','.ecm','.bios'}; found=[]
for p in ROOT.rglob('*'):
    if not p.is_file(): continue
    rel=p.relative_to(ROOT).as_posix().lower()
    if rel.startswith('windows/bundled_cache/') or rel.startswith('windows/bundled_packs/'): continue
    if p.suffix.lower() in rom_ext: found.append(str(p.relative_to(ROOT)))
check('no-rom-bios-payload',not found,','.join(found[:5]))

print('\n'.join(rows))
print(f'RESULT PASS={PASS} FAIL={FAIL}')
if FAIL: sys.exit(1)
