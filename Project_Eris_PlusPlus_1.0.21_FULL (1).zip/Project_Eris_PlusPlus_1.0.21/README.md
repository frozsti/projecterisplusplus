# Project Eris ++ 1.0.21

Project Eris ++ is an unofficial community add-on for Project Eris on the Sony PlayStation Classic. This release keeps the proven 1.0.20 runtime and achievement workflow, but replaces the normal Windows front end with a much shorter installer flow.

## What the installer does

1. Detects a USB drive with a working Project Eris installation.
2. Runs the existing Project Eris ++ preflight checks.
3. Creates the normal Project Eris backup before changing the USB.
4. Installs Project Eris ++ as one package.
5. Offers exactly three normal game workflows:
   - **Install One Game**
   - **Install a Game Folder**
   - **Use Current USB Library**

The first two options use the existing FDB-first transfer workflow. The third scans games already present on the Project Eris USB and adds Project Eris ++ achievement mappings without copying, moving or renaming those game images.

## Achievement data

Project Eris ++ uses genuine RetroAchievements definitions from a validated local cache/FDB. It does not invent achievement triggers. DuckStation plus `RA_Integration.dll` is only needed when the required achievement data is not already available locally.

## Important

Project Eris ++ does not include ROMs, disc images, BIOS files, RetroAchievements credentials, DuckStation or `RA_Integration.dll`. Use only game and BIOS files you are legally allowed to use.

## Bug fix in 1.0.21

The legacy Manager performance-mode selector no longer depends on the outer `$modeBox` variable inside its `SelectedIndexChanged` event. The handler now uses its event sender, preventing the uninitialized-variable crash reported in 1.0.20.

## Public release

See `README_REDDIT.md` for a ready-to-post installation guide and `README_SETUP_EN.txt` for detailed prerequisites and troubleshooting.

Copyright Frozsti 2026.
