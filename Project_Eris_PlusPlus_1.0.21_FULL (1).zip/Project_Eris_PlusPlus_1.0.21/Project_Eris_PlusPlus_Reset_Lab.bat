@echo off
setlocal
cd /d "%~dp0"
echo Checking Project Eris ++ PowerShell files...
powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0windows\Validate-PowerShell.ps1"
if errorlevel 1 (
  echo.
  echo Project Eris ++ Reset Lab stopped because a PowerShell parser error was detected.
  pause
  exit /b 10
)
powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0windows\ProjectErisPlusPlus.ResetLab.ps1"
if errorlevel 1 pause
