@echo off
setlocal
cd /d "%~dp0"
echo Checking Project Eris ++ achievement repair scripts...
powershell.exe -NoProfile -ExecutionPolicy Bypass -Command "$ErrorActionPreference='Stop';$files=@('.\windows\ProjectErisPlusPlus.RichCompiler.ps1','.\windows\ProjectErisPlusPlus.Core.ps1','.\windows\ProjectErisPlusPlus.AchievementRepair.ps1');foreach($f in $files){$tokens=$null;$errors=$null;[void][System.Management.Automation.Language.Parser]::ParseFile((Resolve-Path $f),[ref]$tokens,[ref]$errors);if($errors.Count){foreach($e in $errors){Write-Host ('ERROR: '+$e.Message+' at '+$e.Extent.StartLineNumber) -ForegroundColor Red};exit 1}else{Write-Host ('OK: '+(Resolve-Path $f)) -ForegroundColor Green}}"
if errorlevel 1 (
  echo.
  echo Parser check failed. Nothing was changed.
  pause
  exit /b 1
)
powershell.exe -NoProfile -ExecutionPolicy Bypass -File ".\windows\ProjectErisPlusPlus.AchievementRepair.ps1"
if errorlevel 1 pause
endlocal
