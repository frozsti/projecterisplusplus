#!/bin/sh
source "/var/volatile/project_eris.cfg" 2>/dev/null
echo 2 > "/data/power/disable" 2>/dev/null
ROOT="/media/PROJECT_ERIS_PP_INTERNAL_EXPORT"
LOG="/media/PROJECT_ERIS_PP_INTERNAL_EXPORT.log"
CORELOG="/media/PROJECT_ERIS_PP_INTERNAL_CORE.log"
RA="/media/project_eris/opt/retroarch/retroarch"
CFG="/media/project_eris/opt/retroarch/config/retroarch/retroarch.cfg"
CORE="/var/volatile/launchtmp/erispp_internal_export_libretro.so"
CONTENT="/var/volatile/launchtmp/erispp_internal.erispp"
WORKER="/var/volatile/launchtmp/export_worker.sh"
mkdir -p "$ROOT"
: > "$CORELOG"
echo "========================================" >> "$LOG"
echo "$(date 2>/dev/null) Project Eris ++ Internal Export 1.0.13" >> "$LOG"
if [ ! -f "$ROOT/EXPORT_COMPLETE.txt" ]; then
 if ! ps | grep '[e]xport_worker.sh' >/dev/null 2>&1; then
  sh "$WORKER" >/dev/null 2>&1 &
  echo "worker started pid=$!" >> "$LOG"
 fi
fi
cd /var/volatile/launchtmp || exit 2
"$RA" --config "$CFG" --verbose -L "$CORE" "$CONTENT" >> "$LOG" 2>&1
RC=$?
echo "$(date 2>/dev/null) Export UI rc=$RC" >> "$LOG"
echo "launch_stockui" > /tmp/launchfilecommand
exit 0
