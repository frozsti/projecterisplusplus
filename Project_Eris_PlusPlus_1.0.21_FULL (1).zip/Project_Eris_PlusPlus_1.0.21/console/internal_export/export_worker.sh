#!/bin/sh
ROOT="/media/PROJECT_ERIS_PP_INTERNAL_EXPORT"
GAMES="$ROOT/games"
STATUS="$ROOT/status.txt"
LOG="/media/PROJECT_ERIS_PP_INTERNAL_EXPORT.log"
MAN="$ROOT/manifest.tsv"
TOTAL=20

mkdir -p "$ROOT" "$GAMES"

write_status(){
  PH="$1"; DONE="$2"; CUR="$3"; MSG="$4"; ERR="$5"
  {
    echo "PHASE=$PH"
    echo "DONE=$DONE"
    echo "TOTAL=$TOTAL"
    echo "CURRENT=$CUR"
    echo "MESSAGE=$MSG"
    echo "ERROR=$ERR"
  } > "$STATUS"
}

title_for(){
  case "$1" in
    1) echo "Battle Arena Toshinden";;
    2) echo "Cool Boarders 2";;
    3) echo "Destruction Derby";;
    4) echo "Final Fantasy VII";;
    5) echo "Grand Theft Auto";;
    6) echo "Intelligent Qube";;
    7) echo "Jumping Flash!";;
    8) echo "Metal Gear Solid";;
    9) echo "Mr Driller";;
    10) echo "Oddworld - Abe's Oddysee";;
    11) echo "Rayman";;
    12) echo "Resident Evil - Director's Cut";;
    13) echo "Persona Revelations";;
    14) echo "R4 - Ridge Racer Type 4";;
    15) echo "Super Puzzle Fighter II Turbo";;
    16) echo "Syphon Filter";;
    17) echo "Tekken 3";;
    18) echo "Tom Clancy's Rainbow Six";;
    19) echo "Twisted Metal";;
    20) echo "Wild Arms";;
  esac
}
raid_for(){
  case "$1" in
    1) echo 11414;; 2) echo 7332;; 3) echo 14045;; 4) echo 11242;; 5) echo 10437;;
    6) echo 13904;; 7) echo 14048;; 8) echo 11244;; 9) echo 5573;; 10) echo 11295;;
    11) echo 11346;; 12) echo 11268;; 13) echo 11371;; 14) echo 11305;; 15) echo 14379;;
    16) echo 10675;; 17) echo 11259;; 18) echo 11591;; 19) echo 11383;; 20) echo 11310;;
  esac
}
set_for(){
  case "$1" in 2|3|18) echo "NO_SET";; *) echo "SET";; esac
}

echo "==================================================" >> "$LOG"
echo "$(date 2>/dev/null) Internal20 export worker 1.0.18 start" >> "$LOG"

if [ -f "$ROOT/EXPORT_COMPLETE.txt" ]; then
  write_status "COMPLETE" 20 "All internal games" "Export already complete." ""
  echo "Already complete" >> "$LOG"
  exit 0
fi

if [ ! -d /gaadata ]; then
  write_status "ERROR" 0 "" "Internal storage /gaadata not found." "GAADATA_MISSING"
  echo "ERROR: /gaadata missing" >> "$LOG"
  exit 2
fi

NEED="$(du -sk /gaadata 2>/dev/null | awk '{print $1}')"
FREE="$(df -Pk /media 2>/dev/null | tail -n 1 | awk '{print $4}')"
[ -z "$NEED" ] && NEED=0
[ -z "$FREE" ] && FREE=0
echo "NEED_KB=$NEED FREE_KB=$FREE" >> "$LOG"
if [ "$NEED" -gt 0 ] && [ "$FREE" -gt 0 ]; then
  RESERVE=262144
  WANT=$((NEED + RESERVE))
  if [ "$FREE" -lt "$WANT" ]; then
    write_status "ERROR" 0 "" "Not enough USB free space." "NEED_${WANT}_KB_FREE_${FREE}_KB"
    echo "ERROR: not enough free space" >> "$LOG"
    exit 3
  fi
fi

# Manifest header, rebuilt safely. Rows are appended after each completed slot.
echo "#slot	ra_id	set_status	title	launch_relative" > "$MAN"

DONE=0
i=1
while [ "$i" -le 20 ]; do
  TITLE="$(title_for "$i")"
  RAID="$(raid_for "$i")"
  SETSTATUS="$(set_for "$i")"
  SRC="/gaadata/$i"
  DEST="$GAMES/$(printf '%02d' "$i")"
  PART="$DEST.partial"

  write_status "COPYING" "$DONE" "$TITLE" "Copying internal game $i of 20. Do not power off." ""

  if [ -f "$DEST/.complete" ]; then
    echo "SKIP complete slot $i $TITLE" >> "$LOG"
  else
    rm -rf "$PART"
    mkdir -p "$PART"
    if [ ! -d "$SRC" ]; then
      write_status "ERROR" "$DONE" "$TITLE" "Source folder missing." "MISSING_SLOT_$i"
      echo "ERROR missing $SRC" >> "$LOG"
      exit 4
    fi
    echo "$(date 2>/dev/null) COPY slot=$i title=$TITLE mode=REGULAR_DISC_FILES" >> "$LOG"
    LIST="/tmp/erispp_internal20_files_$$"
    find "$SRC" -type f > "$LIST" 2>>"$LOG"
    RC=$?
    if [ "$RC" -ne 0 ]; then
      rm -f "$LIST"
      write_status "ERROR" "$DONE" "$TITLE" "Could not enumerate internal game files." "FIND_RC_$RC"
      echo "ERROR find rc=$RC slot=$i" >> "$LOG"
      exit 5
    fi

    COPIED=0
    while IFS= read -r F; do
      case "$F" in
        *.cue|*.CUE|*.bin|*.BIN|*.img|*.IMG|*.iso|*.ISO|*.pbp|*.PBP|*.chd|*.CHD|*.ccd|*.CCD|*.sub|*.SUB|*.mds|*.MDS|*.mdf|*.MDF|*.m3u|*.M3U)
          REL="${F#$SRC/}"
          PARENT="$(dirname "$REL")"
          TARGET="$PART/$REL"

          if [ "$PARENT" != "." ]; then
            mkdir -p "$PART/$PARENT" >> "$LOG" 2>&1
            RC=$?
            if [ "$RC" -ne 0 ]; then
              rm -f "$LIST"
              write_status "ERROR" "$DONE" "$TITLE" "Could not create destination folder." "MKDIR_RC_$RC"
              echo "COPY_FATAL stage=mkdir rc=$RC src=$F target=$TARGET parent=$PARENT" >> "$LOG"
              exit 5
            fi
          fi

          SRC_BYTES="$(wc -c < "$F" 2>/dev/null | tr -d ' ')"
          [ -z "$SRC_BYTES" ] && SRC_BYTES=0
          FREE_NOW="$(df -Pk /media 2>/dev/null | tail -n 1 | awk '{print $4}')"
          echo "COPY_ATTEMPT slot=$i src=$F target=$TARGET bytes=$SRC_BYTES free_kb=$FREE_NOW" >> "$LOG"

          rm -f "$TARGET" 2>/dev/null

          # Method 1: BusyBox cp. Fast path.
          cp "$F" "$TARGET" >> "$LOG" 2>&1
          RC=$?
          METHOD="cp"

          # Method 2: shell byte stream. Avoids cp-specific cross-filesystem quirks.
          if [ "$RC" -ne 0 ]; then
            echo "COPY_METHOD_FAIL method=cp rc=$RC src=$F target=$TARGET" >> "$LOG"
            rm -f "$TARGET" 2>/dev/null
            cat "$F" > "$TARGET" 2>> "$LOG"
            RC=$?
            METHOD="cat"
          fi

          # Method 3: dd fallback. Uses no metadata/symlink operations.
          if [ "$RC" -ne 0 ]; then
            echo "COPY_METHOD_FAIL method=cat rc=$RC src=$F target=$TARGET" >> "$LOG"
            rm -f "$TARGET" 2>/dev/null
            dd if="$F" of="$TARGET" bs=1048576 >> "$LOG" 2>&1
            RC=$?
            METHOD="dd"
          fi

          if [ "$RC" -ne 0 ]; then
            echo "COPY_METHOD_FAIL method=dd rc=$RC src=$F target=$TARGET" >> "$LOG"
            rm -f "$TARGET" 2>/dev/null
            rm -f "$LIST"
            BASEF="$(basename "$F")"
            write_status "ERROR" "$DONE" "$TITLE" "Could not copy: $BASEF" "COPY_ALL_METHODS_RC_$RC"
            echo "COPY_FATAL stage=data rc=$RC src=$F target=$TARGET bytes=$SRC_BYTES" >> "$LOG"
            exit 5
          fi

          DST_BYTES="$(wc -c < "$TARGET" 2>/dev/null | tr -d ' ')"
          [ -z "$DST_BYTES" ] && DST_BYTES=0
          if [ "$SRC_BYTES" != "$DST_BYTES" ]; then
            echo "COPY_VERIFY_FAIL method=$METHOD src=$F target=$TARGET source_bytes=$SRC_BYTES target_bytes=$DST_BYTES" >> "$LOG"
            rm -f "$TARGET" 2>/dev/null
            rm -f "$LIST"
            BASEF="$(basename "$F")"
            write_status "ERROR" "$DONE" "$TITLE" "Size verification failed: $BASEF" "SIZE_MISMATCH"
            exit 5
          fi

          echo "COPY_OK method=$METHOD src=$F target=$TARGET bytes=$DST_BYTES" >> "$LOG"
          COPIED=$((COPIED+1))
          ;;
      esac
    done < "$LIST"
    rm -f "$LIST"

    if [ "$COPIED" -lt 1 ]; then
      write_status "ERROR" "$DONE" "$TITLE" "No PS1 disc files found in this internal slot." "NO_DISC_FILES_$i"
      echo "ERROR no recognized disc files slot=$i src=$SRC" >> "$LOG"
      exit 6
    fi

    echo "COPIED_FILES slot=$i count=$COPIED" >> "$LOG"
    sync 2>/dev/null || true
    rm -rf "$DEST"
    mv "$PART" "$DEST"
    touch "$DEST/.complete"
  fi

  # Create a DuckStation-friendly m3u when there is more than one CUE.
  CUES=0
  for f in "$DEST"/*.cue "$DEST"/*.CUE; do
    [ -f "$f" ] || continue
    CUES=$((CUES+1))
  done
  LAUNCH=""
  if [ "$CUES" -gt 1 ]; then
    : > "$DEST/launch.m3u"
    for f in "$DEST"/*.cue "$DEST"/*.CUE; do
      [ -f "$f" ] || continue
      basename "$f" >> "$DEST/launch.m3u"
    done
    LAUNCH="games/$(printf '%02d' "$i")/launch.m3u"
  else
    for f in "$DEST"/*.cue "$DEST"/*.CUE; do
      [ -f "$f" ] || continue
      LAUNCH="games/$(printf '%02d' "$i")/$(basename "$f")"
      break
    done
  fi
  if [ -z "$LAUNCH" ]; then
    for f in "$DEST"/*.pbp "$DEST"/*.PBP "$DEST"/*.chd "$DEST"/*.CHD; do
      [ -f "$f" ] || continue
      LAUNCH="games/$(printf '%02d' "$i")/$(basename "$f")"
      break
    done
  fi

  printf "%s\t%s\t%s\t%s\t%s\n" "$i" "$RAID" "$SETSTATUS" "$TITLE" "$LAUNCH" >> "$MAN"
  DONE=$((DONE+1))
  write_status "COPYING" "$DONE" "$TITLE" "Completed $DONE of 20." ""
  i=$((i+1))
done

# Copy the generated Internal playlist as reference when available.
for P in \
 "/media/project_eris/opt/retroarch/config/retroarch/playlists/PlayStation Classic - Internal.lpl" \
 "/media/project_eris/etc/project_eris/SUP/retroarch/psc_row.lpl"; do
  if [ -f "$P" ]; then cp -f "$P" "$ROOT/" 2>/dev/null; fi
done

{
  echo "Project Eris ++ Internal export complete"
  echo "Date=$(date 2>/dev/null)"
  echo "Source=/gaadata"
  echo "Games=20"
  echo "Manifest=$MAN"
} > "$ROOT/EXPORT_COMPLETE.txt"

write_status "COMPLETE" 20 "All internal games" "Export complete. Move USB to PC and run the Project Eris ++ Wizard." ""
echo "$(date 2>/dev/null) EXPORT COMPLETE" >> "$LOG"
exit 0
