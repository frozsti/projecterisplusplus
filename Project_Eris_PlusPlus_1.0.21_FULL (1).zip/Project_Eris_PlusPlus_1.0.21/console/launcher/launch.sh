#!/bin/sh
source "/var/volatile/project_eris.cfg" 2>/dev/null
echo 2 > "/data/power/disable" 2>/dev/null
LOG="/media/PROJECT_ERIS_PP_UI_LAUNCH.log"
RA="/media/project_eris/opt/retroarch/retroarch"
CFG="/media/project_eris/opt/retroarch/config/retroarch/retroarch.cfg"
CORE="/var/volatile/launchtmp/projecterispp_libretro.so"
CONTENT="/var/volatile/launchtmp/projecterispp.erispp"
echo "========================================" >> "$LOG"
echo "$(date 2>/dev/null) Project Eris ++ Achievements 1.0.0" >> "$LOG"
cd /var/volatile/launchtmp || exit 2
"$RA" --config "$CFG" --verbose -L "$CORE" "$CONTENT" >> "$LOG" 2>&1
RC=$?
echo "$(date 2>/dev/null) RetroArch rc=$RC" >> "$LOG"
echo "launch_stockui" > /tmp/launchfilecommand
exit 0
