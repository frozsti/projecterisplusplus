#!/bin/sh
# Project Eris ++ v1.0.17 runtime hook
# Proven v1.0.5 evaluator + exact v1.0.4 PID resolver.
# Achievement audio is mixed in-process by the LD_PRELOAD ALSA bridge.
ROOT="${ERISPP_ROOT:-/media/project_eris/etc/project_eris/etc/erispp}"
PROC_ROOT="${ERISPP_PROC_ROOT:-/proc}"
MAP="$ROOT/content_map.tsv"
EVAL="$ROOT/runtime/erispp_eval.arm"
LOG="${ERISPP_LOG:-/media/PROJECT_ERIS_PP_HOOK.log}"
PLAYED="$ROOT/profiles/active/played.tsv"

[ -f "$MAP" ] || exit 0
CONTENT=""
for A in "$@"; do
 case "$A" in
  *.cue|*.CUE|*.chd|*.CHD|*.pbp|*.PBP|*.iso|*.ISO|*.m3u|*.M3U|*.bin|*.BIN) CONTENT="$A" ;;
 esac
done
[ -n "$CONTENT" ] || exit 0
BASE="$(basename "$CONTENT")"
GID="$(awk -F '	' -v b="$BASE" '$2==b {print $1; exit}' "$MAP" 2>/dev/null)"
[ -n "$GID" ] || { echo "$(date 2>/dev/null) map_miss content=$CONTENT base=$BASE" >> "$LOG"; exit 0; }

mkdir -p "$ROOT/profiles/active" "$ROOT/state" 2>/dev/null
if ! grep -q "^${GID}[[:space:]]" "$PLAYED" 2>/dev/null; then
 printf "%s	%s	%s
" "$GID" "$(date '+%Y-%m-%d %H:%M:%S' 2>/dev/null)" "$BASE" >> "$PLAYED"
fi

echo "$(date 2>/dev/null) hook_v110 content=$CONTENT base=$BASE gid=$GID" >> "$LOG"
FDB="$ROOT/database/$GID.fdb"
[ -f "$FDB" ] || { echo "$(date 2>/dev/null) no_fdb gid=$GID path=$FDB" >> "$LOG"; exit 0; }
[ -x "$EVAL" ] || { echo "$(date 2>/dev/null) evaluator_missing path=$EVAL" >> "$LOG"; exit 0; }

PID=""
N=0
while [ "$N" -lt 600 ]; do
 for P in "$PROC_ROOT"/[0-9]*; do
  [ -r "$P/exe" ] || continue
  EXE="$(readlink "$P/exe" 2>/dev/null)"
  case "$EXE" in
   */retroarch)
    [ -r "$P/cmdline" ] || continue
    if ! tr '\000' '\n' < "$P/cmdline" 2>/dev/null | grep -F -x "$CONTENT" >/dev/null 2>&1; then continue; fi
    [ -r "$P/maps" ] || continue
    if grep -q '^80000000-802' "$P/maps" 2>/dev/null; then PID="${P##*/}"; break; fi
   ;;
  esac
 done
 [ -n "$PID" ] && break
 sleep 0.1
 N=$((N+1))
done
[ -n "$PID" ] || { echo "$(date 2>/dev/null) retroarch_pid_timeout gid=$GID content=$CONTENT" >> "$LOG"; exit 0; }

PRELOAD=""
if [ -r "$PROC_ROOT/$PID/environ" ]; then
 PRELOAD="$(tr '\000' '\n' < "$PROC_ROOT/$PID/environ" 2>/dev/null | grep '^LD_PRELOAD=' | head -n1 | cut -d= -f2-)"
fi
if echo "$PRELOAD" | grep -F 'erispp_audio_bridge.so' >/dev/null 2>&1; then
 echo "$(date 2>/dev/null) audio_bridge_env gid=$GID pid=$PID preload=present" >> "$LOG"
else
 echo "$(date 2>/dev/null) audio_bridge_env gid=$GID pid=$PID preload=missing value=$PRELOAD" >> "$LOG"
fi

EXE="$(readlink "$PROC_ROOT/$PID/exe" 2>/dev/null)"
MAPLINE="$(grep '^80000000-802' "$PROC_ROOT/$PID/maps" 2>/dev/null | head -n1)"
ACHCOUNT="$(awk -F '	' '$1=="A"{n++} END{print n+0}' "$FDB" 2>/dev/null)"
CONDCOUNT="$(awk -F '	' '$1=="C"{n++} END{print n+0}' "$FDB" 2>/dev/null)"
STATE="$ROOT/state/$GID.unlocked"
HIST="$ROOT/profiles/active/history.tsv"
echo "$(date 2>/dev/null) evaluator_start gid=$GID pid=$PID exe=$EXE ach=$ACHCOUNT cond=$CONDCOUNT map=$MAPLINE" >> "$LOG"
(
 "$EVAL" "$PID" "$FDB" "$STATE" "$HIST" live >> "$LOG" 2>&1
 RC=$?
 echo "$(date 2>/dev/null) evaluator_stop gid=$GID pid=$PID rc=$RC" >> "$LOG"
 case "$RC" in
  0) ;;
  2) echo "$(date 2>/dev/null) evaluator_error bad_arguments" >> "$LOG" ;;
  3) echo "$(date 2>/dev/null) evaluator_error fdb_parse_failed gid=$GID" >> "$LOG" ;;
  4) echo "$(date 2>/dev/null) evaluator_error proc_mem_open_failed pid=$PID" >> "$LOG" ;;
  139) echo "$(date 2>/dev/null) evaluator_error segmentation_fault pid=$PID" >> "$LOG" ;;
  *) echo "$(date 2>/dev/null) evaluator_error unknown_rc=$RC" >> "$LOG" ;;
 esac
) &
WRAP_PID=$!
echo "$(date 2>/dev/null) evaluator_spawned gid=$GID wrapper_pid=$WRAP_PID retroarch_pid=$PID audio=preload_bridge" >> "$LOG"
exit 0
