#!/bin/sh
# Project Eris ++ v1.0.17 prelaunch.
# Keeps top-left OSD and removes only the obsolete Project Eris ++ DSP plugin setting.
ROOT="/media/project_eris/etc/project_eris/etc/erispp"
RA="/media/project_eris/opt/retroarch/config/retroarch"
FLAG="$ROOT/reset/RESET_INTERNAL_SAVES.flag"
LOG="/media/PROJECT_ERIS_PP_RESET.log"

set_ra(){
 F="$1"; K="$2"; V="$3"
 [ -f "$F" ] || return 0
 T="$F.erispp.$$"
 awk -v k="$K" -v v="$V" '
  BEGIN{done=0}
  $0 ~ "^[[:space:]]*" k "[[:space:]]*=" {print k " = \"" v "\"";done=1;next}
  {print}
  END{if(!done)print k " = \"" v "\""}
 ' "$F" > "$T" 2>/dev/null && cat "$T" > "$F"
 rm -f "$T" 2>/dev/null
}
clear_legacy_dmix(){
 F="$1"; [ -f "$F" ] || return 0
 if grep -Eq '^[[:space:]]*audio_device[[:space:]]*=[[:space:]]*"(plug:)?dmix' "$F" 2>/dev/null; then
  T="$F.erispp.dmix.$$"; sed -E 's|^[[:space:]]*audio_device[[:space:]]*=[[:space:]]*"(plug:)?dmix[^"]*"[[:space:]]*$|audio_device = ""|' "$F" > "$T" 2>/dev/null && cat "$T" > "$F"; rm -f "$T" 2>/dev/null
 fi
}
clear_erispp_dsp(){
 F="$1"; [ -f "$F" ] || return 0
 if grep -Eq '^[[:space:]]*audio_dsp_plugin[[:space:]]*=.*erispp_dsp[.]so' "$F" 2>/dev/null; then set_ra "$F" audio_dsp_plugin ""; fi
}
force_runtime_cfg(){
 for F in "$RA/retroarch.cfg" "$RA/retroarch_DEFAULT.cfg" "$RA/ra-game.cfg" "$RA/config/PCSX-ReARMed/PCSX-ReARMed.cfg" "$RA/config/PCSX-ReARMed/title.cfg" "$RA"/config/PCSX-ReARMed/*.cfg; do
  [ -f "$F" ] || continue
  clear_legacy_dmix "$F"; clear_erispp_dsp "$F"
  set_ra "$F" video_font_enable true
  set_ra "$F" video_message_pos_x 0.030000
  set_ra "$F" video_message_pos_y 0.950000
  set_ra "$F" savestate_auto_save true
  set_ra "$F" savestate_directory /tmp/ra_savestate
  set_ra "$F" savestate_thumbnail_enable true
  set_ra "$F" savestate_file_compression false
  set_ra "$F" savestate_auto_index false
  set_ra "$F" state_slot 0
  set_ra "$F" network_cmd_enable true
  set_ra "$F" network_cmd_port 55355
  set_ra "$F" notification_show_save_state false
 done
}
force_runtime_cfg
mkdir -p /tmp/ra_savestate /media/project_eris/opt/retroarch/savestates 2>/dev/null
set_ra "$RA/ra-game.cfg" savestate_auto_load true
set_ra "$RA/ra-game.cfg" savestate_directory /tmp/ra_savestate

[ -f "$FLAG" ] || exit 0
{
 echo "$(date 2>/dev/null) Reset Lab: internal save purge started"
 rm -f /data/AppData/sony/pcsx/.pcsx/memcards/* 2>/dev/null
 rm -f /data/AppData/sony/pcsx/.pcsx/sstates/* 2>/dev/null
 rm -f /data/AppData/sony/pcsx/.pcsx/screenshots/* 2>/dev/null
 rm -f /data/AppData/sony/pcsx/.pcsx/filename.txt 2>/dev/null
 rm -f /media/project_eris/opt/retroarch/saves/* 2>/dev/null
 rm -f /media/project_eris/opt/retroarch/savestates/* 2>/dev/null
 sync 2>/dev/null
 rm -f "$FLAG"
 echo "$(date 2>/dev/null) Reset Lab: internal save purge complete"
} >> "$LOG" 2>&1
exit 0
