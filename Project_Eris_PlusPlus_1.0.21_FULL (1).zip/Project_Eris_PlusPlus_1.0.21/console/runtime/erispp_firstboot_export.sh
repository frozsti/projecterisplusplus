#!/bin/sh
REAL_RA="$1"
ERIS="/media/project_eris/etc/project_eris"
RUNTIME="$ERIS/etc/erispp/runtime"
FIRST="$ERIS/etc/erispp/firstboot"
EXPORTER="$ERIS/etc/erispp/firstboot/exporter"
LEGACY_EXPORTER="$ERIS/SUP/launchers/erispp_internal_export"
ROOT="/media/PROJECT_ERIS_PP_INTERNAL_EXPORT"
LOG="/media/PROJECT_ERIS_PP_FIRSTBOOT.log"
EXPORT_LOG="/media/PROJECT_ERIS_PP_INTERNAL_EXPORT.log"
CORELOG="/media/PROJECT_ERIS_PP_INTERNAL_CORE.log"
MARKER="/media/PROJECT_ERIS_PP_FIRSTBOOT_EXPORT.txt"
RA_PATH="/media/project_eris/opt/retroarch/retroarch"
RA_REAL="/media/project_eris/opt/retroarch/retroarch.erispp_real"
CFG="$ERIS/CFG/project_eris_cfg.INI"
CFG_DEFAULT="$ERIS/CFG/project_eris_cfg_DEFAULT.INI"
RA_CFG="/media/project_eris/opt/retroarch/config/retroarch/retroarch.cfg"
CORE="$EXPORTER/erispp_internal_export_libretro.so"
CONTENT="$EXPORTER/erispp_internal.erispp"
WORKER="$EXPORTER/export_worker.sh"
PENDING="$RUNTIME/FIRST_BOOT_EXPORT_PENDING.flag"
AUTOFLAG="$RUNTIME/AUTO_INTERNAL_EXPORT.flag"
CLEANUP_ROOT="$FIRST/cleanup"

log(){ echo "$(date 2>/dev/null) ERISPP118 $*" >> "$LOG"; }
restore_environment(){
  log "RESTORE_BEGIN"
  [ -f "$FIRST/original_project_eris_cfg.INI" ] && cp -f "$FIRST/original_project_eris_cfg.INI" "$CFG" 2>>"$LOG"
  [ -f "$FIRST/original_project_eris_cfg_DEFAULT.INI" ] && cp -f "$FIRST/original_project_eris_cfg_DEFAULT.INI" "$CFG_DEFAULT" 2>>"$LOG"
  rm -f "$PENDING" "$AUTOFLAG" 2>/dev/null
  rm -f "$FIRST/original_project_eris_cfg.INI" "$FIRST/original_project_eris_cfg_DEFAULT.INI" 2>/dev/null
  sync 2>/dev/null
  log "RESTORE_CONFIG_OK"
}
restore_retroarch(){
  if [ -f "$RA_REAL" ]; then
    rm -f "$RA_PATH" 2>/dev/null
    mv "$RA_REAL" "$RA_PATH" 2>>"$LOG"
    RC=$?
    if [ "$RC" -eq 0 ]; then log "RESTORE_RETROARCH_OK"; else log "RESTORE_RETROARCH_FAIL rc=$RC"; fi
  else
    log "RESTORE_RETROARCH_SKIP real_missing"
  fi
}
wait_worker_exit(){
  I=0
  while ps | grep '[e]xport_worker.sh' >/dev/null 2>&1 && [ "$I" -lt 10 ]; do
    I=$((I+1)); sleep 1
  done
  if ps | grep '[e]xport_worker.sh' >/dev/null 2>&1; then log "WORKER_STILL_PRESENT after_wait=$I"; else log "WORKER_EXIT_CONFIRMED wait=$I"; fi
}
remove_exporter_verified(){
  EXPORTER_MENU_REMOVED=False
  EXPORTER_FILES_REMOVED=False
  rm -rf "$LEGACY_EXPORTER" 2>/dev/null || true
  # The worker and UI are stopped before this function is called. Remove the
  # complete private first-boot area, not only the exporter child directory.
  chmod -R 777 "$FIRST" 2>/dev/null || true
  rm -rf "$FIRST" 2>>"$LOG"
  sync 2>/dev/null
  if [ ! -e "$LEGACY_EXPORTER" ]; then EXPORTER_MENU_REMOVED=True; fi
  if [ ! -e "$FIRST" ]; then EXPORTER_FILES_REMOVED=True; fi
  if [ "$EXPORTER_MENU_REMOVED" = "True" ] && [ "$EXPORTER_FILES_REMOVED" = "True" ]; then
    log "EXPORTER_PERMANENT_REMOVE_OK"
    return 0
  fi
  log "EXPORTER_PERMANENT_REMOVE_FAIL menu=$EXPORTER_MENU_REMOVED files=$EXPORTER_FILES_REMOVED"
  return 1
}
write_complete_marker(){
  printf '%s\n' \
    'Project Eris ++ 1.0.18 automatic internal export' \
    'Mode=COMPLETE' \
    "ExporterMenuRemoved=$EXPORTER_MENU_REMOVED" \
    "ExporterFilesRemoved=$EXPORTER_FILES_REMOVED" \
    'RetryPolicy=disabled' \
    'PowerOffRequested=True' > "$MARKER"
}
power_down(){
  rm -f "$RUNTIME/erispp_firstboot_export.sh" 2>/dev/null || true
  sync 2>/dev/null
  log "POWEROFF_BEGIN"
  if [ -x /sbin/poweroff ]; then /sbin/poweroff >/dev/null 2>&1; fi
  if command -v poweroff >/dev/null 2>&1; then poweroff >/dev/null 2>&1; fi
  if [ -x /bin/busybox ]; then /bin/busybox poweroff >/dev/null 2>&1; fi
  if [ -x /sbin/reboot ]; then /sbin/reboot -p >/dev/null 2>&1; fi
  log "POWEROFF_COMMAND_RETURNED"
  exit 0
}
recovery_reboot(){
  rm -f "$RUNTIME/erispp_firstboot_export.sh" 2>/dev/null || true
  sync 2>/dev/null
  log "RECOVERY_REBOOT_BEGIN"
  if [ -x /sbin/reboot ]; then /sbin/reboot >/dev/null 2>&1; fi
  if command -v reboot >/dev/null 2>&1; then reboot >/dev/null 2>&1; fi
  if [ -x /bin/busybox ]; then /bin/busybox reboot >/dev/null 2>&1; fi
  log "RECOVERY_REBOOT_COMMAND_RETURNED"
  exit 1
}

mkdir -p "$ROOT" "$FIRST" "$CLEANUP_ROOT" 2>/dev/null
rm -rf "$LEGACY_EXPORTER" 2>/dev/null || true
: > "$CORELOG"
echo 2 > /data/power/disable 2>/dev/null
log "AUTO_EXPORT_START real_ra=$REAL_RA"

if [ -f "$ROOT/EXPORT_COMPLETE.txt" ]; then
  log "EXPORT_ALREADY_COMPLETE"
  restore_environment
  wait_worker_exit
  remove_exporter_verified || true
  restore_retroarch
  write_complete_marker
  power_down
fi

if [ ! -f "$REAL_RA" ] || [ ! -f "$CORE" ] || [ ! -f "$CONTENT" ] || [ ! -f "$WORKER" ]; then
  log "PREREQ_FAIL real=$([ -f "$REAL_RA" ] && echo 1 || echo 0) core=$([ -f "$CORE" ] && echo 1 || echo 0) content=$([ -f "$CONTENT" ] && echo 1 || echo 0) worker=$([ -f "$WORKER" ] && echo 1 || echo 0)"
  restore_environment
  wait_worker_exit
  remove_exporter_verified || true
  restore_retroarch
  printf '%s\n' 'Project Eris ++ 1.0.18 automatic internal export' 'Mode=FAILED_PREREQUISITE_PERMANENTLY_CLEANED' "ExporterMenuRemoved=$EXPORTER_MENU_REMOVED" "ExporterFilesRemoved=$EXPORTER_FILES_REMOVED" 'RetryPolicy=disabled' 'Recovery=normal boot restored; rerun the Windows base installer only after resolving the prerequisite' > "$MARKER"
  recovery_reboot
fi

touch "$AUTOFLAG"
if ! ps | grep '[e]xport_worker.sh' >/dev/null 2>&1; then
  /bin/sh "$WORKER" >/dev/null 2>&1 &
  log "WORKER_STARTED pid=$!"
else
  log "WORKER_ALREADY_RUNNING"
fi

log "UI_START"
"$REAL_RA" --config "$RA_CFG" --verbose -L "$CORE" "$CONTENT" >> "$EXPORT_LOG" 2>&1
UIRC=$?
log "UI_STOP rc=$UIRC"

if [ -f "$ROOT/EXPORT_COMPLETE.txt" ]; then
  log "EXPORT_COMPLETE_CONFIRMED"
  restore_environment
  wait_worker_exit
  remove_exporter_verified || true
  restore_retroarch
  write_complete_marker
  power_down
fi

log "EXPORT_FAILED_OR_INCOMPLETE ui_rc=$UIRC"
restore_environment
wait_worker_exit
remove_exporter_verified || true
restore_retroarch
printf '%s\n' 'Project Eris ++ 1.0.18 automatic internal export' 'Mode=FAILED_OR_INCOMPLETE_PERMANENTLY_CLEANED' "ExporterMenuRemoved=$EXPORTER_MENU_REMOVED" "ExporterFilesRemoved=$EXPORTER_FILES_REMOVED" 'RetryPolicy=disabled' 'Recovery=normal boot restored; exporter permanently removed' > "$MARKER"
recovery_reboot
