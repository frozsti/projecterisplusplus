@echo off
setlocal
cd /d "%~dp0"
echo Project Eris ++ v1.0.21 - in-process achievement audio bridge test
powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0windows\Validate-PowerShell.ps1" "%~dp0windows\ProjectErisPlusPlus.TestAudio.ps1"
if errorlevel 1 (
  echo.
  echo Test stopped: PowerShell parser validation failed.
  pause
  exit /b 10
)
powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0windows\ProjectErisPlusPlus.TestAudio.ps1"
pause
