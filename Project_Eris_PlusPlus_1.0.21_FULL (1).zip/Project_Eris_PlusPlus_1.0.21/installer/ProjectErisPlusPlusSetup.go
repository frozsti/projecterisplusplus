//go:build windows

package main

import (
    "archive/zip"
    "bytes"
    "embed"
    "fmt"
    "io"
    "os"
    "os/exec"
    "path/filepath"
    "strings"
    "syscall"
    "unsafe"
)

const version = "1.0.21"
const product = "Project Eris ++"

//go:embed payload.zip
var payloadFS embed.FS

var (
    user32         = syscall.NewLazyDLL("user32.dll")
    procMessageBox = user32.NewProc("MessageBoxW")
)

const (
    mbOK              = 0x00000000
    mbYesNo           = 0x00000004
    mbIconInfo        = 0x00000040
    mbIconQuestion    = 0x00000020
    mbIconError       = 0x00000010
    mbSetForeground   = 0x00010000
    idYes             = 6
)

func utf16Ptr(s string) *uint16 {
    p, _ := syscall.UTF16PtrFromString(s)
    return p
}

func msg(title, text string, flags uintptr) int {
    r, _, _ := procMessageBox.Call(0, uintptr(unsafe.Pointer(utf16Ptr(text))), uintptr(unsafe.Pointer(utf16Ptr(title))), flags|mbSetForeground)
    return int(r)
}

func fatalf(format string, args ...any) {
    msg(product+" Setup", fmt.Sprintf(format, args...), mbOK|mbIconError)
    os.Exit(1)
}

func installDir() string {
    base := os.Getenv("LOCALAPPDATA")
    if base == "" {
        if p, err := os.UserConfigDir(); err == nil { base = p }
    }
    return filepath.Join(base, "Programs", "Project Eris PlusPlus")
}

func safeExtractZip(data []byte, dest string) error {
    zr, err := zip.NewReader(bytes.NewReader(data), int64(len(data)))
    if err != nil { return err }
    cleanDest, err := filepath.Abs(dest)
    if err != nil { return err }
    for _, f := range zr.File {
        name := filepath.Clean(filepath.FromSlash(f.Name))
        if name == "." || filepath.IsAbs(name) || strings.HasPrefix(name, ".."+string(os.PathSeparator)) || name == ".." {
            return fmt.Errorf("unsafe payload path: %s", f.Name)
        }
        target := filepath.Join(cleanDest, name)
        absTarget, err := filepath.Abs(target)
        if err != nil { return err }
        if absTarget != cleanDest && !strings.HasPrefix(strings.ToLower(absTarget), strings.ToLower(cleanDest)+string(os.PathSeparator)) {
            return fmt.Errorf("payload path escaped install directory: %s", f.Name)
        }
        if f.FileInfo().IsDir() {
            if err := os.MkdirAll(target, 0755); err != nil { return err }
            continue
        }
        if err := os.MkdirAll(filepath.Dir(target), 0755); err != nil { return err }
        rc, err := f.Open(); if err != nil { return err }
        out, err := os.OpenFile(target, os.O_CREATE|os.O_TRUNC|os.O_WRONLY, 0644)
        if err != nil { rc.Close(); return err }
        _, cpErr := io.Copy(out, rc)
        closeErr := out.Close(); rc.Close()
        if cpErr != nil { return cpErr }
        if closeErr != nil { return closeErr }
    }
    return nil
}

func psQuote(s string) string { return strings.ReplaceAll(s, "'", "''") }

func createShortcuts(dir string) error {
    wizard := filepath.Join(dir, "windows", "ProjectErisPlusPlus.SimpleWizard.ps1")
    icon := filepath.Join(dir, "assets", "projecterispp.ico")
    readme := filepath.Join(dir, "README_SETUP_EN.txt")
    uninstaller := filepath.Join(dir, "Uninstall Project Eris PlusPlus.exe")
    script := fmt.Sprintf(`
$ErrorActionPreference='Stop'
$ws=New-Object -ComObject WScript.Shell
$desk=[Environment]::GetFolderPath('Desktop')
$start=Join-Path $env:APPDATA 'Microsoft\Windows\Start Menu\Programs\Project Eris ++'
New-Item -ItemType Directory -Force -Path $start|Out-Null
function Make-Link([string]$path,[string]$target,[string]$args,[string]$work,[string]$desc,[string]$icon){$s=$ws.CreateShortcut($path);$s.TargetPath=$target;$s.Arguments=$args;$s.WorkingDirectory=$work;$s.Description=$desc;if($icon -and (Test-Path $icon)){$s.IconLocation=$icon};$s.Save()}
foreach($old in @((Join-Path $desk 'Project Eris ++ Wizard.lnk'),(Join-Path $desk 'Project Eris ++ Reset Lab.lnk'))){Remove-Item $old -Force -ErrorAction SilentlyContinue}
$wiz='%s';$ico='%s';$read='%s';$un='%s'
$args='-NoLogo -NoProfile -ExecutionPolicy Bypass -File "'+$wiz+'"'
Make-Link (Join-Path $desk 'Project Eris ++.lnk') 'powershell.exe' $args (Split-Path $wiz -Parent) 'Project Eris ++' $ico
Make-Link (Join-Path $start 'Project Eris ++.lnk') 'powershell.exe' $args (Split-Path $wiz -Parent) 'Project Eris ++' $ico
Make-Link (Join-Path $start 'Project Eris ++ - Setup Guide.lnk') 'notepad.exe' ('"'+$read+'"') (Split-Path $read -Parent) 'Project Eris ++ setup guide' $ico
Make-Link (Join-Path $start 'Uninstall Project Eris ++.lnk') $un '--uninstall' (Split-Path $un -Parent) 'Uninstall Project Eris ++' $ico
`, psQuote(wizard), psQuote(icon), psQuote(readme), psQuote(uninstaller))
    cmd := exec.Command("powershell.exe", "-NoLogo", "-NoProfile", "-ExecutionPolicy", "Bypass", "-Command", script)
    return cmd.Run()
}

func removeShortcuts() {
    script := `
$desk=[Environment]::GetFolderPath('Desktop')
foreach($n in @('Project Eris ++.lnk','Project Eris ++ Wizard.lnk','Project Eris ++ Reset Lab.lnk')){Remove-Item (Join-Path $desk $n) -Force -ErrorAction SilentlyContinue}
Remove-Item (Join-Path $env:APPDATA 'Microsoft\Windows\Start Menu\Programs\Project Eris ++') -Recurse -Force -ErrorAction SilentlyContinue
`
    _ = exec.Command("powershell.exe", "-NoLogo", "-NoProfile", "-ExecutionPolicy", "Bypass", "-Command", script).Run()
}

func copySelf(dest string) error {
    src, err := os.Executable(); if err != nil { return err }
    in, err := os.Open(src); if err != nil { return err }; defer in.Close()
    out, err := os.OpenFile(dest, os.O_CREATE|os.O_TRUNC|os.O_WRONLY, 0755); if err != nil { return err }
    _, err = io.Copy(out, in); cerr := out.Close(); if err != nil { return err }; return cerr
}

func launchWizard(dir string) {
    wizard := filepath.Join(dir, "windows", "ProjectErisPlusPlus.SimpleWizard.ps1")
    _ = exec.Command("powershell.exe", "-NoLogo", "-NoProfile", "-ExecutionPolicy", "Bypass", "-File", wizard).Start()
}

func doInstall(silent bool) {
    if !silent {
        text := "Project Eris ++ 1.0.21 will be installed for the current Windows user.\r\n\r\n" +
            "Install location:\r\n%LOCALAPPDATA%\\Programs\\Project Eris PlusPlus\r\n\r\n" +
            "Desktop and Start Menu shortcuts will be created. After setup, the simple USB wizard installs Project Eris ++ and offers three game workflows. Existing Project Eris ++ user data will be preserved.\r\n\r\nContinue?"
        if msg(product+" Setup", text, mbYesNo|mbIconQuestion) != idYes { return }
    }
    dir := installDir()
    if dir == "" { fatalf("LOCALAPPDATA could not be determined.") }
    if err := os.RemoveAll(dir); err != nil { fatalf("The previous program folder could not be removed:\r\n%v", err) }
    if err := os.MkdirAll(dir, 0755); err != nil { fatalf("The installation folder could not be created:\r\n%v", err) }
    data, err := payloadFS.ReadFile("payload.zip"); if err != nil { fatalf("The embedded installer payload is missing:\r\n%v", err) }
    if err := safeExtractZip(data, dir); err != nil { fatalf("The application files could not be installed:\r\n%v", err) }
    if err := os.WriteFile(filepath.Join(dir, "INSTALLED_VERSION.txt"), []byte("Project Eris ++ "+version+"\r\n"), 0644); err != nil { fatalf("The version marker could not be written:\r\n%v", err) }
    if err := copySelf(filepath.Join(dir, "Uninstall Project Eris PlusPlus.exe")); err != nil { fatalf("The uninstaller could not be installed:\r\n%v", err) }
    if err := createShortcuts(dir); err != nil { fatalf("The shortcuts could not be created:\r\n%v", err) }
    if silent { return }
    text := "Project Eris ++ 1.0.21 has been installed.\r\n\r\n" +
        "The simple USB wizard is ready. Start with a working Project Eris USB drive. After USB installation you can install one game, install a game folder, or use the current USB library.\r\n\r\nStart Project Eris ++ now?"
    if msg(product+" Setup", text, mbYesNo|mbIconInfo) == idYes { launchWizard(dir) }
}

func doUninstall() {
    if msg(product+" Uninstall", "Remove Project Eris ++?\r\n\r\nThe application files and shortcuts will be removed. Your local Project Eris ++ cache/profile data under %LOCALAPPDATA%\\ProjectErisPlusPlus will be preserved.", mbYesNo|mbIconQuestion) != idYes { return }
    dir := installDir(); removeShortcuts()
    msg(product+" Uninstall", "Project Eris ++ will now be removed. Local user data will be preserved.", mbOK|mbIconInfo)
    // A running EXE cannot delete itself. Schedule removal after this process exits.
    cmdline := fmt.Sprintf(`ping 127.0.0.1 -n 3 >nul & rmdir /s /q "%s"`, dir)
    _ = exec.Command("cmd.exe", "/C", cmdline).Start()
}

func main() {
    uninstall := false; silent := false
    for _, a := range os.Args[1:] {
        if strings.EqualFold(a, "--uninstall") { uninstall = true }
        if strings.EqualFold(a, "--silent") { silent = true }
    }
    if uninstall { doUninstall(); return }
    doInstall(silent)
}
