﻿$ErrorActionPreference='Stop'
$root=Split-Path -Parent $PSScriptRoot
$stage=Join-Path $env:TEMP ('erispp_installer_'+[guid]::NewGuid().ToString('N'))
$payload=Join-Path $PSScriptRoot 'payload.zip'
try {
  New-Item -ItemType Directory -Force -Path $stage|Out-Null
  Get-ChildItem $root -Force | Where-Object { $_.Name -notin @('installer','.git','Project_Eris_PlusPlus_Setup_v1.0.21.exe') } | ForEach-Object { Copy-Item $_.FullName $stage -Recurse -Force }
  if(Test-Path $payload){Remove-Item $payload -Force}
  Compress-Archive -Path (Join-Path $stage '*') -DestinationPath $payload -CompressionLevel Optimal
  Push-Location $PSScriptRoot
  try { go build -trimpath -ldflags '-H windowsgui -s -w' -o (Join-Path $root 'Project_Eris_PlusPlus_Setup_v1.0.21.exe') .\ProjectErisPlusPlusSetup.go }
  finally { Pop-Location }
  Write-Host 'Built Project_Eris_PlusPlus_Setup_v1.0.21.exe' -ForegroundColor Green
} finally {
  Remove-Item $stage -Recurse -Force -ErrorAction SilentlyContinue
  Remove-Item $payload -Force -ErrorAction SilentlyContinue
}
