Project Eris ++ Windows installer source
========================================
The release Setup EXE is built from ProjectErisPlusPlusSetup.go with Go.
It embeds a ZIP of the application files, installs per-user, creates Desktop/Start Menu shortcuts
and supplies an uninstaller. It deliberately preserves %LOCALAPPDATA%\ProjectErisPlusPlus user data.

To rebuild on Windows:
1. Install Go.
2. Run installer\Build-Installer.ps1 from a PowerShell prompt.

The release EXE is currently unsigned. Code-signing can be added later to the release workflow.
