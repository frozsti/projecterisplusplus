/* Project Eris ++ v1.0.10 in-process RetroArch ALSA bridge.
 * Loaded with LD_PRELOAD into RetroArch. It intercepts ALSA PCM writes and
 * mixes a short achievement chime into the already-open game audio stream.
 * No second ALSA client, no dmix, no RetroArch DSP plugin.
 */
typedef long ssize_t;
typedef long off_t;
typedef unsigned long size_t;
typedef unsigned long snd_pcm_uframes_t;
typedef long snd_pcm_sframes_t;
typedef struct _snd_pcm snd_pcm_t;

extern void *dlsym(void *handle, const char *name);
extern int open(const char *path, int flags, ...);
extern int close(int fd);
extern int unlink(const char *path);
extern off_t lseek(int fd, off_t off, int whence);
extern ssize_t write(int fd, const void *buf, size_t count);

#define RTLD_NEXT ((void *)-1L)
#define O_RDONLY 0
#define O_WRONLY 1
#define O_CREAT 64
#define O_APPEND 1024
#define SEEK_END 2
#define MAX_FRAMES 65536UL
#define CHIME_FRAMES 16800UL

static short scratch[MAX_FRAMES * 2UL];
static unsigned long chime_pos = CHIME_FRAMES;
static unsigned int phase = 0;
static long history_size = -1;
static int write_hook_logged = 0;
static int mmap_hook_logged = 0;
static int resolve_error_logged = 0;
static int recurse_guard = 0;

static const char *ROOT = "/media/project_eris/etc/project_eris/etc/erispp";
static const char *LOG = "/media/PROJECT_ERIS_PP_AUDIO_BRIDGE.log";
static const char *TEST_FLAG = "/media/project_eris/etc/project_eris/etc/erispp/runtime/TEST_AUDIO_BRIDGE.flag";
static const char *PLAY_FLAG = "/media/project_eris/etc/project_eris/etc/erispp/runtime/PLAY_CHIME.flag";
static const char *HISTORY = "/media/project_eris/etc/project_eris/etc/erispp/profiles/active/history.tsv";

static size_t slen(const char *s){size_t n=0; while(s && s[n]) n++; return n;}
static void log_line(const char *s){
    int fd=open(LOG,O_WRONLY|O_CREAT|O_APPEND,0644);
    if(fd>=0){write(fd,s,slen(s));write(fd,"\n",1);close(fd);}
}
__attribute__((constructor)) static void erispp_bridge_load(void){
    log_line("ERISPP_BRIDGE_110 LOAD_OK");
}
static int consume_flag(const char *path){
    int fd=open(path,O_RDONLY);
    if(fd<0) return 0;
    close(fd); unlink(path); return 1;
}
static long file_size(const char *path){
    int fd=open(path,O_RDONLY); off_t p;
    if(fd<0) return -1;
    p=lseek(fd,0,SEEK_END); close(fd); return (long)p;
}
static void start_chime(const char *why){
    chime_pos=0; phase=0; log_line(why);
}
static void poll_trigger(void){
    long hs;
    if(consume_flag(TEST_FLAG)) start_chime("ERISPP_BRIDGE_110 TEST_SOUND_TRIGGER");
    if(consume_flag(PLAY_FLAG)) start_chime("ERISPP_BRIDGE_110 UNLOCK_SOUND_TRIGGER flag");
    hs=file_size(HISTORY);
    if(hs>=0){
        if(history_size<0) history_size=hs;
        else if(hs>history_size){history_size=hs; start_chime("ERISPP_BRIDGE_110 UNLOCK_SOUND_TRIGGER history");}
        else if(hs<history_size) history_size=hs;
    }
}
static int sat16(int v){if(v>32767)return 32767;if(v<-32768)return -32768;return v;}
static int tri(unsigned int p){
    unsigned int x=(p>>16)&0xffffU;
    if(x<32768U) return ((int)x*2)-32768;
    return 98303-((int)x*2);
}
static const void *mix_buffer(const void *buffer, snd_pcm_uframes_t frames){
    const short *in=(const short*)buffer; unsigned long i; int tone,env,amp,mix;
    if(!buffer || frames==0 || frames>MAX_FRAMES) return buffer;
    for(i=0;i<frames*2UL;i++) scratch[i]=in[i];
    if(chime_pos>=CHIME_FRAMES) return scratch;
    for(i=0;i<frames && chime_pos<CHIME_FRAMES;i++,chime_pos++){
        unsigned int inc;
        if(chime_pos<5600UL) inc=1201493U;       /* ~880 Hz @ 48 kHz */
        else if(chime_pos<11200UL) inc=1638400U; /* ~1200 Hz */
        else inc=1966080U;                       /* ~1440 Hz */
        phase+=inc;
        tone=tri(phase);
        if(chime_pos<720UL) env=(int)(chime_pos*18UL);
        else env=(int)(((CHIME_FRAMES-chime_pos)*12800UL)/CHIME_FRAMES);
        if(env>12800) env=12800;
        amp=(tone*env)>>15;
        mix=scratch[i*2UL]+amp; scratch[i*2UL]=(short)sat16(mix);
        mix=scratch[i*2UL+1UL]+amp; scratch[i*2UL+1UL]=(short)sat16(mix);
    }
    return scratch;
}

typedef snd_pcm_sframes_t (*writei_fn)(snd_pcm_t*,const void*,snd_pcm_uframes_t);
static writei_fn real_writei=0;
static writei_fn real_mmap_writei=0;

__attribute__((visibility("default")))
snd_pcm_sframes_t snd_pcm_writei(snd_pcm_t *pcm,const void *buffer,snd_pcm_uframes_t frames){
    const void *out;
    if(!real_writei) real_writei=(writei_fn)dlsym(RTLD_NEXT,"snd_pcm_writei");
    if(!real_writei){if(!resolve_error_logged){resolve_error_logged=1;log_line("ERISPP_BRIDGE_110 RESOLVE_FAIL snd_pcm_writei");}return -1;}
    if(recurse_guard) return real_writei(pcm,buffer,frames);
    recurse_guard=1;
    if(!write_hook_logged){write_hook_logged=1;log_line("ERISPP_BRIDGE_110 WRITE_HOOK_OK method=snd_pcm_writei");history_size=file_size(HISTORY);}
    poll_trigger(); out=mix_buffer(buffer,frames);
    {snd_pcm_sframes_t r=real_writei(pcm,out,frames);recurse_guard=0;return r;}
}

__attribute__((visibility("default")))
snd_pcm_sframes_t snd_pcm_mmap_writei(snd_pcm_t *pcm,const void *buffer,snd_pcm_uframes_t frames){
    const void *out;
    if(!real_mmap_writei) real_mmap_writei=(writei_fn)dlsym(RTLD_NEXT,"snd_pcm_mmap_writei");
    if(!real_mmap_writei){if(!resolve_error_logged){resolve_error_logged=1;log_line("ERISPP_BRIDGE_110 RESOLVE_FAIL snd_pcm_mmap_writei");}return -1;}
    if(recurse_guard) return real_mmap_writei(pcm,buffer,frames);
    recurse_guard=1;
    if(!mmap_hook_logged){mmap_hook_logged=1;log_line("ERISPP_BRIDGE_110 WRITE_HOOK_OK method=snd_pcm_mmap_writei");history_size=file_size(HISTORY);}
    poll_trigger(); out=mix_buffer(buffer,frames);
    {snd_pcm_sframes_t r=real_mmap_writei(pcm,out,frames);recurse_guard=0;return r;}
}
