/*
 * Project Eris ++ Trophy Room v2.6.3 - PlayStation Classic libretro core
 * Dependency-free ARM/Linux userspace. Reads catalog generated on Windows,
 * and permanent unlock state directly from the Project Eris ++ achievement runtime.
 */
typedef unsigned char u8; typedef unsigned short u16; typedef unsigned int u32; typedef int s32; typedef unsigned long usize;


/* ARM EABI integer division helpers for the freestanding static build. */
static u32 udiv32(u32 n,u32 d){u32 q=0,bit=1;if(!d)return 0xffffffffu;while((d&0x80000000u)==0 && d<n && bit && (d<<1)>d){d<<=1;bit<<=1;}while(bit){if(n>=d){n-=d;q|=bit;}d>>=1;bit>>=1;}return q;}
u32 __aeabi_uidiv(u32 n,u32 d){return udiv32(n,d);}
s32 __aeabi_idiv(s32 n,s32 d){int neg=0;u32 un,ud,q;if(!d)return n>=0?0x7fffffff:(s32)0x80000000u;if(n<0){neg^=1;un=(u32)(-(n+1))+1;}else un=(u32)n;if(d<0){neg^=1;ud=(u32)(-(d+1))+1;}else ud=(u32)d;q=udiv32(un,ud);return neg?-(s32)q:(s32)q;}
static s32 imod32(s32 n,s32 d){s32 q=__aeabi_idiv(n,d);return n-q*d;}
static u32 umod32(u32 n,u32 d){u32 q=__aeabi_uidiv(n,d);return n-q*d;}

#define SYS_EXIT 1
#define SYS_READ 3
#define SYS_WRITE 4
#define SYS_OPEN 5
#define SYS_CLOSE 6
#define SYS_LSEEK 19
#define SYS_IOCTL 54
#define SYS_MMAP2 192
#define SYS_MUNMAP 91
#define SYS_POLL 168
#define SYS_NANOSLEEP 162

#define O_RDONLY 0
#define O_WRONLY 1
#define O_CREAT 0100
#define O_RDWR 2
#define O_APPEND 02000
#define O_NONBLOCK 04000
#define SEEK_SET 0
#define PROT_READ 1
#define PROT_WRITE 2
#define MAP_SHARED 1
#define MAP_FAILED ((void*)-1)

static long sc0(long n){register long r7 asm("r7")=n;register long r0 asm("r0");asm volatile("svc 0":"=r"(r0):"r"(r7):"memory");return r0;}
static long sc1(long n,long a){register long r7 asm("r7")=n;register long r0 asm("r0")=a;asm volatile("svc 0":"+r"(r0):"r"(r7):"memory");return r0;}
static long sc2(long n,long a,long b){register long r7 asm("r7")=n;register long r0 asm("r0")=a;register long r1 asm("r1")=b;asm volatile("svc 0":"+r"(r0):"r"(r1),"r"(r7):"memory");return r0;}
static long sc3(long n,long a,long b,long c){register long r7 asm("r7")=n;register long r0 asm("r0")=a;register long r1 asm("r1")=b;register long r2 asm("r2")=c;asm volatile("svc 0":"+r"(r0):"r"(r1),"r"(r2),"r"(r7):"memory");return r0;}
static long sc6(long n,long a,long b,long c,long d,long e,long f){register long r7 asm("r7")=n;register long r0 asm("r0")=a;register long r1 asm("r1")=b;register long r2 asm("r2")=c;register long r3 asm("r3")=d;register long r4 asm("r4")=e;register long r5 asm("r5")=f;asm volatile("svc 0":"+r"(r0):"r"(r1),"r"(r2),"r"(r3),"r"(r4),"r"(r5),"r"(r7):"memory");return r0;}
static int openf(const char*p,int f){return (int)sc3(SYS_OPEN,(long)p,f,0);}
static int closef(int fd){return (int)sc1(SYS_CLOSE,fd);}
static int readf(int fd,void*b,int n){return (int)sc3(SYS_READ,fd,(long)b,n);}
static int writef(int fd,const void*b,int n){return (int)sc3(SYS_WRITE,fd,(long)b,n);}
static int seekf(int fd,int off,int wh){return (int)sc3(SYS_LSEEK,fd,off,wh);}
static int ioctl3(int fd,u32 req,void*p){return (int)sc3(SYS_IOCTL,fd,req,(long)p);}
static void sleep_ms(int ms){struct {u32 sec,nsec;} t; t.sec=(u32)(ms/1000);t.nsec=(u32)imod32(ms,1000)*1000000u;sc2(SYS_NANOSLEEP,(long)&t,0);}

static int slen(const char*s){int n=0;if(!s)return 0;while(s[n])n++;return n;}
static void scpy(char*d,const char*s,int max){int i=0;if(max<1)return;while(s&&s[i]&&i<max-1){d[i]=s[i];i++;}d[i]=0;}
static int seq(const char*a,const char*b){int i=0;if(!a||!b)return 0;while(a[i]&&b[i]&&a[i]==b[i])i++;return a[i]==0&&b[i]==0;}
static int atoi10(const char*s){int n=0,sign=1;if(!s)return 0;if(*s=='-'){sign=-1;s++;}while(*s>='0'&&*s<='9'){n=n*10+(*s-'0');s++;}return n*sign;}
static char upper(char c){if(c>='a'&&c<='z')return c-32;return c;}
static int contains_ci(const char*s,const char*q){int i,j;if(!q||!*q)return 1;for(i=0;s&&s[i];i++){for(j=0;q[j]&&s[i+j]&&upper(s[i+j])==upper(q[j]);j++);if(!q[j])return 1;}return 0;}
static void sanitize(char*s){int i;for(i=0;s&&s[i];i++){unsigned char c=(unsigned char)s[i];if(c<32)s[i]=' ';if(c>=128)s[i]='?';}}
static int file_exists(const char*p){int fd=openf(p,O_RDONLY);if(fd<0)return 0;closef(fd);return 1;}


#define VIDEO_W 1280
#define VIDEO_H 720
static int SW=1280,SH=720;
static u16 video_buf[VIDEO_W*VIDEO_H];
static u32 rgb(u8 r,u8 g,u8 b){return (u32)(((u16)(r>>3)<<11)|((u16)(g>>2)<<5)|((u16)(b>>3)));}
static void px(int x,int y,u32 c){
    if(x<0||y<0||x>=VIDEO_W||y>=VIDEO_H)return;
    video_buf[y*VIDEO_W+x]=(u16)c;
}
static void rect(int x,int y,int w,int h,u32 c){
    int yy,xx,x2,y2;
    if(x<0){w+=x;x=0;} if(y<0){h+=y;y=0;}
    if(x>=VIDEO_W||y>=VIDEO_H||w<=0||h<=0)return;
    x2=x+w; y2=y+h;
    if(x2>VIDEO_W)x2=VIDEO_W; if(y2>VIDEO_H)y2=VIDEO_H;
    for(yy=y;yy<y2;yy++){
        u16 *row=&video_buf[yy*VIDEO_W];
        for(xx=x;xx<x2;xx++)row[xx]=(u16)c;
    }
}
static void line(int x0,int y0,int x1,int y1,u32 c){int dx=x1>x0?x1-x0:x0-x1,sx=x0<x1?1:-1,dy=y1>y0?y0-y1:y1-y0,sy=y0<y1?1:-1,e=dx+dy,e2;for(;;){px(x0,y0,c);if(x0==x1&&y0==y1)break;e2=2*e;if(e2>=dy){e+=dy;x0+=sx;}if(e2<=dx){e+=dx;y0+=sy;}}}

/* Compact 5x7 glyphs; lower-case is rendered as upper-case for legibility. */
static const u8 GLYPH_AZ[26][7]={
{14,17,17,31,17,17,17},{30,17,17,30,17,17,30},{14,17,16,16,16,17,14},{30,17,17,17,17,17,30},{31,16,16,30,16,16,31},{31,16,16,30,16,16,16},{14,17,16,23,17,17,15},{17,17,17,31,17,17,17},{14,4,4,4,4,4,14},{7,2,2,2,2,18,12},{17,18,20,24,20,18,17},{16,16,16,16,16,16,31},{17,27,21,21,17,17,17},{17,25,21,19,17,17,17},{14,17,17,17,17,17,14},{30,17,17,30,16,16,16},{14,17,17,17,21,18,13},{30,17,17,30,20,18,17},{15,16,16,14,1,1,30},{31,4,4,4,4,4,4},{17,17,17,17,17,17,14},{17,17,17,17,17,10,4},{17,17,17,21,21,21,10},{17,17,10,4,10,17,17},{17,17,10,4,4,4,4},{31,1,2,4,8,16,31}};
static const u8 GLYPH_NUM[10][7]={
{14,17,19,21,25,17,14},{4,12,4,4,4,4,14},{14,17,1,2,4,8,31},{30,1,1,14,1,1,30},{2,6,10,18,31,2,2},{31,16,16,30,1,1,30},{14,16,16,30,17,17,14},{31,1,2,4,8,8,8},{14,17,17,14,17,17,14},{14,17,17,15,1,1,14}};
static void glyph(char ch,u8 out[7]){int i;for(i=0;i<7;i++)out[i]=0;ch=upper(ch);if(ch>='A'&&ch<='Z'){for(i=0;i<7;i++)out[i]=GLYPH_AZ[ch-'A'][i];return;}if(ch>='0'&&ch<='9'){for(i=0;i<7;i++)out[i]=GLYPH_NUM[ch-'0'][i];return;}switch(ch){case '.':out[6]=4;break;case ':':out[2]=4;out[5]=4;break;case '-':out[3]=14;break;case '+':out[1]=4;out[2]=4;out[3]=31;out[4]=4;out[5]=4;break;case '/':out[0]=1;out[1]=2;out[2]=2;out[3]=4;out[4]=8;out[5]=8;out[6]=16;break;case '%':out[0]=17;out[1]=2;out[2]=4;out[3]=4;out[4]=8;out[5]=16;out[6]=17;break;case '[':out[0]=14;out[1]=8;out[2]=8;out[3]=8;out[4]=8;out[5]=8;out[6]=14;break;case ']':out[0]=14;out[1]=2;out[2]=2;out[3]=2;out[4]=2;out[5]=2;out[6]=14;break;case '(':out[0]=2;out[1]=4;out[2]=8;out[3]=8;out[4]=8;out[5]=4;out[6]=2;break;case ')':out[0]=8;out[1]=4;out[2]=2;out[3]=2;out[4]=2;out[5]=4;out[6]=8;break;case '!':out[0]=4;out[1]=4;out[2]=4;out[3]=4;out[4]=4;out[6]=4;break;case '?':out[0]=14;out[1]=17;out[2]=1;out[3]=2;out[4]=4;out[6]=4;break;case '=':out[2]=14;out[4]=14;break;case '_':out[6]=31;break;case '#':out[1]=10;out[2]=31;out[3]=10;out[4]=31;out[5]=10;break;case '*':out[1]=21;out[2]=14;out[3]=31;out[4]=14;out[5]=21;break;default:break;}}
static void text(int x,int y,const char*s,int sc,u32 c,int max){int n=0,row,col,xx=x;u8 g[7];while(s&&*s&&n<max){char ch=*s++;if(ch=='\n'){y+=8*sc;xx=x;n++;continue;}glyph(ch,g);for(row=0;row<7;row++)for(col=0;col<5;col++)if(g[row]&(1<<(4-col)))rect(xx+col*sc,y+row*sc,sc,sc,c);xx+=6*sc;n++;}}
static void number(char*b,int n){char t[16];int i=0,j=0,q,r;if(n==0){b[0]='0';b[1]=0;return;}if(n<0){b[j++]='-';n=-n;}while(n&&i<15){q=__aeabi_idiv(n,10);r=n-q*10;t[i++]=(char)('0'+r);n=q;}while(i)b[j++]=t[--i];b[j]=0;}

static u32 C_BG,C_PANEL,C_PANEL2,C_ICE,C_PURPLE,C_PINK,C_TEXT,C_MUTED,C_GREEN,C_RED,C_LINE,C_GOLD;
static void colors(void){C_BG=rgb(7,11,25);C_PANEL=rgb(14,22,43);C_PANEL2=rgb(20,31,58);C_ICE=rgb(142,233,255);C_PURPLE=rgb(183,140,255);C_PINK=rgb(255,136,214);C_TEXT=rgb(238,247,255);C_MUTED=rgb(137,160,188);C_GREEN=rgb(143,255,199);C_RED=rgb(255,116,130);C_LINE=rgb(38,52,82);C_GOLD=rgb(255,215,110);}
static void snowflake(int cx,int cy,int r,u32 c){line(cx-r,cy,cx+r,cy,c);line(cx,cy-r,cx,cy+r,c);line(cx-r*3/4,cy-r*3/4,cx+r*3/4,cy+r*3/4,c);line(cx+r*3/4,cy-r*3/4,cx-r*3/4,cy+r*3/4,c);}
static void progress(int x,int y,int w,int h,int a,int b){int fill=0;rect(x,y,w,h,C_LINE);rect(x+2,y+2,w-4,h-4,C_BG);if(b>0)fill=(w-4)*a/b;if(fill<0)fill=0;if(fill>w-4)fill=w-4;rect(x+2,y+2,fill,h-4,C_ICE);}

#define MAX_GAMES 256
#define MAX_ACH 512
struct Game{int gid,total,unlocked;char title[80];char status[20];};
struct Ach{int id,points;char title[76],desc[180],badge[128],locked[128];};
static struct Game games[MAX_GAMES];static int ngames=0;
static struct Ach achs[MAX_ACH];static int nach=0;
static char filebuf[262144];
static char statebuf[65536];
static int cur_unlocked[1024],ncur_unlocked=0,cur_gid=-1;
static const char*BASE="/media/project_eris/etc/project_eris/etc/erispp/ui";
static const char*STATE="/media/project_eris/etc/project_eris/etc/erispp/state";
static const char*DB="/media/project_eris/etc/project_eris/etc/erispp/database";
static const char*PROFILE="/media/project_eris/etc/project_eris/etc/erispp/profiles/active/profile.tsv";
static const char*PROFILE_AVATAR="/media/project_eris/etc/project_eris/etc/erispp/profiles/active/avatar.bmp";
static const char*PLAYED="/media/project_eris/etc/project_eris/etc/erispp/profiles/active/played.tsv";
static char profile_name[40]="PLAYER";
static char profilebuf[1024];


static int readall(const char*p,char*b,int max){int fd,n,total=0;fd=openf(p,O_RDONLY);if(fd<0)return -1;while(total<max-1&&(n=readf(fd,b+total,max-1-total))>0)total+=n;closef(fd);b[total]=0;return total;}
static char*field(char**p){char*s=*p,*q=s;if(!s)return 0;while(*q&&*q!='\t'&&*q!='\n'&&*q!='\r')q++;if(*q){*q=0;q++;while(*q=='\n'||*q=='\r')q++;}*p=q;return s;}
static void mkpath2(char*out,const char*a,int n,const char*suf){char num[16];int k=0,i;number(num,n);for(i=0;a[i]&&k<250;i++)out[k++]=a[i];for(i=0;num[i]&&k<250;i++)out[k++]=num[i];for(i=0;suf[i]&&k<250;i++)out[k++]=suf[i];out[k]=0;}

static void load_profile(void){
    char*p,*ln,*q,*f;int n;
    scpy(profile_name,"PLAYER",40);
    n=readall(PROFILE,profilebuf,sizeof(profilebuf));
    if(n<0)return;
    p=profilebuf;
    while(*p){
        ln=p;
        while(*p&&*p!='\n'&&*p!='\r')p++;
        if(*p){*p++=0;while(*p=='\n'||*p=='\r')p++;}
        q=ln;f=field(&q);
        if(f&&(seq(f,"display")||seq(f,"name"))){
            f=field(&q);
            if(f&&*f){scpy(profile_name,f,40);sanitize(profile_name);}
            if(seq(ln,"display"))return;
        }
    }
}

static int played_gid(int gid){char*p;int n,v;n=readall(PLAYED,statebuf,sizeof(statebuf));if(n<0)return 0;p=statebuf;while(*p){while(*p=='\r'||*p=='\n')p++;if(!*p)break;v=atoi10(p);if(v==gid)return 1;while(*p&&*p!='\n'&&*p!='\r')p++;}return 0;}
static int played_name(const char*name){char*p,*ln,*q,*f;int n;if(!name||!*name)return 0;n=readall(PLAYED,statebuf,sizeof(statebuf));if(n<0)return 0;p=statebuf;while(*p){while(*p=='\r'||*p=='\n')p++;if(!*p)break;ln=p;while(*p&&*p!='\n'&&*p!='\r')p++;if(*p){*p++=0;while(*p=='\n'||*p=='\r')p++;}q=ln;f=field(&q);f=field(&q);f=field(&q);if(f&&seq(f,name))return 1;}return 0;}
static int game_gid_loaded(int gid,int count){int i;for(i=0;i<count;i++)if(games[i].gid==gid)return 1;return 0;}
static int title_cmp_ci(const char*a,const char*b){int i=0;char ca,cb;while(a&&b&&a[i]&&b[i]){ca=upper(a[i]);cb=upper(b[i]);if(ca<cb)return -1;if(ca>cb)return 1;i++;}if(!a||!a[i])return (!b||!b[i])?0:-1;return 1;}
static void copy_game(struct Game*d,const struct Game*s){int i;d->gid=s->gid;d->total=s->total;d->unlocked=s->unlocked;for(i=0;i<80;i++)d->title[i]=s->title[i];for(i=0;i<20;i++)d->status[i]=s->status[i];}
static void sort_games_alpha(int count){int i,j;struct Game tmp;for(i=1;i<count;i++){copy_game(&tmp,&games[i]);j=i-1;while(j>=0&&title_cmp_ci(games[j].title,tmp.title)>0){copy_game(&games[j+1],&games[j]);j--;}copy_game(&games[j+1],&tmp);}}
static int ach_id_loaded(int aid,int count){int i;for(i=0;i<count;i++)if(achs[i].id==aid)return 1;return 0;}
static int load_games(void){load_profile();char path[256],*p,*ln,*q,*f,*src;int n,i=0,gid,total;char title[80],status[20],base[96];scpy(path,BASE,220);n=slen(path);scpy(path+n,"/games.tsv",256-n);n=readall(path,filebuf,sizeof(filebuf));if(n<0)return 0;p=filebuf;while(*p&&i<MAX_GAMES){ln=p;while(*p&&*p!='\n'&&*p!='\r')p++;if(*p){*p++=0;while(*p=='\n'||*p=='\r')p++;}if(!*ln||*ln=='#')continue;q=ln;f=field(&q);if(!f)continue;gid=atoi10(f);if(gid<=0||game_gid_loaded(gid,i))continue;f=field(&q);scpy(title,f?f:"UNKNOWN",80);sanitize(title);f=field(&q);total=atoi10(f?f:"0");f=field(&q);scpy(status,f?f:"PACK",20);src=field(&q);f=field(&q);scpy(base,f?f:"",96);if(src&&seq(src,"EXTERNAL")&&!played_gid(gid)&&!played_name(base))continue;games[i].gid=gid;games[i].total=total;scpy(games[i].title,title,80);scpy(games[i].status,status,20);i++;}ngames=i;sort_games_alpha(ngames);return i;}
static int load_ach(int gid){char path[256],num[16],*p,*ln,*q,*f;int n,i=0,k=0,j,aid,points;scpy(path,BASE,220);k=slen(path);scpy(path+k,"/games/",256-k);k=slen(path);number(num,gid);for(j=0;num[j]&&k<250;j++)path[k++]=num[j];scpy(path+k,".tsv",256-k);n=readall(path,filebuf,sizeof(filebuf));if(n<0){nach=0;return 0;}p=filebuf;while(*p&&i<MAX_ACH){ln=p;while(*p&&*p!='\n'&&*p!='\r')p++;if(*p){*p++=0;while(*p=='\n'||*p=='\r')p++;}if(!*ln||*ln=='#')continue;q=ln;f=field(&q);aid=atoi10(f?f:"0");if(aid<=0||ach_id_loaded(aid,i))continue;f=field(&q);points=atoi10(f?f:"0");achs[i].id=aid;achs[i].points=points;f=field(&q);scpy(achs[i].title,f?f:"UNTITLED",76);sanitize(achs[i].title);f=field(&q);scpy(achs[i].desc,f?f:"",180);sanitize(achs[i].desc);f=field(&q);scpy(achs[i].badge,f?f:"",128);f=field(&q);scpy(achs[i].locked,f?f:"",128);i++;}nach=i;return i;}
static int state_has(int gid,int aid){char path[256],num[16],*p;int n,k=0,j,v;scpy(path,STATE,220);k=slen(path);path[k++]='/';number(num,gid);for(j=0;num[j]&&k<240;j++)path[k++]=num[j];scpy(path+k,".unlocked",256-k);n=readall(path,statebuf,sizeof(statebuf));if(n<0)return 0;p=statebuf;while(*p){v=atoi10(p);if(v==aid)return 1;while(*p&&*p!='\n'&&*p!='\r')p++;while(*p=='\n'||*p=='\r')p++;}return 0;}
static int state_count(int gid){char path[256],num[16],*p;int ids[1024],n,k=0,j,c=0,v,dup;scpy(path,STATE,220);k=slen(path);path[k++]='/';number(num,gid);for(j=0;num[j]&&k<240;j++)path[k++]=num[j];scpy(path+k,".unlocked",256-k);n=readall(path,statebuf,sizeof(statebuf));if(n<0)return 0;p=statebuf;while(*p){while(*p=='\r'||*p=='\n')p++;if(!*p)break;v=atoi10(p);if(v>0){dup=0;for(j=0;j<c;j++)if(ids[j]==v){dup=1;break;}if(!dup&&c<1024)ids[c++]=v;}while(*p&&*p!='\n'&&*p!='\r')p++;}return c;}
static void load_current_state(int gid){char path[256],num[16],*p;int n,k=0,j,v,dup;ncur_unlocked=0;cur_gid=gid;scpy(path,STATE,220);k=slen(path);path[k++]='/';number(num,gid);for(j=0;num[j]&&k<240;j++)path[k++]=num[j];scpy(path+k,".unlocked",256-k);n=readall(path,statebuf,sizeof(statebuf));if(n<0)return;p=statebuf;while(*p&&ncur_unlocked<1024){while(*p=='\r'||*p=='\n')p++;if(!*p)break;v=atoi10(p);if(v>0){dup=0;for(j=0;j<ncur_unlocked;j++)if(cur_unlocked[j]==v){dup=1;break;}if(!dup)cur_unlocked[ncur_unlocked++]=v;}while(*p&&*p!='\n'&&*p!='\r')p++;}}
static int current_has(int aid){int i;for(i=0;i<ncur_unlocked;i++)if(cur_unlocked[i]==aid)return 1;return 0;}
static void refresh_counts(void){int i;for(i=0;i<ngames;i++)games[i].unlocked=state_count(games[i].gid);}
static int runtime_ready(int gid){char p[256],num[16];int k=0,j;scpy(p,DB,220);k=slen(p);p[k++]='/';number(num,gid);for(j=0;num[j]&&k<240;j++)p[k++]=num[j];scpy(p+k,".fdb",256-k);return file_exists(p);}

static u32 rd32(const u8*b){return (u32)b[0]|((u32)b[1]<<8)|((u32)b[2]<<16)|((u32)b[3]<<24);}
static int draw_bmp(const char*rel,int x,int y,int dw,int dh){
    char path[300];u8 h[54],row[1024];
    int fd,w,hh,bpp,bytespp,off,top,rowbytes,yy,xx,sy,sx,k=0,i;
    u8 B,G,R;u32 c;
    if(!rel||!*rel)return 0;
    if(rel[0]=='/')scpy(path,rel,300);
    else{scpy(path,BASE,240);k=slen(path);path[k++]='/';scpy(path+k,rel,300-k);}
    fd=openf(path,O_RDONLY);if(fd<0)return 0;
    if(readf(fd,h,54)!=54||h[0]!='B'||h[1]!='M'){closef(fd);return 0;}
    off=(int)rd32(h+10);w=(int)rd32(h+18);hh=(int)rd32(h+22);
    bpp=(int)((u16)h[28]|((u16)h[29]<<8));
    if(w<=0||hh==0||(bpp!=24&&bpp!=32)||w>256){closef(fd);return 0;}
    bytespp=bpp/8;top=hh<0;if(hh<0)hh=-hh;
    rowbytes=((w*bytespp+3)/4)*4;
    if(rowbytes>(int)sizeof(row)){closef(fd);return 0;}
    for(yy=0;yy<dh;yy++){
        sy=yy*hh/dh;if(!top)sy=hh-1-sy;
        seekf(fd,off+sy*rowbytes,SEEK_SET);
        if(readf(fd,row,rowbytes)!=rowbytes)break;
        for(xx=0;xx<dw;xx++){
            sx=xx*w/dw;i=sx*bytespp;
            B=row[i];G=row[i+1];R=row[i+2];
            c=rgb(R,G,B);px(x+xx,y+yy,c);
        }
    }
    closef(fd);return 1;
}


enum Action{A_NONE,A_UP,A_DOWN,A_LEFT,A_RIGHT,A_OK,A_BACK,A_SQUARE,A_TRIANGLE,A_L1,A_R1,A_L2,A_R2,A_SELECT,A_START,A_L3,A_R3};

static int badge_fail_logged=0;
static void badge_fail_log(const char*rel){
    int fd;
    if(badge_fail_logged>=24)return;
    fd=openf("/media/PROJECT_ERIS_PP_BADGE_RUNTIME.log",O_WRONLY|O_CREAT|O_APPEND);
    if(fd>=0){
        writef(fd,"BADGE_FAIL\t",11);
        if(rel)writef(fd,rel,slen(rel));
        writef(fd,"\n",1);
        closef(fd);
    }
    badge_fail_logged++;
}
static int draw_badge_img(const char*rel,int x,int y,int w,int h){
    int ok;
    if(!rel||!*rel)return 0;
    ok=draw_bmp(rel,x,y,w,h);
    if(!ok)badge_fail_log(rel);
    return ok;
}

static int view=3; /* 0 journal, 1 achievements, 2 help, 3 RPG home, 4 pack quest board */
static int gsel=0,asel=0,filter=0,prevview=3,menu_sel=0;
static char search[1]={0};
static int ach_visible(int idx,int gid){int u;if(idx<0||idx>=nach)return 0;u=current_has(achs[idx].id);if(filter==1&&!u)return 0;if(filter==2&&u)return 0;return 1;}
static int next_vis(int cur,int dir,int gid){int i=cur;while(1){i+=dir;if(i<0||i>=nach)return cur;if(ach_visible(i,gid))return i;}}
static int first_vis(int gid){int i;for(i=0;i<nach;i++)if(ach_visible(i,gid))return i;return 0;}
static int unlocked_points_for_game(int gid){int i,s=0;for(i=0;i<nach;i++)if(current_has(achs[i].id))s+=achs[i].points;return s;}

static void header(const char*subtitle){rect(0,0,SW,SH,C_BG);rect(0,0,SW,76,C_PANEL);rect(0,74,SW,2,C_ICE);rect(23,29,32,12,C_ICE);rect(33,19,12,32,C_ICE);text(70,21,"PROJECT ERIS ++",3,C_ICE,24);text(360,25,"ACHIEVEMENTS",3,C_TEXT,24);if(subtitle)text(SW-420,28,subtitle,2,C_MUTED,42);}
static void footer(void){rect(0,SH-45,SW,45,C_PANEL);text(24,SH-31,"X SELECT",2,C_ICE,20);text(180,SH-31,"O BACK",2,C_TEXT,20);text(320,SH-31,"SQUARE FILTER",2,C_PURPLE,20);text(530,SH-31,"TRIANGLE HELP",2,C_PINK,22);text(770,SH-31,"L1/R1 PAGE",2,C_TEXT,20);text(980,SH-31,"START HELP",2,C_MUTED,20);}
static void status_badge(int x,int y,int gid,const char*status){int ready=runtime_ready(gid);if(seq(status,"NO_SET")){rect(x,y,142,25,C_RED);text(x+8,y+6,"NO RA SET",2,C_BG,15);}else if(seq(status,"PARTIAL")&&ready){rect(x,y,142,25,C_GOLD);text(x+8,y+6,"PARTIAL PACK",2,C_BG,18);}else if(ready){rect(x,y,142,25,C_GREEN);text(x+8,y+6,"RUNTIME READY",2,C_BG,18);}else{rect(x,y,142,25,C_GOLD);text(x+8,y+6,"PACK NEEDED",2,C_BG,18);}}
static void draw_games(void){int i,start,row,y,u,totalu=0,totala=0;char b[40];header("OFFLINE CONSOLE EDITION");
/* profile strip */rect(22,92,SW-44,90,C_PANEL);text(44,108,"PROFILE:",3,C_MUTED,12);text(205,108,profile_name,3,C_TEXT,24);for(i=0;i<ngames;i++){totalu+=games[i].unlocked;totala+=games[i].total;}number(b,totalu);text(44,148,b,3,C_ICE,10);text(44+80,152,"UNLOCKED",2,C_MUTED,12);number(b,totala);text(260,148,b,3,C_PURPLE,10);text(340,152,"AVAILABLE",2,C_MUTED,12);number(b,ngames);text(540,148,b,3,C_PINK,10);text(600,152,"GAMES",2,C_MUTED,10);if(totala>0)progress(760,126,430,18,totalu,totala);
start=(gsel/7)*7;for(i=start,row=0;i<ngames&&row<7;i++,row++){y=200+row*62;u=games[i].unlocked;rect(30,y,SW-60,54,i==gsel?C_PANEL2:C_PANEL);if(i==gsel)rect(30,y,5,54,C_ICE);text(50,y+10,games[i].title,2,i==gsel?C_TEXT:C_MUTED,42);number(b,u);text(630,y+9,b,2,C_GREEN,8);text(680,y+9,"/",2,C_MUTED,2);number(b,games[i].total);text(706,y+9,b,2,C_MUTED,8);progress(800,y+18,220,12,u,games[i].total);status_badge(1040,y+14,games[i].gid,games[i].status);}footer();}
static void wrap_desc(const char*s,int x,int y,int width_chars,int maxlines,u32 c){char lineb[60];int n=0,l=0,lastspace=-1,i=0,j;while(s&&*s&&l<maxlines){n=0;lastspace=-1;while(s[n]&&n<width_chars){if(s[n]==' ')lastspace=n;n++;}if(s[n]&&lastspace>4)n=lastspace;for(i=0;i<n&&i<58;i++)lineb[i]=s[i];lineb[i]=0;text(x,y+l*22,lineb,2,c,58);s+=n;while(*s==' ')s++;l++;} }
static void draw_ach(void){int gid=games[gsel].gid,i,start,row,y,u,cnt=0;char b[32],title[84];header(games[gsel].title);u=games[gsel].unlocked;rect(22,92,SW-44,66,C_PANEL);text(42,106,games[gsel].title,3,C_TEXT,46);number(b,u);text(760,108,b,3,C_GREEN,8);text(830,112,"/",2,C_MUTED,2);number(b,games[gsel].total);text(850,108,b,3,C_MUTED,8);progress(960,115,250,14,u,games[gsel].total);status_badge(42,132,gid,games[gsel].status);
if(seq(games[gsel].status,"NO_SET")){rect(80,220,SW-160,260,C_PANEL);text(120,260,"NO OFFICIAL RETROACHIEVEMENTS SET",3,C_RED,44);text(120,315,"THIS GAME IS INCLUDED IN THE ACHIEVEMENTS,",2,C_TEXT,55);text(120,345,"BUT THERE IS CURRENTLY NO OFFICIAL SET TO IMPORT.",2,C_TEXT,58);text(120,405,"A PACK CAN BE ADDED WHEN A SUPPORTED SET EXISTS.",2,C_ICE,48);footer();return;}
if(nach<=0){rect(80,220,SW-160,260,C_PANEL);text(120,260,"ACHIEVEMENT PACK NOT INSTALLED YET",3,C_GOLD,44);text(120,315,"THE INTERNAL GAME IS MAPPED TO ITS RA GAME ID.",2,C_TEXT,58);text(120,345,"ADD THE RAW CACHE / COMPILED FDB TO ACTIVATE IT.",2,C_TEXT,58);footer();return;}
/* find visible page based on asel */start=asel;cnt=0;while(start>0&&cnt<3){start=next_vis(start,-1,gid);cnt++;}i=start;for(row=0;row<4&&i>=0&&i<nach;row++){if(!ach_visible(i,gid)){int ni=next_vis(i,1,gid);if(ni==i)break;i=ni;}y=180+row*118;u=current_has(achs[i].id);rect(30,y,SW-60,108,i==asel?C_PANEL2:C_PANEL);if(i==asel)rect(30,y,5,108,C_ICE);if(!draw_badge_img((!u&&achs[i].locked[0])?achs[i].locked:achs[i].badge,50,y+14,80,80)){rect(50,y+14,80,80,u?C_GREEN:C_LINE);snowflake(90,y+54,22,u?C_BG:C_MUTED);}text(150,y+12,achs[i].title,2,u?C_TEXT:C_MUTED,62);text(150,y+41,u?"UNLOCKED":"LOCKED",2,u?C_GREEN:C_MUTED,12);number(b,achs[i].points);text(300,y+41,b,2,C_PURPLE,8);text(350,y+41,"XP",2,C_PURPLE,4);wrap_desc(achs[i].desc,150,y+68,76,2,C_MUTED);{int ni=next_vis(i,1,gid);if(ni==i)break;i=ni;}}
rect(SW-250,162,220,22,C_PANEL);text(SW-238,168,filter==0?"FILTER: ALL":filter==1?"FILTER: UNLOCKED":"FILTER: LOCKED",2,C_ICE,26);footer();}
static void draw_help(void){header("CONTROLS");rect(90,115,SW-180,500,C_PANEL);text(130,145,"PLAYSTATION CONTROLS",3,C_ICE,36);text(140,205,"D-PAD",2,C_PURPLE,12);text(360,205,"MOVE THROUGH LISTS",2,C_TEXT,30);text(140,245,"X",2,C_ICE,4);text(360,245,"OPEN / SELECT",2,C_TEXT,30);text(140,285,"O",2,C_TEXT,4);text(360,285,"BACK / EXIT",2,C_TEXT,30);text(140,325,"SQUARE",2,C_PURPLE,12);text(360,325,"ALL / UNLOCKED / LOCKED",2,C_TEXT,36);text(140,365,"TRIANGLE",2,C_PINK,12);text(360,365,"OPEN THIS HELP",2,C_TEXT,30);text(140,405,"L1 / R1",2,C_TEXT,12);text(360,405,"PREVIOUS / NEXT PAGE OR GAME",2,C_TEXT,42);text(140,445,"L2 / R2",2,C_TEXT,12);text(360,445,"FAST PAGE UP / DOWN",2,C_TEXT,32);text(140,485,"SELECT",2,C_TEXT,12);text(360,485,"RETURN TO PROFILE / GAMES",2,C_TEXT,38);text(140,525,"START",2,C_TEXT,12);text(360,525,"HELP",2,C_TEXT,12);text(140,565,"L3 / R3",2,C_TEXT,12);text(360,565,"FIRST / LAST ITEM",2,C_TEXT,32);footer();}
static void rpg_panel(int x,int y,int w,int h,u32 edge){
    rect(x,y,w,h,C_PANEL);
    rect(x,y,w,3,edge);rect(x,y+h-3,w,3,edge);
    rect(x,y,3,h,edge);rect(x+w-3,y,3,h,edge);
    rect(x+8,y+8,w-16,h-16,C_BG);
}
static void rpg_cursor(int x,int y,u32 cc){int i;for(i=0;i<18;i++)line(x+i,y+i/2,x+i,y+17-i/2,cc);}
static void draw_rpg_home(void){
    int i,totalu=0,totala=0,ready=0,need=0,noset=0,level;char b[32];
    header("ACHIEVEMENT HUB");
    for(i=0;i<ngames;i++){totalu+=games[i].unlocked;totala+=games[i].total;if(seq(games[i].status,"NO_SET"))noset++;else if(runtime_ready(games[i].gid))ready++;else need++;}
    level=1+totalu/10;
    rpg_panel(35,105,390,505,C_ICE);
    rect(72,132,316,300,C_PANEL2);
    if(!draw_bmp(PROFILE_AVATAR,102,145,256,256)){rect(177,190,106,106,C_ICE);rect(202,165,56,156,C_ICE);}
    text(82,463,"LOCAL PROFILE",2,C_MUTED,20);text(82,495,profile_name,4,C_TEXT,22);
    text(82,541,"LEVEL",2,C_MUTED,10);number(b,level);text(190,534,b,4,C_PURPLE,8);
    text(82,578,"UNLOCKED",2,C_MUTED,14);number(b,totalu);text(260,572,b,3,C_GREEN,10);
    rpg_panel(455,105,790,505,C_PURPLE);
    text(495,135,"PROJECT ERIS ++",3,C_ICE,30);text(495,176,"OFFLINE ACHIEVEMENT HUB",2,C_TEXT,36);
    text(495,210,"ALL PROGRESS STAYS ON THIS USB DRIVE.",2,C_MUTED,48);
    for(i=0;i<4;i++){int yy=270+i*68;rect(500,yy,680,52,i==menu_sel?C_PANEL2:C_PANEL);if(i==menu_sel){rect(500,yy,5,52,C_ICE);rpg_cursor(516,yy+17,C_ICE);}if(i==0)text(555,yy+14,"ACHIEVEMENT LIBRARY",3,i==menu_sel?C_TEXT:C_MUTED,32);else if(i==1)text(555,yy+14,"PACK STATUS",3,i==menu_sel?C_TEXT:C_MUTED,24);else if(i==2)text(555,yy+14,"CONTROLS",3,i==menu_sel?C_TEXT:C_MUTED,20);else text(555,yy+14,"RETURN TO CAROUSEL",3,i==menu_sel?C_TEXT:C_MUTED,32);}
    text(500,557,"READY",2,C_GREEN,12);number(b,ready);text(610,550,b,3,C_GREEN,8);
    text(720,557,"NEEDS PACK",2,C_GOLD,16);number(b,need);text(900,550,b,3,C_GOLD,8);
    text(1000,557,"NO SET",2,C_RED,12);number(b,noset);text(1110,550,b,3,C_RED,8);footer();
}
static void draw_pack_quests(void){
    int i,start,row,y,ready=0,need=0,noset=0;char b[32];
    header("PACK STATUS");
    for(i=0;i<ngames;i++){if(seq(games[i].status,"NO_SET"))noset++;else if(runtime_ready(games[i].gid))ready++;else need++;}
    rpg_panel(25,100,880,535,C_GOLD);text(55,125,"INSTALLED GAME PACKS",3,C_ICE,30);
    text(55,162,"READY",2,C_GREEN,10);number(b,ready);text(145,155,b,3,C_GREEN,8);
    text(225,162,"NEEDED",2,C_GOLD,12);number(b,need);text(335,155,b,3,C_GOLD,8);
    text(415,162,"NO SET",2,C_RED,10);number(b,noset);text(515,155,b,3,C_RED,8);
    start=(gsel/7)*7;for(i=start,row=0;i<ngames&&row<7;i++,row++){y=205+row*55;rect(48,y,830,47,i==gsel?C_PANEL2:C_PANEL);if(i==gsel)rect(48,y,5,47,C_ICE);text(66,y+10,games[i].title,2,i==gsel?C_TEXT:C_MUTED,40);status_badge(705,y+10,games[i].gid,games[i].status);}
    rpg_panel(930,100,315,535,C_PINK);if(!draw_bmp(PROFILE_AVATAR,960,132,256,256)){rect(1045,190,90,90,C_ICE);}
    text(958,420,"LOCAL ONLY",3,C_PINK,18);text(958,462,"PACKS ARE BUILT",2,C_TEXT,22);text(958,488,"ON YOUR WINDOWS PC",2,C_TEXT,24);text(958,514,"AND RUN OFFLINE HERE.",2,C_MUTED,26);text(958,563,"X: DETAILS",2,C_ICE,16);text(958,592,"O: HOME",2,C_MUTED,12);footer();
}
static void draw(void){if(view==3)draw_rpg_home();else if(view==4)draw_pack_quests();else if(view==0)draw_games();else if(view==1)draw_ach();else draw_help();}
static void page_games(int d){gsel+=d*7;if(gsel<0)gsel=0;if(gsel>=ngames)gsel=ngames-1;}
static void change_game(int d){if(ngames<=0)return;gsel+=d;if(gsel<0)gsel=ngames-1;if(gsel>=ngames)gsel=0;load_ach(games[gsel].gid);load_current_state(games[gsel].gid);asel=first_vis(games[gsel].gid);}
static void handle(enum Action a,int*run){
    if(a==A_NONE)return;
    if(a==A_START||a==A_TRIANGLE){if(view==2)view=prevview;else{prevview=view;view=2;}return;}
    if(a==A_SELECT){view=3;menu_sel=0;return;}
    if(view==2){if(a==A_BACK||a==A_OK)view=prevview;return;}
    if(view==3){if(a==A_UP&&menu_sel>0)menu_sel--;else if(a==A_DOWN&&menu_sel<3)menu_sel++;else if(a==A_BACK)*run=0;else if(a==A_OK){if(menu_sel==0)view=0;else if(menu_sel==1)view=4;else if(menu_sel==2){prevview=3;view=2;}else *run=0;}return;}
    if(view==4){if(a==A_L3)gsel=0;else if(a==A_R3&&ngames>0)gsel=ngames-1;else if(a==A_UP&&gsel>0)gsel--;else if(a==A_DOWN&&gsel<ngames-1)gsel++;else if(a==A_L1||a==A_L2)page_games(-1);else if(a==A_R1||a==A_R2)page_games(1);else if(a==A_OK&&ngames>0){load_ach(games[gsel].gid);load_current_state(games[gsel].gid);asel=first_vis(games[gsel].gid);view=1;}else if(a==A_BACK)view=3;return;}
    if(view==0){if(a==A_L3)gsel=0;else if(a==A_R3&&ngames>0)gsel=ngames-1;else if(a==A_UP&&gsel>0)gsel--;else if(a==A_DOWN&&gsel<ngames-1)gsel++;else if(a==A_L1||a==A_L2)page_games(-1);else if(a==A_R1||a==A_R2)page_games(1);else if(a==A_OK&&ngames>0){load_ach(games[gsel].gid);load_current_state(games[gsel].gid);asel=first_vis(games[gsel].gid);view=1;}else if(a==A_BACK)view=3;return;}
    if(view==1){int gid=games[gsel].gid;if(a==A_L3)asel=first_vis(gid);else if(a==A_R3){int k=asel,nx;while((nx=next_vis(k,1,gid))!=k)k=nx;asel=k;}else if(a==A_UP)asel=next_vis(asel,-1,gid);else if(a==A_DOWN)asel=next_vis(asel,1,gid);else if(a==A_L1)change_game(-1);else if(a==A_R1)change_game(1);else if(a==A_L2){int k;for(k=0;k<4;k++)asel=next_vis(asel,-1,gid);}else if(a==A_R2){int k;for(k=0;k<4;k++)asel=next_vis(asel,1,gid);}else if(a==A_SQUARE){filter=filter+1;if(filter>=3)filter=0;asel=first_vis(gid);}else if(a==A_BACK)view=0;}
}

/* -------------------------------------------------------------------------
 * libretro frontend bridge
 * RetroArch owns display, controller, lifecycle and fullscreen presentation.
 * ------------------------------------------------------------------------- */
typedef int lbool;
typedef short s16;
typedef void (*retro_video_refresh_t)(const void*,unsigned,unsigned,usize);
typedef void (*retro_audio_sample_t)(s16,s16);
typedef usize (*retro_audio_sample_batch_t)(const s16*,usize);
typedef lbool (*retro_environment_t)(unsigned,void*);
typedef void (*retro_input_poll_t)(void);
typedef s16 (*retro_input_state_t)(unsigned,unsigned,unsigned,unsigned);

struct retro_game_geometry{unsigned base_width,base_height,max_width,max_height;float aspect_ratio;};
struct retro_system_timing{double fps,sample_rate;};
struct retro_system_av_info{struct retro_game_geometry geometry;struct retro_system_timing timing;};
struct retro_system_info{const char*library_name;const char*library_version;const char*valid_extensions;lbool need_fullpath;lbool block_extract;};
struct retro_game_info{const char*path;const void*data;usize size;const char*meta;};

#define RETRO_API_VERSION 1
#define RETRO_ENVIRONMENT_SHUTDOWN 7
#define RETRO_ENVIRONMENT_SET_PIXEL_FORMAT 10
#define RETRO_ENVIRONMENT_SET_SUPPORT_NO_GAME 18
#define RETRO_PIXEL_FORMAT_XRGB8888 1
#define RETRO_PIXEL_FORMAT_RGB565 2
#define RETRO_DEVICE_JOYPAD 1
#define RETRO_DEVICE_ANALOG 5
#define RETRO_DEVICE_ID_JOYPAD_B 0
#define RETRO_DEVICE_ID_JOYPAD_Y 1
#define RETRO_DEVICE_ID_JOYPAD_SELECT 2
#define RETRO_DEVICE_ID_JOYPAD_START 3
#define RETRO_DEVICE_ID_JOYPAD_UP 4
#define RETRO_DEVICE_ID_JOYPAD_DOWN 5
#define RETRO_DEVICE_ID_JOYPAD_LEFT 6
#define RETRO_DEVICE_ID_JOYPAD_RIGHT 7
#define RETRO_DEVICE_ID_JOYPAD_A 8
#define RETRO_DEVICE_ID_JOYPAD_X 9
#define RETRO_DEVICE_ID_JOYPAD_L 10
#define RETRO_DEVICE_ID_JOYPAD_R 11
#define RETRO_DEVICE_ID_JOYPAD_L2 12
#define RETRO_DEVICE_ID_JOYPAD_R2 13
#define RETRO_DEVICE_ID_JOYPAD_L3 14
#define RETRO_DEVICE_ID_JOYPAD_R3 15
#define RETRO_DEVICE_INDEX_ANALOG_LEFT 0
#define RETRO_DEVICE_ID_ANALOG_X 0
#define RETRO_DEVICE_ID_ANALOG_Y 1

static retro_environment_t env_cb=0;
static retro_video_refresh_t video_cb=0;
static retro_audio_sample_t audio_cb=0;
static retro_audio_sample_batch_t audio_batch_cb=0;
static retro_input_poll_t input_poll_cb=0;
static retro_input_state_t input_state_cb=0;
static u32 prev_buttons=0;
static int hold_frames[16];
static int analog_x_prev=0,analog_y_prev=0;
static int dirty=1,loaded=0,shutdown_sent=0;
static int frame_counter=0,catalog_pending=0;
static const char*CORELOG="/media/PROJECT_ERIS_PP_UI.log";

static void corelog(const char*s){
    int fd=openf(CORELOG,O_WRONLY|O_APPEND);
    if(fd<0)return;
    writef(fd,s,slen(s));writef(fd,"\n",1);closef(fd);
}
static void corelog_num(const char*prefix,int n){char b[32];int fd;number(b,n);fd=openf(CORELOG,O_WRONLY|O_APPEND);if(fd<0)return;writef(fd,prefix,slen(prefix));writef(fd,b,slen(b));writef(fd,"\n",1);closef(fd);}
static void clear_video(void){int i;for(i=0;i<VIDEO_W*VIDEO_H;i++)video_buf[i]=0;}
static int btn(unsigned id){return input_state_cb?input_state_cb(0,RETRO_DEVICE_JOYPAD,0,id)!=0:0;}
static int analog_dir(s16 v){if(v<-16000)return -1;if(v>16000)return 1;return 0;}
static int nav_fire(unsigned id,u32 mask){
    int down=(mask&(1u<<id))!=0;
    if(!down){hold_frames[id]=0;return 0;}
    hold_frames[id]++;
    if(!(prev_buttons&(1u<<id)))return 1;
    if(hold_frames[id]==20)return 1;
    if(hold_frames[id]>20 && (imod32(hold_frames[id]-20,5)==0))return 1;
    return 0;
}
static enum Action poll_action(void){
    u32 m=0;int i,ax,ay;
    if(!input_state_cb)return A_NONE;
    if(input_poll_cb)input_poll_cb();
    for(i=0;i<16;i++)if(btn((unsigned)i))m|=1u<<i;

    /* D-pad and shoulders repeat naturally while held. */
    if(nav_fire(RETRO_DEVICE_ID_JOYPAD_UP,m)){prev_buttons=m;return A_UP;}
    if(nav_fire(RETRO_DEVICE_ID_JOYPAD_DOWN,m)){prev_buttons=m;return A_DOWN;}
    if(nav_fire(RETRO_DEVICE_ID_JOYPAD_LEFT,m)){prev_buttons=m;return A_LEFT;}
    if(nav_fire(RETRO_DEVICE_ID_JOYPAD_RIGHT,m)){prev_buttons=m;return A_RIGHT;}
    if(nav_fire(RETRO_DEVICE_ID_JOYPAD_L,m)){prev_buttons=m;return A_L1;}
    if(nav_fire(RETRO_DEVICE_ID_JOYPAD_R,m)){prev_buttons=m;return A_R1;}
    if(nav_fire(RETRO_DEVICE_ID_JOYPAD_L2,m)){prev_buttons=m;return A_L2;}
    if(nav_fire(RETRO_DEVICE_ID_JOYPAD_R2,m)){prev_buttons=m;return A_R2;}

    /* Standard PlayStation geometry through RetroPad:
       Cross=south(B), Circle=east(A), Square=west(Y), Triangle=north(X). */
    if((m&(1u<<RETRO_DEVICE_ID_JOYPAD_B))&&!(prev_buttons&(1u<<RETRO_DEVICE_ID_JOYPAD_B))){prev_buttons=m;return A_OK;}
    if((m&(1u<<RETRO_DEVICE_ID_JOYPAD_A))&&!(prev_buttons&(1u<<RETRO_DEVICE_ID_JOYPAD_A))){prev_buttons=m;return A_BACK;}
    if((m&(1u<<RETRO_DEVICE_ID_JOYPAD_Y))&&!(prev_buttons&(1u<<RETRO_DEVICE_ID_JOYPAD_Y))){prev_buttons=m;return A_SQUARE;}
    if((m&(1u<<RETRO_DEVICE_ID_JOYPAD_X))&&!(prev_buttons&(1u<<RETRO_DEVICE_ID_JOYPAD_X))){prev_buttons=m;return A_TRIANGLE;}
    if((m&(1u<<RETRO_DEVICE_ID_JOYPAD_SELECT))&&!(prev_buttons&(1u<<RETRO_DEVICE_ID_JOYPAD_SELECT))){prev_buttons=m;return A_SELECT;}
    if((m&(1u<<RETRO_DEVICE_ID_JOYPAD_START))&&!(prev_buttons&(1u<<RETRO_DEVICE_ID_JOYPAD_START))){prev_buttons=m;return A_START;}
    if((m&(1u<<RETRO_DEVICE_ID_JOYPAD_L3))&&!(prev_buttons&(1u<<RETRO_DEVICE_ID_JOYPAD_L3))){prev_buttons=m;return A_L3;}
    if((m&(1u<<RETRO_DEVICE_ID_JOYPAD_R3))&&!(prev_buttons&(1u<<RETRO_DEVICE_ID_JOYPAD_R3))){prev_buttons=m;return A_R3;}

    /* Left analog stick fallback for navigation. */
    ax=analog_dir(input_state_cb(0,RETRO_DEVICE_ANALOG,RETRO_DEVICE_INDEX_ANALOG_LEFT,RETRO_DEVICE_ID_ANALOG_X));
    ay=analog_dir(input_state_cb(0,RETRO_DEVICE_ANALOG,RETRO_DEVICE_INDEX_ANALOG_LEFT,RETRO_DEVICE_ID_ANALOG_Y));
    if(ay!=analog_y_prev){analog_y_prev=ay;prev_buttons=m;if(ay<0)return A_UP;if(ay>0)return A_DOWN;}
    if(ax!=analog_x_prev){analog_x_prev=ax;prev_buttons=m;if(ax<0)return A_LEFT;if(ax>0)return A_RIGHT;}
    prev_buttons=m;
    return A_NONE;
}

__attribute__((visibility("default"))) unsigned retro_api_version(void){return RETRO_API_VERSION;}
__attribute__((visibility("default"))) void retro_set_environment(retro_environment_t cb){lbool yes=1;env_cb=cb;corelog("ERISPP100 SET_ENVIRONMENT");if(env_cb)env_cb(RETRO_ENVIRONMENT_SET_SUPPORT_NO_GAME,&yes);}
__attribute__((visibility("default"))) void retro_set_video_refresh(retro_video_refresh_t cb){video_cb=cb;corelog("ERISPP100 SET_VIDEO_REFRESH");}
__attribute__((visibility("default"))) void retro_set_audio_sample(retro_audio_sample_t cb){audio_cb=cb;corelog("ERISPP100 SET_AUDIO_SAMPLE");}
__attribute__((visibility("default"))) void retro_set_audio_sample_batch(retro_audio_sample_batch_t cb){audio_batch_cb=cb;corelog("ERISPP100 SET_AUDIO_BATCH");}
__attribute__((visibility("default"))) void retro_set_input_poll(retro_input_poll_t cb){input_poll_cb=cb;corelog("ERISPP100 SET_INPUT_POLL");}
__attribute__((visibility("default"))) void retro_set_input_state(retro_input_state_t cb){input_state_cb=cb;corelog("ERISPP100 SET_INPUT_STATE");}
__attribute__((visibility("default"))) void retro_set_controller_port_device(unsigned port,unsigned device){(void)port;(void)device;}
__attribute__((visibility("default"))) void retro_init(void){corelog("ERISPP100 RETRO_INIT ENTER");clear_video();colors();corelog("ERISPP100 RETRO_INIT OK");}
__attribute__((visibility("default"))) void retro_deinit(void){corelog("ERISPP100 CORE DEINIT");}
__attribute__((visibility("default"))) void retro_get_system_info(struct retro_system_info*info){
    info->library_name="Project Eris ++ Achievements";
    info->library_version="1.0.0";
    info->valid_extensions="erispp";
    info->need_fullpath=0;info->block_extract=0;
}
__attribute__((visibility("default"))) void retro_get_system_av_info(struct retro_system_av_info*info){
    info->geometry.base_width=VIDEO_W;info->geometry.base_height=VIDEO_H;
    info->geometry.max_width=VIDEO_W;info->geometry.max_height=VIDEO_H;
    info->geometry.aspect_ratio=16.0f/9.0f;
    info->timing.fps=60.0;info->timing.sample_rate=48000.0;
}
__attribute__((visibility("default"))) void retro_reset(void){view=3;gsel=0;filter=0;menu_sel=0;dirty=1;}
__attribute__((visibility("default"))) usize retro_serialize_size(void){return 0;}
__attribute__((visibility("default"))) lbool retro_serialize(void*data,usize size){(void)data;(void)size;return 0;}
__attribute__((visibility("default"))) lbool retro_unserialize(const void*data,usize size){(void)data;(void)size;return 0;}
__attribute__((visibility("default"))) void retro_cheat_reset(void){}
__attribute__((visibility("default"))) void retro_cheat_set(unsigned index,lbool enabled,const char*code){(void)index;(void)enabled;(void)code;}
__attribute__((visibility("default"))) lbool retro_load_game(const struct retro_game_info*game){
    int fmt=RETRO_PIXEL_FORMAT_RGB565;
    (void)game;
    corelog("ERISPP100 LOAD_GAME ENTER");
    if(env_cb&&!env_cb(RETRO_ENVIRONMENT_SET_PIXEL_FORMAT,&fmt)){corelog("ERISPP100 RGB565 REJECTED");return 0;}
    corelog("ERISPP100 RGB565 ACCEPTED");
    view=3;gsel=0;asel=0;filter=0;prevview=3;menu_sel=0;dirty=1;loaded=1;shutdown_sent=0;frame_counter=0;catalog_pending=1;ngames=0;
    corelog("ERISPP100 LOAD_GAME OK - CATALOG DEFERRED");
    return 1;
}
__attribute__((visibility("default"))) lbool retro_load_game_special(unsigned type,const struct retro_game_info*info,usize num){(void)type;(void)info;(void)num;return 0;}
__attribute__((visibility("default"))) void retro_unload_game(void){loaded=0;corelog("ERISPP100 UNLOAD");}
__attribute__((visibility("default"))) unsigned retro_get_region(void){return 0;}
__attribute__((visibility("default"))) void*retro_get_memory_data(unsigned id){(void)id;return 0;}
__attribute__((visibility("default"))) usize retro_get_memory_size(unsigned id){(void)id;return 0;}

__attribute__((visibility("default"))) void retro_run(void){
    enum Action a;int run=1,n;
    if(!loaded){if(video_cb)video_cb(video_buf,VIDEO_W,VIDEO_H,VIDEO_W*2);return;}
    if(frame_counter==0){
        corelog("ERISPP100 FRAME0 ENTER");
        header("SAFE BOOT V2.5.6");
        rect(120,180,SW-240,260,C_PANEL);
        text(180,230,"PROJECT ERIS ACHIEVEMENTS",4,C_ICE,32);
        text(180,300,"SAFE START - LOADING CATALOG...",2,C_TEXT,45);
        text(180,350,"NATIVE 1280X720 / RGB565 / 16:9",2,C_PURPLE,40);
        if(video_cb)video_cb(video_buf,VIDEO_W,VIDEO_H,VIDEO_W*2);
        corelog("ERISPP100 FRAME0 VIDEO SENT");
        frame_counter++;
        return;
    }
    if(catalog_pending){
        catalog_pending=0;
        corelog("ERISPP100 CATALOG LOAD BEGIN");
        n=load_games();
        corelog_num("ERISPP100 GAMES LOADED=",n);
        if(n>0){corelog("ERISPP100 REFRESH COUNTS BEGIN");refresh_counts();corelog("ERISPP100 REFRESH COUNTS OK");}
        view=3;gsel=0;asel=0;filter=0;prevview=3;menu_sel=0;dirty=1;
        corelog(n>0?"ERISPP100 CATALOG LOAD OK":"ERISPP100 CATALOG EMPTY");
    }
    a=poll_action();
    if(a!=A_NONE){
        handle(a,&run);dirty=1;
        if(!run&&!shutdown_sent){shutdown_sent=1;corelog("ERISPP100 SHUTDOWN REQUESTED");if(env_cb)env_cb(RETRO_ENVIRONMENT_SHUTDOWN,0);}
    }
    frame_counter++;
    if((imod32(frame_counter,300)==0)&&view==0&&ngames>0){refresh_counts();dirty=1;}
    if(dirty){draw();dirty=0;}
    if(video_cb)video_cb(video_buf,VIDEO_W,VIDEO_H,VIDEO_W*2);
}

__attribute__((used,visibility("default"))) void *projecterispp_force_reloc = (void*)&retro_api_version;
