
typedef unsigned char u8; typedef unsigned short u16; typedef unsigned int u32; typedef int s32; typedef unsigned long usize; typedef short s16;
static u32 udiv32(u32 n,u32 d){u32 q=0,b=1;if(!d)return 0xffffffffu;while((d&0x80000000u)==0&&d<n&&b&&(d<<1)>d){d<<=1;b<<=1;}while(b){if(n>=d){n-=d;q|=b;}d>>=1;b>>=1;}return q;}
u32 __aeabi_uidiv(u32 n,u32 d){return udiv32(n,d);} s32 __aeabi_idiv(s32 n,s32 d){int neg=0;u32 a,b,q;if(!d)return 0;if(n<0){neg^=1;a=(u32)(-(n+1))+1;}else a=(u32)n;if(d<0){neg^=1;b=(u32)(-(d+1))+1;}else b=(u32)d;q=udiv32(a,b);return neg?-(s32)q:(s32)q;}
#define SYS_READ 3
#define SYS_WRITE 4
#define SYS_OPEN 5
#define SYS_CLOSE 6
#define O_RDONLY 0
#define O_WRONLY 1
#define O_CREAT 0100
#define O_APPEND 02000
static long sc1(long n,long a){register long r7 asm("r7")=n;register long r0 asm("r0")=a;asm volatile("svc 0":"+r"(r0):"r"(r7):"memory");return r0;}
static long sc3(long n,long a,long b,long c){register long r7 asm("r7")=n;register long r0 asm("r0")=a;register long r1 asm("r1")=b;register long r2 asm("r2")=c;asm volatile("svc 0":"+r"(r0):"r"(r1),"r"(r2),"r"(r7):"memory");return r0;}
static int openf(const char*p,int f){return (int)sc3(SYS_OPEN,(long)p,f,0);}static int closef(int f){return (int)sc1(SYS_CLOSE,f);}static int readf(int f,void*b,int n){return (int)sc3(SYS_READ,f,(long)b,n);}static int writef(int f,const void*b,int n){return (int)sc3(SYS_WRITE,f,(long)b,n);}
static int slen(const char*s){int n=0;while(s&&s[n])n++;return n;}static void scpy(char*d,const char*s,int m){int i=0;if(m<1)return;while(s&&s[i]&&i<m-1){d[i]=s[i];i++;}d[i]=0;}static int atoi10(const char*s){int n=0;while(s&&*s>='0'&&*s<='9'){n=n*10+(*s-'0');s++;}return n;}
static int readall(const char*p,char*b,int m){int f,n,t=0;f=openf(p,O_RDONLY);if(f<0)return -1;while(t<m-1&&(n=readf(f,b+t,m-1-t))>0)t+=n;closef(f);b[t]=0;return t;}
static int existsf(const char*p){int f=openf(p,O_RDONLY);if(f<0)return 0;closef(f);return 1;}
static void elog(const char*s){int f=openf("/media/PROJECT_ERIS_PP_INTERNAL_CORE.log",O_WRONLY|O_CREAT|O_APPEND);if(f<0)return;writef(f,s,slen(s));writef(f,"\n",1);closef(f);}

#define W 1280
#define H 720
static u16 fb[W*H];
static u32 rgb(u8 r,u8 g,u8 b){return (u32)(((u16)(r>>3)<<11)|((u16)(g>>2)<<5)|((u16)(b>>3)));}
static void rect(int x,int y,int w,int h,u32 c){int yy,xx,x2=x+w,y2=y+h;if(x<0)x=0;if(y<0)y=0;if(x2>W)x2=W;if(y2>H)y2=H;for(yy=y;yy<y2;yy++){u16*row=&fb[yy*W];for(xx=x;xx<x2;xx++)row[xx]=(u16)c;}}
static const u8 AZ[26][7]={{14,17,17,31,17,17,17},{30,17,17,30,17,17,30},{14,17,16,16,16,17,14},{30,17,17,17,17,17,30},{31,16,16,30,16,16,31},{31,16,16,30,16,16,16},{14,17,16,23,17,17,15},{17,17,17,31,17,17,17},{14,4,4,4,4,4,14},{7,2,2,2,2,18,12},{17,18,20,24,20,18,17},{16,16,16,16,16,16,31},{17,27,21,21,17,17,17},{17,25,21,19,17,17,17},{14,17,17,17,17,17,14},{30,17,17,30,16,16,16},{14,17,17,17,21,18,13},{30,17,17,30,20,18,17},{15,16,16,14,1,1,30},{31,4,4,4,4,4,4},{17,17,17,17,17,17,14},{17,17,17,17,17,10,4},{17,17,17,21,21,21,10},{17,17,10,4,10,17,17},{17,17,10,4,4,4,4},{31,1,2,4,8,16,31}};
static const u8 NU[10][7]={{14,17,19,21,25,17,14},{4,12,4,4,4,4,14},{14,17,1,2,4,8,31},{30,1,1,14,1,1,30},{2,6,10,18,31,2,2},{31,16,16,30,1,1,30},{14,16,16,30,17,17,14},{31,1,2,4,8,8,8},{14,17,17,14,17,17,14},{14,17,17,15,1,1,14}};
static char up(char c){return c>='a'&&c<='z'?c-32:c;}static void glyph(char c,u8 g[7]){int i;for(i=0;i<7;i++)g[i]=0;c=up(c);if(c>='A'&&c<='Z'){for(i=0;i<7;i++)g[i]=AZ[c-'A'][i];return;}if(c>='0'&&c<='9'){for(i=0;i<7;i++)g[i]=NU[c-'0'][i];return;}if(c=='-')g[3]=14;else if(c=='.')g[6]=4;else if(c==':'){g[2]=4;g[5]=4;}else if(c=='/') {g[0]=1;g[1]=2;g[2]=2;g[3]=4;g[4]=8;g[5]=8;g[6]=16;}else if(c=='!'){g[0]=g[1]=g[2]=g[3]=g[4]=g[6]=4;}}
static void text(int x,int y,const char*s,int sc,u32 c,int max){int n=0,r,k,xx=x;u8 g[7];while(s&&*s&&n<max){char ch=*s++;glyph(ch,g);for(r=0;r<7;r++)for(k=0;k<5;k++)if(g[r]&(1<<(4-k)))rect(xx+k*sc,y+r*sc,sc,sc,c);xx+=6*sc;n++;}}
static void num(char*b,int n){char t[16];int i=0,j=0,q,r;if(n==0){b[0]='0';b[1]=0;return;}while(n){q=__aeabi_idiv(n,10);r=n-q*10;t[i++]=(char)('0'+r);n=q;}while(i)b[j++]=t[--i];b[j]=0;}
static char statbuf[4096],phase[32],current[96],message[160],errorv[128];static int done=0,total=20,auto_mode=0,terminal_frames=0;
static void val(const char*key,char*out,int max){
    const char*p=statbuf;int kl=slen(key),i,j;
    out[0]=0;
    while(*p){
        const char*line=p;
        while(*p&&*p!='\n'&&*p!='\r')p++;
        for(i=0;i<kl&&line+i<p&&line[i]==key[i];i++);
        if(i==kl&&line+i<p&&line[i]=='='){
            j=0;i++;
            while(line+i<p&&j<max-1){out[j++]=line[i++];}
            out[j]=0;return;
        }
        while(*p=='\n'||*p=='\r')p++;
    }
}
static int is_complete(void){return phase[0]=='C'&&phase[1]=='O'&&phase[2]=='M';}
static int is_error(void){return phase[0]=='E'&&phase[1]=='R'&&phase[2]=='R';}
static void status(void){char b[32];if(readall("/media/PROJECT_ERIS_PP_INTERNAL_EXPORT/status.txt",statbuf,sizeof(statbuf))<0){scpy(phase,"WAITING",32);scpy(current,"",96);scpy(message,"Preparing export worker...",160);scpy(errorv,"",128);done=0;total=20;return;}val("PHASE",phase,32);val("CURRENT",current,96);val("MESSAGE",message,160);val("ERROR",errorv,128);val("DONE",b,32);done=atoi10(b);val("TOTAL",b,32);total=atoi10(b);if(total<1)total=20;}
typedef int lbool;typedef void(*retro_video_refresh_t)(const void*,unsigned,unsigned,usize);typedef void(*retro_audio_sample_t)(s16,s16);typedef usize(*retro_audio_sample_batch_t)(const s16*,usize);typedef lbool(*retro_environment_t)(unsigned,void*);typedef void(*retro_input_poll_t)(void);typedef s16(*retro_input_state_t)(unsigned,unsigned,unsigned,unsigned);
struct retro_game_geometry{unsigned base_width,base_height,max_width,max_height;float aspect_ratio;};struct retro_system_timing{double fps,sample_rate;};struct retro_system_av_info{struct retro_game_geometry geometry;struct retro_system_timing timing;};struct retro_system_info{const char*library_name;const char*library_version;const char*valid_extensions;lbool need_fullpath;lbool block_extract;};struct retro_game_info{const char*path;const void*data;usize size;const char*meta;};
#define RETRO_ENVIRONMENT_SHUTDOWN 7
#define RETRO_ENVIRONMENT_SET_PIXEL_FORMAT 10
#define RETRO_ENVIRONMENT_SET_SUPPORT_NO_GAME 18
#define RETRO_PIXEL_FORMAT_RGB565 2
#define RETRO_DEVICE_JOYPAD 1
#define RETRO_DEVICE_ID_JOYPAD_A 8
static retro_environment_t env;static retro_video_refresh_t video;static retro_audio_sample_t aud;static retro_audio_sample_batch_t audb;static retro_input_poll_t poll;static retro_input_state_t input;static int prevA=0,frames=0,shutdown=0;
void retro_set_environment(retro_environment_t c){int yes=1;env=c;elog("ERISPP112 SET_ENVIRONMENT");if(env)env(RETRO_ENVIRONMENT_SET_SUPPORT_NO_GAME,&yes);}
void retro_set_controller_port_device(unsigned port,unsigned device){(void)port;(void)device;}void retro_set_video_refresh(retro_video_refresh_t c){video=c;}void retro_set_audio_sample(retro_audio_sample_t c){aud=c;}void retro_set_audio_sample_batch(retro_audio_sample_batch_t c){audb=c;}void retro_set_input_poll(retro_input_poll_t c){poll=c;}void retro_set_input_state(retro_input_state_t c){input=c;}
unsigned retro_api_version(void){return 1;}void retro_init(void){auto_mode=existsf("/media/project_eris/etc/project_eris/etc/erispp/runtime/AUTO_INTERNAL_EXPORT.flag");elog(auto_mode?"ERISPP112 RETRO_INIT AUTO_MODE=1":"ERISPP112 RETRO_INIT AUTO_MODE=0");}void retro_deinit(void){}void retro_get_system_info(struct retro_system_info*i){i->library_name="Project Eris ++ Internal Export";i->library_version="1.0.12";i->valid_extensions="fzexport";i->need_fullpath=1;i->block_extract=0;}void retro_get_system_av_info(struct retro_system_av_info*i){i->geometry.base_width=W;i->geometry.base_height=H;i->geometry.max_width=W;i->geometry.max_height=H;i->geometry.aspect_ratio=16.0f/9.0f;i->timing.fps=60.0;i->timing.sample_rate=48000.0;}
void retro_reset(void){}usize retro_serialize_size(void){return 0;}lbool retro_serialize(void*d,usize s){return 0;}lbool retro_unserialize(const void*d,usize s){return 0;}void retro_cheat_reset(void){}void retro_cheat_set(unsigned i,lbool e,const char*c){}unsigned retro_get_region(void){return 0;}void*retro_get_memory_data(unsigned i){return 0;}usize retro_get_memory_size(unsigned i){return 0;}
lbool retro_load_game(const struct retro_game_info*g){int f=RETRO_PIXEL_FORMAT_RGB565;elog("ERISPP112 LOAD_GAME ENTER");if(env&&!env(RETRO_ENVIRONMENT_SET_PIXEL_FORMAT,&f)){elog("ERISPP112 RGB565 REJECTED");return 0;}elog("ERISPP112 RGB565 ACCEPTED");return 1;}void retro_unload_game(void){}lbool retro_load_game_special(unsigned t,const struct retro_game_info*i,usize n){return 0;}
void retro_run(void){if(frames==0)elog("ERISPP112 FRAME0 ENTER");u32 bg=rgb(7,11,25),panel=rgb(14,22,43),ice=rgb(142,233,255),txt=rgb(238,247,255),mut=rgb(137,160,188),pur=rgb(183,140,255),green=rgb(143,255,199),red=rgb(255,116,130);char b[32];int fill=0;
 if(poll)poll();status();rect(0,0,W,H,bg);rect(0,0,W,82,panel);rect(0,80,W,2,ice);text(45,22,"PROJECT ERIS ++ INTERNAL EXPORT",4,ice,40);text(1000,28,"V1.12",3,pur,8);
 rect(90,145,1100,430,panel);text(130,185,"ONE-TIME INTERNAL GAME EXPORT",3,txt,42);text(130,235,current[0]?current:"PREPARING...",3,ice,55);text(130,285,message,2,mut,90);
 rect(130,365,1020,34,rgb(38,52,82));rect(134,369,1012,26,bg);if(total>0)fill=1012*done/total;if(fill>1012)fill=1012;rect(134,369,fill,26,green);
 num(b,done);text(130,425,b,4,green,4);text(215,435,"OF",2,mut,4);num(b,total);text(265,425,b,4,pur,4);text(350,435,"GAMES COPIED",2,txt,24);
 if(errorv[0]){text(130,490,"ERROR:",2,red,10);text(245,490,errorv,2,red,60);if(auto_mode)text(130,535,"RETURNING TO NORMAL BOOT - RECOVERY APP KEPT",2,pur,58);}
 else if(is_complete()){if(auto_mode)text(130,490,"COMPLETE - CLEANING UP AND POWERING OFF",2,green,58);else text(130,490,"COMPLETE - PRESS CIRCLE TO RETURN",2,green,50);}
 else{text(130,490,"DO NOT POWER OFF OR REMOVE THE USB DRIVE",2,pur,55);}
 if(auto_mode)text(50,665,"AUTOMATIC FIRST-BOOT EXPORT - NO INPUT REQUIRED",2,mut,58);else text(50,665,"CIRCLE: RETURN AFTER COMPLETE / ERROR",2,mut,48);
 if(video)video(fb,W,H,W*2);if(frames==0)elog("ERISPP112 FRAME0 VIDEO SENT");
 if(is_complete()||is_error())terminal_frames++;else terminal_frames=0;
 if(auto_mode&&terminal_frames>180&&env&&!shutdown){shutdown=1;elog(is_complete()?"ERISPP112 AUTO_UI_SHUTDOWN COMPLETE":"ERISPP112 AUTO_UI_SHUTDOWN ERROR");env(RETRO_ENVIRONMENT_SHUTDOWN,0);}
 if(input){int aNow=input(0,RETRO_DEVICE_JOYPAD,0,RETRO_DEVICE_ID_JOYPAD_A)!=0;if(!auto_mode&&aNow&&!prevA&&(is_complete()||is_error())){if(env&&!shutdown){shutdown=1;env(RETRO_ENVIRONMENT_SHUTDOWN,0);}}prevA=aNow;}
 frames++;
}

__attribute__((used,visibility("default"))) void *projecterispp_force_reloc_internal = (void*)&retro_api_version;
