typedef unsigned char u8; typedef unsigned short u16; typedef unsigned int u32; typedef signed int i32; typedef unsigned long long u64;
#define SYS_EXIT 1
#define SYS_READ 3
#define SYS_WRITE 4
#define SYS_OPEN 5
#define SYS_CLOSE 6
#define SYS_LSEEK 19
#define SYS_KILL 37
#define SYS_NANOSLEEP 162
#define SYS_LLSEEK 140
#define SYS_SOCKET 281
#define SYS_SENDTO 290
#define AF_INET 2
#define SOCK_DGRAM 2
#define O_RDONLY 0
#define O_WRONLY 1
#define O_CREAT 64
#define O_APPEND 1024
#define SEEK_SET 0
#define MAX_FILE (4*1024*1024)
#define MAX_ACH 512
#define MAX_GROUP 2048
#define MAX_COND 16384
#define TITLE 96

typedef struct { long tv_sec; long tv_nsec; } timespec_t;

void *memset(void *dst,int c,unsigned long n){unsigned char*p=(unsigned char*)dst;while(n--)*p++=(unsigned char)c;return dst;}
static u32 udiv32(u32 n,u32 d,u32*rem){u32 q=0,r=0;int i;if(!d){if(rem)*rem=n;return 0;}for(i=31;i>=0;i--){r=(r<<1)|((n>>i)&1u);if(r>=d){r-=d;q|=(1u<<i);}}if(rem)*rem=r;return q;}
u32 __aeabi_uidiv(u32 n,u32 d){return udiv32(n,d,0);}
i32 __aeabi_idiv(i32 n,i32 d){u32 un,ud,q;int neg;if(!d)return 0;neg=((n<0)^(d<0));un=(n<0)?(u32)(0u-(u32)n):(u32)n;ud=(d<0)?(u32)(0u-(u32)d):(u32)d;q=udiv32(un,ud,0);return neg?-(i32)q:(i32)q;}
const char ERISPP_EVALUATOR_BUILD[]="ERISPP_EVAL_1.0.5";
static volatile const char popup_prefix[]="SHOW_MSG [Project Eris ++] ";
static long sc1(long n,long a){register long r0 asm("r0")=a;register long r7 asm("r7")=n;asm volatile("svc 0":"+r"(r0):"r"(r7):"memory");return r0;}
static long sc2(long n,long a,long b){register long r0 asm("r0")=a;register long r1 asm("r1")=b;register long r7 asm("r7")=n;asm volatile("svc 0":"+r"(r0):"r"(r1),"r"(r7):"memory");return r0;}
static long sc3(long n,long a,long b,long c){register long r0 asm("r0")=a;register long r1 asm("r1")=b;register long r2 asm("r2")=c;register long r7 asm("r7")=n;asm volatile("svc 0":"+r"(r0):"r"(r1),"r"(r2),"r"(r7):"memory");return r0;}
static long sc5(long n,long a,long b,long c,long d,long e){register long r0 asm("r0")=a;register long r1 asm("r1")=b;register long r2 asm("r2")=c;register long r3 asm("r3")=d;register long r4 asm("r4")=e;register long r7 asm("r7")=n;asm volatile("svc 0":"+r"(r0):"r"(r1),"r"(r2),"r"(r3),"r"(r4),"r"(r7):"memory");return r0;}
static long sc6(long n,long a,long b,long c,long d,long e,long f){register long r0 asm("r0")=a;register long r1 asm("r1")=b;register long r2 asm("r2")=c;register long r3 asm("r3")=d;register long r4 asm("r4")=e;register long r5 asm("r5")=f;register long r7 asm("r7")=n;asm volatile("svc 0":"+r"(r0):"r"(r1),"r"(r2),"r"(r3),"r"(r4),"r"(r5),"r"(r7):"memory");return r0;}
static int slen(const char*s){int n=0;while(s&&s[n])n++;return n;}
static int seq(const char*a,const char*b){int i=0;while(a[i]&&b[i]&&a[i]==b[i])i++;return a[i]==b[i];}
static void copy(char*d,const char*s,int n){int i=0;if(n<=0)return;while(s&&s[i]&&i<n-1){d[i]=s[i];i++;}d[i]=0;}
static void write_s(int fd,const char*s){sc3(SYS_WRITE,fd,(long)s,slen(s));}
static void utoa(u32 v,char*b){char t[16];int n=0,i;if(!v){b[0]='0';b[1]=0;return;}while(v){t[n++]=(char)('0'+v%10);v/=10;}for(i=0;i<n;i++)b[i]=t[n-1-i];b[n]=0;}
static u32 atou(const char*s){u32 v=0;int i=0;while(s[i]>='0'&&s[i]<='9'){v=v*10+(u32)(s[i]-'0');i++;}return v;}
static int openf(const char*p,int flags){return (int)sc3(SYS_OPEN,(long)p,flags,0644);}
static int readf(int fd,void*b,int n){return (int)sc3(SYS_READ,fd,(long)b,n);}
static void closef(int fd){sc1(SYS_CLOSE,fd);}
static void sleep_ms(int ms){timespec_t t;t.tv_sec=ms/1000;t.tv_nsec=(ms%1000)*1000000;sc2(SYS_NANOSLEEP,(long)&t,0);}
static int seek64(int fd,u32 off){u64 res=0;return (int)sc5(SYS_LLSEEK,fd,0,off,(long)&res,SEEK_SET);}

static char filebuf[MAX_FILE];
static char *fields[20];
static int split_tabs(char*s){int n=0;fields[n++]=s;while(*s){if(*s=='\t'){*s=0;if(n<20)fields[n++]=s+1;}s++;}return n;}

enum {K_NONE=0,K_MEM=1,K_CONST=2,K_FCONST=3,K_RECALL=4};
enum {SZ_BIT0=1,SZ_BIT1,SZ_BIT2,SZ_BIT3,SZ_BIT4,SZ_BIT5,SZ_BIT6,SZ_BIT7,SZ_LOW4,SZ_UP4,SZ_U8,SZ_U16,SZ_U24,SZ_U32,SZ_U16BE,SZ_U24BE,SZ_U32BE,SZ_BITCOUNT,SZ_FLOAT,SZ_FLOATBE};
typedef struct {u8 kind,mod,size;u32 val;u32 cur,prev,prior;u8 init;} Operand;
typedef struct {u8 flag,op;Operand l,r;u32 hit_target,hits;} Cond;
typedef struct {u8 type;u16 first,count;} Group;
typedef struct {u32 id;u16 points;u16 first_group,group_count;char title[TITLE];u8 unlocked;} Ach;
static Cond conds[MAX_COND];static Group groups[MAX_GROUP];static Ach achs[MAX_ACH];static int ncond=0,ngroup=0,nach=0;static u32 gameid=0;

static u8 sizecode(char c){switch(c){case'0':return SZ_BIT0;case'1':return SZ_BIT1;case'2':return SZ_BIT2;case'3':return SZ_BIT3;case'4':return SZ_BIT4;case'5':return SZ_BIT5;case'6':return SZ_BIT6;case'7':return SZ_BIT7;case'l':return SZ_LOW4;case'u':return SZ_UP4;case'8':return SZ_U8;case'w':return SZ_U16;case't':return SZ_U24;case'x':return SZ_U32;case'I':return SZ_U16BE;case'J':return SZ_U24BE;case'G':return SZ_U32BE;case'K':return SZ_BITCOUNT;case'F':return SZ_FLOAT;case'B':return SZ_FLOATBE;}return 0;}
static u8 kindcode(char c){if(c=='m')return K_MEM;if(c=='c')return K_CONST;if(c=='f')return K_FCONST;if(c=='r')return K_RECALL;return K_NONE;}
static u8 flagcode(char c){return (u8)c;}
static u8 opcode(const char*s){if(!s||s[0]=='.')return 0;if(seq(s,"="))return 1;if(seq(s,"!="))return 2;if(seq(s,">"))return 3;if(seq(s,">="))return 4;if(seq(s,"<"))return 5;if(seq(s,"<="))return 6;if(seq(s,"*"))return 7;if(seq(s,"/"))return 8;if(seq(s,"%"))return 9;if(seq(s,"+"))return 10;if(seq(s,"-"))return 11;if(seq(s,"&"))return 12;if(seq(s,"^"))return 13;return 0;}
static void parseop(Operand*o,char*k,char*m,char*s,char*v){o->kind=kindcode(k[0]);o->mod=(u8)m[0];o->size=sizecode(s[0]);o->val=atou(v);o->cur=o->prev=o->prior=0;o->init=0;}
static int loadpack(const char*path){int fd=openf(path,O_RDONLY),n;char*p,*e;Ach*ca=0;Group*cg=0;if(fd<0)return 0;n=readf(fd,filebuf,MAX_FILE-1);closef(fd);if(n<=0)return 0;filebuf[n]=0;p=filebuf;while(*p){e=p;while(*e&&*e!='\n'&&*e!='\r')e++;if(*e){*e=0;e++;while(*e=='\n'||*e=='\r')e++;}if(*p){int nf=split_tabs(p);if(nf>0&&seq(fields[0],"ERPP2")){if(nf>1)gameid=atou(fields[1]);}
else if(nf>=6&&seq(fields[0],"A")&&nach<MAX_ACH){ca=&achs[nach++];ca->id=atou(fields[1]);ca->points=(u16)atou(fields[2]);ca->group_count=(u16)atou(fields[3]);copy(ca->title,fields[4],TITLE);ca->first_group=(u16)ngroup;ca->unlocked=0;}
else if(nf>=3&&seq(fields[0],"G")&&ngroup<MAX_GROUP){cg=&groups[ngroup++];cg->type=(u8)fields[1][0];cg->count=(u16)atou(fields[2]);cg->first=(u16)ncond;}
else if(nf>=12&&seq(fields[0],"C")&&ncond<MAX_COND){Cond*c=&conds[ncond++];c->flag=flagcode(fields[1][0]);parseop(&c->l,fields[2],fields[3],fields[4],fields[5]);c->op=opcode(fields[6]);parseop(&c->r,fields[7],fields[8],fields[9],fields[10]);c->hit_target=atou(fields[11]);c->hits=0;}
}p=e;}return nach>0&&ncond>0;}

static int memfd=-1;
static u32 readraw(u32 off,u8 size){u8 b[4]={0,0,0,0};u32 addr=0x80000000u+off,v=0;int need=4;if(size>=SZ_BIT0&&size<=SZ_BIT7)need=1;else if(size==SZ_LOW4||size==SZ_UP4||size==SZ_U8||size==SZ_BITCOUNT)need=1;else if(size==SZ_U16||size==SZ_U16BE)need=2;else if(size==SZ_U24||size==SZ_U24BE)need=3;else need=4;if(seek64(memfd,addr)<0)return 0;if(readf(memfd,b,need)!=need)return 0;if(size>=SZ_BIT0&&size<=SZ_BIT7)return (b[0]>>(size-SZ_BIT0))&1;if(size==SZ_LOW4)return b[0]&15;if(size==SZ_UP4)return (b[0]>>4)&15;if(size==SZ_U8)return b[0];if(size==SZ_U16)return (u32)b[0]|((u32)b[1]<<8);if(size==SZ_U24)return (u32)b[0]|((u32)b[1]<<8)|((u32)b[2]<<16);if(size==SZ_U32||size==SZ_FLOAT)return (u32)b[0]|((u32)b[1]<<8)|((u32)b[2]<<16)|((u32)b[3]<<24);if(size==SZ_U16BE)return ((u32)b[0]<<8)|b[1];if(size==SZ_U24BE)return ((u32)b[0]<<16)|((u32)b[1]<<8)|b[2];if(size==SZ_U32BE||size==SZ_FLOATBE)return ((u32)b[0]<<24)|((u32)b[1]<<16)|((u32)b[2]<<8)|b[3];if(size==SZ_BITCOUNT){u8 x=b[0],c=0;while(x){c+=(x&1);x>>=1;}return c;}return v;}
static u32 masksize(u32 v,u8 s){if(s==SZ_LOW4||s==SZ_UP4)return v&15;if(s==SZ_U8)return v&255;if(s==SZ_U16||s==SZ_U16BE)return v&65535;if(s==SZ_U24||s==SZ_U24BE)return v&0xffffff;return v;}
static u32 bcd(u32 v,u8 s){u32 r=0,m=1;int n=(s==SZ_U8?2:(s==SZ_U16||s==SZ_U16BE?4:(s==SZ_U24||s==SZ_U24BE?6:8))),i;for(i=0;i<n;i++){r+=(v&15)*m;m*=10;v>>=4;}return r;}
static u32 invertv(u32 v,u8 s){if(s==SZ_LOW4||s==SZ_UP4)return v^15;if(s==SZ_U8)return v^255;if(s==SZ_U16||s==SZ_U16BE)return v^65535;if(s==SZ_U24||s==SZ_U24BE)return v^0xffffff;return ~v;}
static u32 evalop(Operand*o,u32 recall,u32 addaddr){u32 v;if(o->kind==K_CONST||o->kind==K_FCONST)return o->val;if(o->kind==K_RECALL)return recall;if(o->kind!=K_MEM)return 0;v=readraw(o->val+addaddr,o->size);if(!o->init){o->cur=v;o->prev=0;o->prior=0;o->init=1;}else{u32 old=o->cur;o->prev=old;if(v!=old)o->prior=old;o->cur=v;}if(o->mod=='d')v=o->prev;else if(o->mod=='p')v=o->prior;else if(o->mod=='c')v=bcd(v,o->size);else if(o->mod=='v')v=invertv(v,o->size);return v;}
static u32 arith(u32 a,u8 op,u32 b){switch(op){case 7:return a*b;case 8:return b?a/b:0;case 9:return b?a%b:0;case 10:return a+b;case 11:return a-b;case 12:return a&b;case 13:return a^b;default:return a;}}
static int cmp(u32 a,u8 op,u32 b){switch(op){case 1:return a==b;case 2:return a!=b;case 3:return a>b;case 4:return a>=b;case 5:return a<b;case 6:return a<=b;default:return a!=0;}}
static int condtruth(Cond*c,u32*acc,u32*addr,u32*recall,int mutate){u32 l=evalop(&c->l,*recall,*addr),r=c->r.kind?evalop(&c->r,*recall,*addr):0,val=l;int t;if(c->op>=7)val=arith(l,c->op,r);if(c->flag=='A'){*acc+=val;return 1;}if(c->flag=='B'){*acc-=val;return 1;}if(c->flag=='I'){*addr+=val;return 1;}if(c->flag=='K'){*recall=val;return 1;}if(c->op>=1&&c->op<=6)t=cmp(l+*acc,c->op,r);else t=(val+*acc)!=0;*acc=0;*addr=0;if(c->hit_target){if(mutate&&t&&c->hits<c->hit_target)c->hits++;return c->hits>=c->hit_target;}return t;}
static void resetall(void){int i;for(i=0;i<ncond;i++)conds[i].hits=0;}
static int evalgroup(Group*g,int mutate){u32 acc=0,addr=0,recall=0;int i,end=g->first+g->count,all=1,chain=0,chainop=0;u32 addh=0,subh=0;
/* pause pass */for(i=g->first;i<end;i++){Cond*c=&conds[i];if(c->flag=='P'){int t=condtruth(c,&acc,&addr,&recall,mutate);if(t)return 0;}}
acc=addr=recall=0;
for(i=g->first;i<end;i++){Cond*c=&conds[i];int t;if(c->flag=='P')continue;if(c->flag=='R'){t=condtruth(c,&acc,&addr,&recall,mutate);if(t){if(mutate)resetall();return 0;}continue;}if(c->flag=='Z'){t=condtruth(c,&acc,&addr,&recall,mutate);if(t&&mutate){int j=i+1;while(j<end&&(conds[j].flag=='A'||conds[j].flag=='B'||conds[j].flag=='I'||conds[j].flag=='K'))j++;if(j<end)conds[j].hits=0;}continue;}if(c->flag=='A'||c->flag=='B'||c->flag=='I'||c->flag=='K'){condtruth(c,&acc,&addr,&recall,mutate);continue;}t=condtruth(c,&acc,&addr,&recall,mutate);if(c->flag=='C'){if(mutate&&t)c->hits++;addh+=c->hits;continue;}if(c->flag=='D'){if(mutate&&t)c->hits++;subh+=c->hits;continue;}if(c->hit_target&&(addh||subh)){u32 eff=c->hits+addh;if(eff>=subh)eff-=subh;else eff=0;t=eff>=c->hit_target;addh=subh=0;}
if(c->flag=='N'){if(!chain){chain=t;chainop='N';}else chain=(chainop=='N')?(chain&&t):(chain||t);chainop='N';continue;}if(c->flag=='O'){if(!chain){chain=t;chainop='O';}else chain=(chainop=='N')?(chain&&t):(chain||t);chainop='O';continue;}if(chain){t=(chainop=='N')?(chain&&t):(chain||t);chain=0;chainop=0;}if(c->flag=='Q'&&!t)all=0;else if(c->flag=='M'||c->flag=='G'||c->flag=='T'||c->flag=='S'||c->flag==0){if(!t)all=0;}else if(!t)all=0;}
return all;}
static int evalach(Ach*a){int i,core=1,anyalt=0,altok=0;for(i=0;i<a->group_count;i++){Group*g=&groups[a->first_group+i];int ok=evalgroup(g,1);if(g->type=='C')core=ok;else{anyalt=1;if(ok)altok=1;}}return core&&(!anyalt||altok);}
static int contains_id(const char*buf,u32 id){char n[16];int i,j;utoa(id,n);for(i=0;buf[i];i++){for(j=0;n[j]&&buf[i+j]==n[j];j++);if(!n[j]&&(i==0||buf[i-1]=='\n'||buf[i-1]==' ')&&(buf[i+j]=='\n'||buf[i+j]==0||buf[i+j]==' '))return 1;}return 0;}
static void loadstate(const char*path){static char b[65536];int fd=openf(path,O_RDONLY),n,i;if(fd<0)return;n=readf(fd,b,65535);closef(fd);if(n<=0)return;b[n]=0;for(i=0;i<nach;i++)if(contains_id(b,achs[i].id))achs[i].unlocked=1;}
struct sockaddr_in_x{u16 family;u16 port;u32 addr;u8 zero[8];};
static void popup(Ach*a){int fd,i;struct sockaddr_in_x sa;char msg[220],num[16];int k=0,j;const volatile char*pfx=popup_prefix;for(j=0;pfx[j]&&k<218;j++)msg[k++]=(char)pfx[j];for(j=0;a->title[j]&&k<185;j++)msg[k++]=a->title[j];if(k<215){msg[k++]=' ';msg[k++]='+';utoa(a->points,num);for(j=0;num[j]&&k<216;j++)msg[k++]=num[j];msg[k++]=' ';msg[k++]='X';msg[k++]='P';}msg[k]=0;sa.family=AF_INET;sa.port=(u16)0x3bd8;sa.addr=0x0100007f;for(i=0;i<8;i++)sa.zero[i]=0;fd=(int)sc3(SYS_SOCKET,AF_INET,SOCK_DGRAM,0);if(fd>=0){sc6(SYS_SENDTO,fd,(long)msg,slen(msg),0,(long)&sa,sizeof(sa));closef(fd);}}
static void logunlock(const char*log,const char*state,Ach*a,int live){char num[16];int fd=openf(log,O_WRONLY|O_CREAT|O_APPEND);if(fd>=0){write_s(fd,live?"UNLOCK\t":"SHADOW\t");utoa(a->id,num);write_s(fd,num);write_s(fd,"\t");write_s(fd,a->title);write_s(fd,"\n");closef(fd);}if(live){fd=openf(state,O_WRONLY|O_CREAT|O_APPEND);if(fd>=0){utoa(a->id,num);write_s(fd,num);write_s(fd,"\n");closef(fd);popup(a);}}a->unlocked=1;}
static int atoi10(const char*s){return (int)atou(s);}
static void make_mempath(char*b,int pid){char n[16];utoa((u32)pid,n);copy(b,"/proc/",64);int l=slen(b);copy(b+l,n,64-l);l=slen(b);copy(b+l,"/mem",64-l);}
int main(int argc,char**argv){char mempath[64];int pid,live=0,i;write_s(1,"ERISPP_EVAL_105 BOOT\n");if(argc<6)return 2;pid=atoi10(argv[1]);if(!loadpack(argv[2]))return 3;write_s(1,"ERISPP_EVAL_105 PACK_OK\n");loadstate(argv[3]);if(seq(argv[5],"live"))live=1;make_mempath(mempath,pid);memfd=openf(mempath,O_RDONLY);if(memfd<0)return 4;write_s(1,"ERISPP_EVAL_105 MEM_OK\n");for(;;){if(sc2(SYS_KILL,pid,0)<0)break;for(i=0;i<nach;i++){if(!achs[i].unlocked&&evalach(&achs[i]))logunlock(argv[4],argv[3],&achs[i],live);}sleep_ms(16);}closef(memfd);return 0;}
